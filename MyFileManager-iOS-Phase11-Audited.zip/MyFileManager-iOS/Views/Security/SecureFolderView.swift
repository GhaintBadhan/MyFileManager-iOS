import SwiftUI
import LocalAuthentication

struct SecureFolderView: View {
    let url: URL
    
    @State private var isUnlocked = false
    @State private var isAuthenticating = false
    @State private var errorMessage: String?
    
    var body: some View {
        Group {
            if !isUnlocked {
                VStack(spacing: 20) {
                    Image(systemName: "lock.shield.fill")
                        .font(.system(size: 80))
                        .foregroundStyle(.blue)
                    
                    Text("Hidden Space")
                        .font(.title)
                        .fontWeight(.bold)
                    
                    if let error = errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundStyle(.red)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                    
                    Button {
                        authenticate()
                    } label: {
                        Label("Unlock with Face ID", systemImage: "faceid")
                            .font(.headline)
                            .foregroundStyle(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                    }
                    .disabled(isAuthenticating)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color(UIColor.systemGroupedBackground))
                .onAppear {
                    authenticate()
                }
            } else {
                BrowserView(url: url)
            }
        }
    }
    
    private func authenticate() {
        guard !isAuthenticating else { return }
        isAuthenticating = true
        errorMessage = nil
        
        let context = LAContext()
        var error: NSError?
        
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Access your hidden folders") { success, authError in
                DispatchQueue.main.async {
                    isAuthenticating = false
                    if success {
                        withAnimation { isUnlocked = true }
                    } else {
                        fallbackToPasscode()
                    }
                }
            }
        } else {
            fallbackToPasscode()
        }
    }
    
    private func fallbackToPasscode() {
        let context = LAContext()
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Access your hidden folders") { success, authError in
            DispatchQueue.main.async {
                isAuthenticating = false
                if success {
                    withAnimation { isUnlocked = true }
                } else {
                    if let authError = authError {
                        errorMessage = authError.localizedDescription
                    }
                }
            }
        }
    }
}
