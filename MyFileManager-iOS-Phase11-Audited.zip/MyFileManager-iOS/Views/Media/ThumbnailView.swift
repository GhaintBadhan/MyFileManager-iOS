import SwiftUI
import AVFoundation
import ImageIO

final class ThumbnailCache: @unchecked Sendable {
    static let shared = NSCache<NSURL, UIImage>()
    private init() {}
}

struct ThumbnailView: View {
    let url: URL
    let fallbackIcon: String
    let fallbackColor: Color
    
    @State private var thumbnail: UIImage?
    
    var body: some View {
        Group {
            if let thumbnail = thumbnail {
                Image(uiImage: thumbnail)
                    .resizable()
                    .scaledToFill()
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            } else {
                Image(systemName: fallbackIcon)
                    .font(.system(size: 32))
                    .foregroundStyle(fallbackColor)
            }
        }
        .onAppear(perform: loadThumbnail)
    }
    
    private func loadThumbnail() {
        let ext = url.pathExtension.lowercased()
        let isImage = ["png", "jpg", "jpeg", "gif", "webp", "heic"].contains(ext)
        let isVideo = ["mp4", "mov", "mkv", "avi", "m4v"].contains(ext)
        
        guard isImage || isVideo else { return }
        
        if let cached = ThumbnailCache.shared.object(forKey: url as NSURL) {
            self.thumbnail = cached
            return
        }
        
        Task.detached(priority: .userInitiated) {
            var image: UIImage? = nil
            
            if isImage {
                image = generateImageThumbnail(url: url)
            } else if isVideo {
                image = await generateVideoThumbnail(url: url)
            }
            
            if let image = image {
                ThumbnailCache.shared.setObject(image, forKey: url as NSURL)
                await MainActor.run {
                    self.thumbnail = image
                }
            }
        }
    }
    
    // 🔥 FIXED: Added 'nonisolated' so Swift 6 allows it to run in the background
    nonisolated private func generateImageThumbnail(url: URL) -> UIImage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return nil }
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageIfAbsent: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: 200
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }
        return UIImage(cgImage: cgImage)
    }
    
    // 🔥 FIXED: Added 'nonisolated' here too
    nonisolated private func generateVideoThumbnail(url: URL) async -> UIImage? {
        let asset = AVURLAsset(url: url)
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: 200, height: 200)
        
        do {
            let (cgImage, _) = try await generator.image(at: CMTime(value: 1, timescale: 2))
            return UIImage(cgImage: cgImage)
        } catch {
            return nil
        }
    }
}
