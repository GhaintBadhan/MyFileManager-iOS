import SwiftUI

struct MediaGalleryView: View {
    let items: [FileItem]
    @State private var selectedIndex: Int
    @Environment(\.dismiss) var dismiss
    
    @State private var dragOffset: CGSize = .zero

    init(items: [FileItem], startIndex: Int) {
        self.items = items
        self._selectedIndex = State(initialValue: startIndex)
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black
                .opacity(1 - Double(abs(dragOffset.height) / 500))
                .ignoresSafeArea()
            
            TabView(selection: $selectedIndex) {
                ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                    if let uiImage = loadImage(from: item.url) {
                        ZoomableImageView(image: uiImage)
                            .tag(index)
                    } else {
                        VStack {
                            Image(systemName: "photo").font(.largeTitle)
                            Text("Cannot load image")
                        }
                        .foregroundStyle(.white)
                        .tag(index)
                    }
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
            .indexViewStyle(.page(backgroundDisplayMode: .always))
            // 🔥 NEW: Swipe down to dismiss
            .offset(y: dragOffset.height)
            .scaleEffect(1 - Double(abs(dragOffset.height) / 1000))
            .gesture(
                DragGesture()
                    .onChanged { value in
                        if value.translation.height > 0 {
                            dragOffset = value.translation
                        }
                    }
                    .onEnded { value in
                        if value.translation.height > 150 {
                            HapticManager.shared.impact(style: .medium)
                            dismiss()
                        } else {
                            withAnimation(.spring()) { dragOffset = .zero }
                        }
                    }
            )
            
            Button {
                HapticManager.shared.impact()
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title)
                    .foregroundStyle(.white, .black.opacity(0.5))
                    .padding()
            }
        }
    }

    private func loadImage(from url: URL) -> UIImage? {
        return UIImage(contentsOfFile: url.path)
    }
}

struct ZoomableImageView: View {
    let image: UIImage
    @State private var scale: CGFloat = 1.0
    
    var body: some View {
        Image(uiImage: image)
            .resizable()
            .scaledToFit()
            .scaleEffect(scale)
            .gesture(
                MagnificationGesture()
                    .onChanged { value in scale = value }
                    .onEnded { _ in withAnimation(.spring()) { scale = 1.0 } }
            )
    }
}
