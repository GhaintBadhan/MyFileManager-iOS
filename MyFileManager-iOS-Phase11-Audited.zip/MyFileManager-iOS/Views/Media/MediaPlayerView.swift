import SwiftUI
import AVKit
import MediaPlayer

struct MediaPlayerView: View {
    let url: URL
    @Environment(\.dismiss) var dismiss
    @State private var player = AVPlayer()
    @State private var playbackRate: Float = 1.0
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                if isVideo(url: url) {
                    AVPlayerView(player: player)
                        .ignoresSafeArea()
                } else {
                    VStack(spacing: 20) {
                        Image(systemName: "music.note")
                            .font(.system(size: 80))
                            .foregroundStyle(.white.opacity(0.5))
                            .padding(.bottom, 20)
                        
                        Text(url.lastPathComponent)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        AVPlayerView(player: player)
                            .frame(height: 80)
                    }
                }
                
                // Playback Speed Control
                HStack {
                    Text("Speed:")
                        .foregroundStyle(.white)
                    ForEach([0.5, 1.0, 1.5, 2.0], id: \.self) { speed in
                        Button {
                            playbackRate = Float(speed)
                            player.rate = playbackRate
                        } label: {
                            Text("\(speed, specifier: "%.1f")x")
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(playbackRate == Float(speed) ? Color.blue : Color.white.opacity(0.2))
                                .foregroundStyle(.white)
                                .cornerRadius(8)
                        }
                    }
                }
                .padding(.bottom, 40)
            }
        }
        .navigationTitle(url.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            setupPlayer()
        }
        .onDisappear {
            player.pause()
        }
    }
    
    private func setupPlayer() {
        // 🔥 Enable Background Audio
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to set audio session: \(error)")
        }
        
        player = AVPlayer(url: url)
        player.play()
        
        // 🔥 Lock Screen Controls
        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.playCommand.addTarget { _ in
            self.player.play()
            return .success
        }
        commandCenter.pauseCommand.addTarget { _ in
            self.player.pause()
            return .success
        }
        
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: url.lastPathComponent,
            MPMediaItemPropertyPlaybackDuration: player.currentItem?.duration.seconds ?? 0
        ]
    }
    
    private func isVideo(url: URL) -> Bool {
        let videoExts = ["mp4", "mov", "mkv", "avi", "m4v"]
        return videoExts.contains(url.pathExtension.lowercased())
    }
}

struct AVPlayerView: UIViewControllerRepresentable {
    let player: AVPlayer
    
    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = true
        return controller
    }
    
    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) {
        uiViewController.player = player
    }
}
