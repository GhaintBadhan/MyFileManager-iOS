import SwiftUI
import PencilKit

struct ImageMarkupView: View {
    let item: FileItem
    @Environment(\.dismiss) var dismiss
    
    // 🔥 FIXED: Use environment to get the screen scale safely
    @Environment(\.displayScale) var displayScale
    
    @State private var canvasView = PKCanvasView()
    @State private var originalImage: UIImage?
    @State private var isSaving = false
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                if let originalImage = originalImage {
                    // The image being drawn on
                    Image(uiImage: originalImage)
                        .resizable()
                        .scaledToFit()
                    
                    // The transparent drawing canvas
                    CanvasView(canvasView: $canvasView)
                } else {
                    ProgressView()
                }
            }
            .navigationTitle("Markup")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Save") { saveImage() }
                        .disabled(originalImage == nil || isSaving)
                }
            }
            .alert("Error", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
            .onAppear {
                loadImage()
            }
        }
    }
    
    private func loadImage() {
        if let image = UIImage(contentsOfFile: item.url.path) {
            self.originalImage = image
        } else {
            self.errorMessage = "Could not load image."
        }
    }
    
    private func saveImage() {
        guard let originalImage = originalImage else { return }
        isSaving = true
        
        // Render the canvas drawing into an image
        let bounds = CGRect(origin: .zero, size: originalImage.size)
        
        // 🔥 FIXED: Use displayScale instead of UIScreen.main.scale
        let drawingImage = canvasView.drawing.image(from: bounds, scale: displayScale)
        
        // Merge original image and drawing
        let format = UIGraphicsImageRendererFormat()
        format.scale = displayScale
        let renderer = UIGraphicsImageRenderer(size: originalImage.size, format: format)
        
        let mergedImage = renderer.image { context in
            originalImage.draw(at: .zero)
            drawingImage.draw(in: bounds)
        }
        
        // Save as JPEG/PNG
        let ext = item.url.pathExtension.lowercased()
        let data: Data?
        if ext == "png" {
            data = mergedImage.pngData()
        } else {
            data = mergedImage.jpegData(compressionQuality: 0.9)
        }
        
        if let data = data {
            do {
                try data.write(to: item.url)
                NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                dismiss()
            } catch {
                self.errorMessage = "Failed to save: \(error.localizedDescription)"
                self.isSaving = false
            }
        }
    }
}

// Wrapper for PKCanvasView
struct CanvasView: UIViewRepresentable {
    @Binding var canvasView: PKCanvasView
    
    func makeUIView(context: Context) -> PKCanvasView {
        canvasView.tool = PKInkingTool(.pen, color: .red, width: 5)
        canvasView.drawingPolicy = .anyInput
        canvasView.backgroundColor = .clear
        canvasView.isOpaque = false
        return canvasView
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {}
}
