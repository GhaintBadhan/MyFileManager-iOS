import SwiftUI
import UniformTypeIdentifiers

struct WebDAVView: View {
    @Environment(\.dismiss) var dismiss
    
    @State private var serverURL = ""
    @State private var username = ""
    @State private var password = ""
    @State private var saveCredentials = true
    
    @State private var isConnected = false
    @State private var service: WebDAVService?
    @StateObject private var transferService = BackgroundTransferService.shared
    @State private var currentPath: URL?
    @State private var items: [WebDAVItem] = []
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    // 🔥 NEW: Upload & Folder Creation State
    @State private var showImporter = false
    @State private var showNewFolderAlert = false
    @State private var newFolderName = ""
    @State private var showTransfers = false
    
    var body: some View {
        NavigationStack {
            Group {
                if !isConnected {
                    connectionForm
                } else {
                    fileBrowser
                }
            }
            .navigationTitle(isConnected ? (currentPath?.lastPathComponent ?? "WebDAV") : "Connect WebDAV")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if isConnected {
                        Button("Disconnect") { isConnected = false }
                    } else {
                        Button("Cancel") { dismiss() }
                    }
                }
                // 🔥 NEW: Action Menu
                ToolbarItem(placement: .topBarTrailing) {
                    if isConnected {
                        Menu {
                            Button { showImporter = true } label: { Label("Upload File", systemImage: "arrow.up.doc") }
                            Button { showNewFolderAlert = true } label: { Label("New Folder", systemImage: "folder.badge.plus") }
                            Button { showTransfers = true } label: { Label("Network Transfers", systemImage: "arrow.up.arrow.down") }
                        } label: {
                            Image(systemName: "plus.circle.fill")
                        }
                    } else if isLoading {
                        ProgressView()
                    }
                }
            }
            .alert("Error", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(errorMessage ?? "") }
            .alert("New Folder", isPresented: $showNewFolderAlert) {
                TextField("Folder Name", text: $newFolderName)
                Button("Create") { createFolder() }
                Button("Cancel", role: .cancel) { newFolderName = "" }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item]) { result in
                if case .success(let url) = result {
                    uploadFile(url: url)
                }
            }
            .sheet(isPresented: $showTransfers) {
                NetworkTransfersView(transferService: transferService)
            }
        }
    }
    
    private var connectionForm: some View {
        Form {
            Section("Server Details") {
                TextField("https://example.com/remote.php/dav", text: $serverURL)
                    .keyboardType(.URL).autocapitalization(.none)
                TextField("Username", text: $username)
                    .autocapitalization(.none)
                SecureField("Password", text: $password)
                Toggle("Save credentials in Keychain", isOn: $saveCredentials)
                HStack {
                    Button("Load Saved Credentials") { loadSavedCredentials() }
                    Spacer()
                    Button("Forget") {
                        KeychainService.deleteWebDAV(server: serverURL)
                        username = ""
                        password = ""
                    }
                    .foregroundStyle(.red)
                }
            }
            Section {
                Button("Connect") { connect() }
                    .disabled(serverURL.isEmpty || username.isEmpty)
            }
        }
    }
    
    private var fileBrowser: some View {
        List(items) { item in
            if item.isDirectory {
                Button {
                    loadDirectory(item.url)
                } label: {
                    Label { Text(item.name) } icon: { Image(systemName: "folder.fill").foregroundStyle(.blue) }
                }
            } else {
                HStack {
                    Label { Text(item.name) } icon: { Image(systemName: "doc.fill").foregroundStyle(.gray) }
                    Spacer()
                    Text(ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file))
                        .font(.caption).foregroundStyle(.secondary)
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    download(item)
                }
            }
        }
        .overlay {
            if items.isEmpty && !isLoading {
                ContentUnavailableView("Empty Folder", systemImage: "folder")
            }
        }
    }
    
    private func connect() {
        guard let url = URL(string: serverURL) else { return }
        if saveCredentials {
            do {
                try KeychainService.saveWebDAV(server: serverURL, username: username, password: password)
            } catch {
                errorMessage = "Could not save credentials securely: \(error.localizedDescription)"
                return
            }
        }
        service = WebDAVService(url: url, username: username, password: password)
        isConnected = true
        loadDirectory(url)
    }

    private func loadSavedCredentials() {
        guard let credentials = KeychainService.loadWebDAV(server: serverURL) else {
            errorMessage = "No saved credentials were found for this server."
            return
        }
        username = credentials.username
        password = credentials.password
    }
    
    private func loadDirectory(_ url: URL) {
        isLoading = true
        currentPath = url
        Task {
            do {
                let fetchedItems = try await service?.listDirectory(at: url) ?? []
                await MainActor.run {
                    self.items = fetchedItems
                    self.isLoading = false
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
    
    private func download(_ item: WebDAVItem) {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dest = docs.appendingPathComponent(item.name)
        guard let service else { return }
        _ = transferService.enqueueDownload(request: service.downloadRequest(for: item.url), to: dest)
    }
    
    // 🔥 NEW: Upload logic
    private func uploadFile(url: URL) {
        guard let currentPath = currentPath else { return }
        let dest = currentPath.appendingPathComponent(url.lastPathComponent)
        guard let service else { return }
        let started = url.startAccessingSecurityScopedResource()
        _ = transferService.enqueueUpload(request: service.uploadRequest(for: dest), from: url)
        if started { url.stopAccessingSecurityScopedResource() }
    }
    
    // 🔥 NEW: Create Folder logic
    private func createFolder() {
        guard let currentPath = currentPath, !newFolderName.isEmpty else { return }
        isLoading = true
        Task {
            do {
                try await service?.createFolder(name: newFolderName, at: currentPath)
                await MainActor.run {
                    self.isLoading = false
                    self.newFolderName = ""
                    loadDirectory(currentPath)
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
}
