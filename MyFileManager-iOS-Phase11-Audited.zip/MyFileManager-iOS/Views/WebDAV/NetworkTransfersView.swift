import SwiftUI

struct NetworkTransfersView: View {
    @ObservedObject var transferService: BackgroundTransferService
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if transferService.records.isEmpty {
                    ContentUnavailableView("No Network Transfers", systemImage: "arrow.up.arrow.down", description: Text("Background uploads and downloads will appear here."))
                } else {
                    ForEach(transferService.records.reversed()) { record in
                        HStack(spacing: 12) {
                            Image(systemName: record.kind == .download ? "arrow.down.circle" : "arrow.up.circle")
                                .foregroundStyle(.blue)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(record.name).lineLimit(1)
                                ProgressView(value: record.progress)
                                if let error = record.errorMessage {
                                    Text(error).font(.caption).foregroundStyle(.red).lineLimit(2)
                                }
                            }
                            Spacer()
                            Text(record.state.rawValue).font(.caption.weight(.semibold)).foregroundStyle(color(for: record.state))
                            if record.state == .running {
                                Button { transferService.cancel(record.id) } label: { Image(systemName: "xmark.circle.fill") }
                                    .buttonStyle(.plain)
                            } else if record.state == .cancelled, record.resumeData != nil {
                                Button { transferService.resume(record.id) } label: { Image(systemName: "play.circle.fill") }
                                    .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("Network Transfers")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Clear") { transferService.removeFinished() }
                        .disabled(transferService.records.allSatisfy { $0.state == .running || $0.state == .queued })
                }
            }
        }
    }

    private func color(for state: NetworkTransferRecord.State) -> Color {
        switch state {
        case .queued, .running: return .blue
        case .finished: return .green
        case .failed: return .red
        case .cancelled: return .secondary
        }
    }
}
