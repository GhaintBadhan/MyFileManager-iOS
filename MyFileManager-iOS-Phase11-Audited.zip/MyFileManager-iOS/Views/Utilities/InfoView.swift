import SwiftUI

struct InfoView: View {
    let item: FileItem
    @State private var hashes: [(HashAlgorithm, String)] = []
    @State private var working = false
    
    @State private var permissions = ""
    @State private var fileType = "Unknown"
    @State private var modDate = Date()
    @State private var totalSize: Int64 = 0
    @State private var showPermAlert = false
    @State private var newPermInput = ""
    
    private let service = FileSystemService()

    var body: some View {
        List {
            Section("General") {
                LabeledContent("Size", value: ByteCountFormatter.string(fromByteCount: totalSize, countStyle: .file))
                LabeledContent("Type", value: fileType)
                
                DatePicker("Modified", selection: $modDate, displayedComponents: [.date, .hourAndMinute])
                    .onChange(of: modDate) { _, newDate in
                        try? service.updateModificationDate(item.url, date: newDate)
                        NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                    }
            }
            
            Section("Permissions") {
                HStack {
                    Text("POSIX Mode")
                    Spacer()
                    Text(permissions).font(.system(.body, design: .monospaced)).foregroundStyle(.secondary)
                }
                .contentShape(Rectangle())
                .onTapGesture {
                    newPermInput = permissions
                    showPermAlert = true
                }
            }
            
            Section("Path") {
                Text(item.url.path).font(.caption).textSelection(.enabled)
            }
            
            Section("Checksums") {
                ForEach(hashes, id: \.0) { algo, value in
                    VStack(alignment: .leading) {
                        Text(algo.rawValue).font(.caption).foregroundStyle(.secondary)
                        Text(value).font(.system(size: 11, design: .monospaced)).textSelection(.enabled)
                    }
                }
                Button(working ? "Computing..." : "Compute Checksums") { compute() }.disabled(working)
            }
        }
        .onAppear { 
            loadProperties() 
            
            // 🔥 FIXED: Create the service inside the detached task
            let url = item.url
            Task.detached {
                let localService = FileSystemService()
                let size = localService.calculateFolderSize(url)
                await MainActor.run {
                    self.totalSize = size
                }
            }
        }
        .alert("Edit Permissions", isPresented: $showPermAlert) {
            TextField("e.g., 755", text: $newPermInput).keyboardType(.numberPad)
            Button("Save") { savePermissions() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Enter the new POSIX permission code (e.g., 644, 755).")
        }
    }
    
    private func loadProperties() {
        do {
            let attrs = try FileManager.default.attributesOfItem(atPath: item.url.path)
            if let type = attrs[.type] as? FileAttributeType {
                switch type {
                case .typeRegular: fileType = "Regular File"
                case .typeDirectory: fileType = "Directory"
                case .typeSymbolicLink: fileType = "Symbolic Link"
                default: fileType = "Other"
                }
            }
            if let d = attrs[.modificationDate] as? Date { modDate = d }
            if let p = attrs[.posixPermissions] as? NSNumber {
                permissions = String(format: "%o", p.intValue)
            }
            
            if !item.isDirectory {
                totalSize = item.size
            }
        } catch { permissions = "Unavailable" }
    }
    
    private func savePermissions() {
        guard let mode = Int(newPermInput, radix: 8) else { return }
        try? service.updatePermissions(item.url, mode: mode)
        loadProperties()
        NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
    }

    private func compute() {
        working = true
        let url = item.url
        Task {
            let result = await Task.detached {
                HashAlgorithm.allCases.compactMap { algo in
                    (try? HashService.hash(url, algo)).map { (algo, $0) }
                }
            }.value
            hashes = result
            working = false
        }
    }
}
