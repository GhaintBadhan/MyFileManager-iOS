import SwiftUI

struct PlistViewerView: View {
    let item: FileItem
    @Environment(\.dismiss) var dismiss
    
    @State private var content: String = ""
    @State private var isLoading = true
    @State private var errorMessage: String?
    
    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Parsing Plist...")
                } else if let error = errorMessage {
                    ContentUnavailableView("Error", systemImage: "exclamationmark.triangle", description: Text(error))
                } else {
                    ScrollView {
                        Text(content)
                            .font(.system(.body, design: .monospaced))
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .textSelection(.enabled)
                    }
                }
            }
            .navigationTitle(item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear(perform: loadPlist)
        }
    }
    
    private func loadPlist() {
        do {
            let data = try Data(contentsOf: item.url)
            
            // Parse the plist (handles both XML and Binary formats)
            var format = PropertyListSerialization.PropertyListFormat.xml
            if let plist = try PropertyListSerialization.propertyList(from: data, options: [], format: &format) as? [String: Any] {
                
                // Convert to JSON for pretty printing
                if let jsonData = try? JSONSerialization.data(withJSONObject: plist, options: [.prettyPrinted, .sortedKeys]),
                   let jsonString = String(data: jsonData, encoding: .utf8) {
                    self.content = jsonString
                } else {
                    self.content = String(describing: plist)
                }
            } else {
                throw NSError(domain: "Plist", code: 1, userInfo: [NSLocalizedDescriptionKey: "Invalid plist format."])
            }
            isLoading = false
        } catch {
            errorMessage = error.localizedDescription
            isLoading = false
        }
    }
}
