import SwiftUI

struct HexViewerView: View {
    let url: URL
    @State private var data = Data()
    @State private var originalData = Data()
    @State private var message: String?
    private let bytesPerRow = 8
    
    @State private var editingOffset: Int? = nil
    @State private var newByteString = ""

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Tap any byte to edit it").font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button("Save") { save() }.disabled(data == originalData)
            }
            .padding(.horizontal).padding(.vertical, 8)

            if let message = message {
                Text(message).foregroundStyle(.red).padding()
                Spacer()
            } else {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 4) {
                        ForEach(0..<((data.count + bytesPerRow - 1) / bytesPerRow), id: \.self) { row in
                            HStack(spacing: 0) {
                                Text(String(format: "%08X  ", row * bytesPerRow)).font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
                                ForEach(0..<bytesPerRow, id: \.self) { col in
                                    let offset = row * bytesPerRow + col
                                    if offset < data.count {
                                        let byte = data[offset]
                                        Text(String(format: "%02X", byte))
                                            .font(.system(size: 11, design: .monospaced))
                                            .foregroundStyle(byte == 0 ? .secondary : .primary)
                                            .padding(.horizontal, 1)
                                            .background(editingOffset == offset ? Color.blue.opacity(0.5) : Color.clear)
                                            .cornerRadius(2)
                                            .onTapGesture {
                                                editingOffset = offset
                                                newByteString = String(format: "%02X", byte)
                                            }
                                    } else { Text("  ").font(.system(size: 11, design: .monospaced)) }
                                }
                                Text("  ")
                                ForEach(0..<bytesPerRow, id: \.self) { col in
                                    let offset = row * bytesPerRow + col
                                    if offset < data.count {
                                        let byte = data[offset]
                                        Text(String(byte >= 32 && byte < 127 ? Character(UnicodeScalar(byte)) : "."))
                                            .font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
            }
        }
        .onAppear {
            do { data = try Data(contentsOf: url); originalData = data }
            catch { message = error.localizedDescription }
        }
        .alert("Edit Byte", isPresented: Binding(get: { editingOffset != nil }, set: { if !$0 { editingOffset = nil } })) {
            TextField("Hex (e.g. FF)", text: $newByteString).textInputAutocapitalization(.characters).autocorrectionDisabled()
            Button("Update") { applyEdit() }
            Button("Cancel", role: .cancel) { editingOffset = nil }
        } message: { if let offset = editingOffset { Text("Offset: \(String(format: "%08X", offset))") } }
    }

    private func applyEdit() {
        guard let offset = editingOffset, let newByte = UInt8(newByteString, radix: 16) else { return }
        data[offset] = newByte
        editingOffset = nil
    }

    private func save() {
        do { try data.write(to: url); originalData = data }
        catch { message = "Failed to save: \(error.localizedDescription)" }
    }
}
