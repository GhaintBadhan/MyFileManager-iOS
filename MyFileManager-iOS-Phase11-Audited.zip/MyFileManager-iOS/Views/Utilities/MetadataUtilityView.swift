import SwiftUI

struct MetadataUtilityView: View {
    let item: FileItem
    @Environment(\.dismiss) private var dismiss
    @State private var rows: [MetadataRow] = []
    @State private var formattedText = ""
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var savedMessage: String?

    private var isImage: Bool {
        ["jpg", "jpeg", "png", "heic", "tiff", "gif"].contains(item.url.pathExtension.lowercased())
    }

    private var isStructuredText: Bool {
        ["json", "xml", "plist"].contains(item.url.pathExtension.lowercased())
    }

    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Reading…")
                } else if let errorMessage {
                    ContentUnavailableView("Utility Error", systemImage: "exclamationmark.triangle", description: Text(errorMessage))
                } else if isImage {
                    List(rows) { row in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(row.key).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                            Text(row.value).font(.body).textSelection(.enabled)
                        }
                        .padding(.vertical, 3)
                    }
                } else if isStructuredText {
                    TextEditor(text: $formattedText)
                        .font(.system(.body, design: .monospaced))
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
            }
            .navigationTitle(item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    if isImage {
                        Button("Remove EXIF") { removeMetadata() }
                    } else if isStructuredText {
                        Button("Save") { saveFormatted() }
                    }
                }
            }
            .task { await load() }
            .alert("Saved", isPresented: Binding(get: { savedMessage != nil }, set: { if !$0 { savedMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(savedMessage ?? "") }
        }
    }

    private func load() async {
        do {
            if isImage {
                rows = try await Task.detached(priority: .utility) {
                    try MetadataUtilityService.imageMetadata(at: item.url)
                }.value
            } else if isStructuredText {
                formattedText = try await Task.detached(priority: .utility) {
                    try MetadataUtilityService.formattedText(at: item.url)
                }.value
            } else {
                throw MetadataUtilityError.unsupported
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func removeMetadata() {
        do {
            try MetadataUtilityService.removeImageMetadata(at: item.url)
            savedMessage = "Image metadata was removed and the file was replaced safely."
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
            Task { await load() }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func saveFormatted() {
        do {
            try MetadataUtilityService.saveFormatted(formattedText, to: item.url)
            savedMessage = "Formatted content saved."
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
