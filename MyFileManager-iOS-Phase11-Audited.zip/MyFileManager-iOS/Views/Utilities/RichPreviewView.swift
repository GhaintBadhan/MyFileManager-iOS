import SwiftUI
import WebKit

struct RichPreviewView: View {
    let url: URL
    @State private var markdownContent: AttributedString?
    
    var body: some View {
        Group {
            if url.pathExtension.lowercased() == "md" {
                // Render Markdown natively
                if let content = markdownContent {
                    ScrollView {
                        Text(content)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else {
                    ProgressView("Rendering Markdown...")
                }
            } else {
                // Render HTML in a WebView
                WebView(url: url)
            }
        }
        .onAppear {
            if url.pathExtension.lowercased() == "md" {
                loadMarkdown()
            }
        }
    }
    
    private func loadMarkdown() {
        Task.detached {
            do {
                let rawText = try String(contentsOf: url, encoding: .utf8)
                // Use Apple's native Markdown parser
                let parsed = try AttributedString(markdown: rawText)
                await MainActor.run {
                    self.markdownContent = parsed
                }
            } catch {
                await MainActor.run {
                    self.markdownContent = AttributedString("Failed to load Markdown.")
                }
            }
        }
    }
}

// Native WKWebView for HTML rendering
struct WebView: UIViewRepresentable {
    let url: URL
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear
        
        // Allow local file access
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
