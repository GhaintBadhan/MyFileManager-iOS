import SwiftUI
import UIKit

struct TextEditorView: View {
    let url: URL
    @Binding var isEditing: Bool

    private static let maxBytes: Int64 = 4_000_000
    private static let encodings: [(String, String.Encoding)] = [
        ("UTF-8", .utf8), ("UTF-16", .utf16), ("Latin-1", .isoLatin1), ("ASCII", .ascii)
    ]

    @State private var text = ""
    @State private var original = ""
    @State private var encoding: String.Encoding = .utf8
    @State private var encodingName = "UTF-8"
    @State private var message: String?
    @State private var showFindReplace = false
    @State private var findText = ""
    @State private var replaceText = ""
    @State private var showGoToLine = false
    @State private var goToLineText = "1"
    @State private var requestedLine: Int?
    @State private var draftTask: Task<Void, Never>?

    var body: some View {
        VStack(spacing: 0) {
            if isEditing {
                HStack(spacing: 12) {
                    Picker("Encoding", selection: $encodingName) {
                        ForEach(Self.encodings, id: \.0) { Text($0.0).tag($0.0) }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: encodingName) { _, newValue in
                        if let selected = Self.encodings.first(where: { $0.0 == newValue })?.1 {
                            encoding = selected
                            load(preferredEncoding: selected)
                        }
                    }
                    Spacer()
                    Button { showGoToLine = true } label: { Image(systemName: "number") }
                    Button { showFindReplace.toggle() } label: { Image(systemName: "magnifyingglass") }
                }
                .padding(.horizontal)
                .padding(.vertical, 8)

                if showFindReplace {
                    HStack {
                        TextField("Find", text: $findText)
                            .textFieldStyle(.roundedBorder)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                        TextField("Replace", text: $replaceText)
                            .textFieldStyle(.roundedBorder)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                        Button("Replace All") { replaceAll() }
                            .buttonStyle(.bordered)
                            .disabled(findText.isEmpty)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 8)
                }
            }

            if let message {
                Text(message).font(.callout).foregroundStyle(.secondary).padding()
                Spacer()
            } else {
                CodeTextView(text: $text, isEditable: isEditing, requestedLine: $requestedLine)
                    .background(Color(uiColor: .systemBackground))
            }
        }
        .onAppear { load() }
        .onDisappear { draftTask?.cancel() }
        .onChange(of: isEditing) { _, newValue in
            if !newValue && text != original { save() }
            if newValue { scheduleDraftSave() }
        }
        .onChange(of: text) { _, _ in
            guard isEditing else { return }
            scheduleDraftSave()
        }
        .alert("Go to Line", isPresented: $showGoToLine) {
            TextField("Line number", text: $goToLineText).keyboardType(.numberPad)
            Button("Go") {
                requestedLine = max(1, Int(goToLineText) ?? 1)
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Enter a line number between 1 and the end of the file.")
        }
    }

    private func load(preferredEncoding: String.Encoding? = nil) {
        message = nil
        guard let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize,
              Int64(size) <= Self.maxBytes else {
            message = "File is too large for the text editor (limit: 4 MB). Use a preview or hex tool instead."
            return
        }
        do {
            let data = try Data(contentsOf: url, options: .mappedIfSafe)
            let detected = preferredEncoding ?? Self.detectEncoding(data)
            guard let loaded = String(data: data, encoding: detected) else {
                message = "This file could not be decoded as text. Try another encoding or use a binary preview."
                return
            }
            encoding = detected
            encodingName = Self.encodings.first(where: { $0.1 == detected })?.0 ?? "UTF-8"
            original = loaded
            let fileDate = (try? url.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
            text = DraftStore.recoveredText(for: url, newerThan: fileDate) ?? loaded
            if text != loaded { message = "Recovered an unsaved draft. Save to replace the file." }
        } catch {
            message = error.localizedDescription
        }
    }

    private func save() {
        do {
            let temporary = url.deletingLastPathComponent().appendingPathComponent(".\(url.lastPathComponent).tmp-\(UUID().uuidString)")
            try text.write(to: temporary, atomically: true, encoding: encoding)
            _ = try FileManager.default.replaceItemAt(url, withItemAt: temporary, backupItemName: nil, options: .usingNewMetadataOnly)
            original = text
            DraftStore.remove(for: url)
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch {
            message = "Save failed: \(error.localizedDescription)"
        }
    }

    private func replaceAll() {
        guard !findText.isEmpty else { return }
        text = text.replacingOccurrences(of: findText, with: replaceText)
    }

    private func scheduleDraftSave() {
        draftTask?.cancel()
        let draftText = text
        draftTask = Task {
            try? await Task.sleep(nanoseconds: 900_000_000)
            guard !Task.isCancelled else { return }
            DraftStore.save(draftText, for: url, encoding: encoding)
        }
    }

    private static func detectEncoding(_ data: Data) -> String.Encoding {
        if data.starts(with: [0xEF, 0xBB, 0xBF]) { return .utf8 }
        if data.starts(with: [0xFF, 0xFE]) || data.starts(with: [0xFE, 0xFF]) { return .utf16 }
        if String(data: data, encoding: .utf8) != nil { return .utf8 }
        return .isoLatin1
    }
}

private enum DraftStore {
    private static var directory: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let folder = base.appendingPathComponent("EditorDrafts", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        return folder
    }

    private static func draftURL(for url: URL) -> URL {
        let key = Data(url.path.utf8).base64EncodedString().replacingOccurrences(of: "/", with: "_")
        return directory.appendingPathComponent(key).appendingPathExtension("draft")
    }

    static func save(_ text: String, for url: URL, encoding _: String.Encoding) {
        try? text.write(to: draftURL(for: url), atomically: true, encoding: .utf8)
    }

    static func recoveredText(for url: URL, newerThan: Date) -> String? {
        let draft = draftURL(for: url)
        guard let draftDate = try? draft.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate,
              draftDate > newerThan else { return nil }
        return try? String(contentsOf: draft, encoding: .utf8)
    }

    static func remove(for url: URL) {
        try? FileManager.default.removeItem(at: draftURL(for: url))
    }
}

struct CodeTextView: UIViewRepresentable {
    @Binding var text: String
    var isEditable: Bool
    @Binding var requestedLine: Int?

    func makeUIView(context: Context) -> LineNumberTextView {
        let textView = LineNumberTextView()
        textView.font = UIFont.monospacedSystemFont(ofSize: 13, weight: .regular)
        textView.autocapitalizationType = .none
        textView.autocorrectionType = .no
        textView.smartQuotesType = .no
        textView.smartDashesType = .no
        textView.backgroundColor = .clear
        textView.delegate = context.coordinator
        textView.isEditable = isEditable
        textView.text = text
        return textView
    }

    func updateUIView(_ uiView: LineNumberTextView, context: Context) {
        uiView.isEditable = isEditable
        if uiView.text != text { uiView.text = text }
        if let requestedLine {
            uiView.scrollToLine(requestedLine)
            DispatchQueue.main.async { self.requestedLine = nil }
        }
        uiView.setNeedsDisplay()
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: CodeTextView
        init(_ parent: CodeTextView) { self.parent = parent }
        func textViewDidChange(_ textView: UITextView) {
            parent.text = textView.text
            textView.setNeedsDisplay()
        }
    }
}

final class LineNumberTextView: UITextView {
    private let gutterWidth: CGFloat = 44

    override func layoutSubviews() {
        super.layoutSubviews()
        if textContainerInset.left != gutterWidth { textContainerInset.left = gutterWidth }
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else { return }
        context.setFillColor(UIColor.secondarySystemBackground.withAlphaComponent(0.7).cgColor)
        context.fill(CGRect(x: 0, y: 0, width: gutterWidth, height: bounds.height))

        let visibleRect = CGRect(x: 0, y: contentOffset.y, width: bounds.width, height: bounds.height)
        let glyphRange = layoutManager.glyphRange(forBoundingRect: visibleRect, in: textContainer)
        var lineNumber = 1
        if glyphRange.location > 0 {
            let prefix = (text as NSString).substring(with: NSRange(location: 0, length: min(glyphRange.location, text.utf16.count)))
            lineNumber += prefix.reduce(0) { $1 == "\n" ? $0 + 1 : $0 }
        }
        layoutManager.enumerateLineFragments(forGlyphRange: glyphRange) { rect, _, _, _, _ in
            let y = rect.minY - self.contentOffset.y + self.textContainerInset.top
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.monospacedSystemFont(ofSize: 11, weight: .regular),
                .foregroundColor: UIColor.secondaryLabel
            ]
            NSString(string: "\(lineNumber)").draw(at: CGPoint(x: 8, y: y + 1), withAttributes: attributes)
            lineNumber += 1
        }
    }

    func scrollToLine(_ line: Int) {
        let lines = (text as NSString).components(separatedBy: "\n")
        let target = min(max(line - 1, 0), max(lines.count - 1, 0))
        var location = 0
        for index in 0..<target { location += (lines[index] as NSString).length + 1 }
        let range = NSRange(location: min(location, text.utf16.count), length: 0)
        scrollRangeToVisible(range)
        selectedRange = range
    }
}
