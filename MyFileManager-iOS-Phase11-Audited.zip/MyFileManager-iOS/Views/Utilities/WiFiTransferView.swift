import SwiftUI
import CoreImage.CIFilterBuiltins

struct WiFiTransferView: View {
    let rootURL: URL
    @Environment(\.dismiss) var dismiss
    @State private var server = WiFiServer()
    @State private var isRunning = false
    @State private var ipAddress = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()
                
                Image(systemName: "wifi.router.fill")
                    .font(.system(size: 70))
                    .foregroundStyle(isRunning ? .blue : .gray)
                
                if isRunning {
                    VStack(spacing: 12) {
                        Text("Server is Running")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text("Scan this QR code or type the address below into your computer's browser:")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                        
                        // 🔥 NEW: QR Code
                        if let qrImage = generateQRCode(from: "http://\(ipAddress):8080") {
                            Image(uiImage: qrImage)
                                .interpolation(.none)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200, height: 200)
                                .padding()
                                .background(Color.white)
                                .cornerRadius(16)
                                .shadow(radius: 5)
                        }
                        
                        Text("http://\(ipAddress):8080")
                            .font(.system(.title3, design: .monospaced))
                            .fontWeight(.bold)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(8)
                            .textSelection(.enabled)
                        
                        Text("Make sure your computer and iPhone are connected to the same Wi-Fi network.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                    }
                } else {
                    Text("Start a local server to transfer files from your PC to your iPhone without any cables.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 30)
                }
                
                Spacer()
                
                Button {
                    if isRunning {
                        server.stop()
                        isRunning = false
                    } else {
                        server.rootDirectory = rootURL
                        server.onStatusChange = { running, ip in
                            isRunning = running
                            ipAddress = ip
                        }
                        server.start()
                    }
                } label: {
                    Text(isRunning ? "Stop Server" : "Start Server")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(isRunning ? Color.red : Color.blue)
                        .cornerRadius(12)
                }
                .padding(.horizontal, 30)
                .padding(.bottom, 30)
            }
            .navigationTitle("Wi-Fi Transfer")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                Button("Done") { 
                    server.stop()
                    dismiss() 
                }
            }
            .onDisappear {
                server.stop()
            }
        }
    }
    
    // 🔥 NEW: Generate QR Code
    private func generateQRCode(from string: String) -> UIImage? {
        let context = CIContext()
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        
        if let outputImage = filter.outputImage {
            if let cgImage = context.createCGImage(outputImage, from: outputImage.extent) {
                return UIImage(cgImage: cgImage)
            }
        }
        return nil
    }
}
