import SwiftUI

struct DataUtilityView: View {
    let item: FileItem
    @Environment(\.dismiss) private var dismiss
    @State private var csv: CSVData?
    @State private var font: FontInfo?
    @State private var tables: [SQLiteTable] = []
    @State private var isLoading = true
    @State private var errorMessage: String?

    private var ext: String { item.url.pathExtension.lowercased() }
    private var isCSV: Bool { ext == "csv" || ext == "tsv" }
    private var isFont: Bool { ["ttf", "otf", "woff", "woff2"].contains(ext) }

    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Reading…")
                } else if let errorMessage {
                    ContentUnavailableView("Utility Error", systemImage: "exclamationmark.triangle", description: Text(errorMessage))
                } else if isCSV, let csv {
                    csvView(csv)
                } else if isFont, let font {
                    fontView(font)
                } else {
                    sqliteView
                }
            }
            .navigationTitle(item.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } } }
            .task { await load() }
        }
    }

    private func csvView(_ data: CSVData) -> some View {
        ScrollView([.horizontal, .vertical]) {
            LazyVStack(alignment: .leading, spacing: 0) {
                rowView(data.headers, isHeader: true)
                ForEach(Array(data.rows.enumerated()), id: \.offset) { _, row in rowView(row, isHeader: false) }
            }
            .font(.caption.monospaced())
            .padding()
        }
    }

    private func rowView(_ row: [String], isHeader: Bool) -> some View {
        HStack(spacing: 0) {
            ForEach(Array(row.enumerated()), id: \.offset) { _, value in
                Text(value.isEmpty ? " " : value)
                    .frame(width: 150, alignment: .leading)
                    .padding(6)
                    .background(isHeader ? Color.accentColor.opacity(0.15) : Color.clear)
                    .overlay(alignment: .trailing) { Divider() }
            }
        }
        .fontWeight(isHeader ? .semibold : .regular)
        .overlay(alignment: .bottom) { Divider() }
    }

    private func fontView(_ font: FontInfo) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                LabeledContent("Family", value: font.familyName)
                LabeledContent("Style", value: font.styleName)
                LabeledContent("PostScript name", value: font.postScriptName)
                Divider()
                Text("Aa Bb Cc 0123")
                    .font(.custom(font.postScriptName, size: 34))
                Text("The quick brown fox jumps over the lazy dog.")
                    .font(.custom(font.postScriptName, size: 22))
            }
            .padding()
        }
    }

    private var sqliteView: some View {
        List {
            ForEach(tables) { table in
                Section(table.name) {
                    if table.rows.isEmpty {
                        Text("No rows").foregroundStyle(.secondary)
                    } else {
                        ForEach(Array(table.rows.enumerated()), id: \.offset) { _, row in
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(Array(row.enumerated()), id: \.offset) { index, value in
                                    Text("\(index < table.columns.count ? table.columns[index] : "Column"): \(value)")
                                        .font(.caption.monospaced())
                                        .textSelection(.enabled)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
        }
        .overlay {
            if tables.isEmpty { ContentUnavailableView("No Tables", systemImage: "tablecells") }
        }
    }

    private func load() async {
        do {
            if isCSV {
                csv = try await Task.detached(priority: .utility) { try DataUtilityService.parseCSV(at: item.url) }.value
            } else if isFont {
                font = try await Task.detached(priority: .utility) { try DataUtilityService.fontInfo(at: item.url) }.value
            } else {
                tables = try await Task.detached(priority: .utility) { try DataUtilityService.sqliteTables(at: item.url) }.value
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}
