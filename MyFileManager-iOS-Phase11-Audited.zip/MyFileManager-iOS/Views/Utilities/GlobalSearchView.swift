import SwiftUI

struct SearchOptions: Sendable {
    var recursive = true
    var includeContent = true
    var caseSensitive = false
    var regularExpression = false
    var includeHidden = false
    var extensionFilter = ""
    var minimumSizeMB = ""
    var maximumSizeMB = ""

    var extensions: Set<String> {
        Set(extensionFilter
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().replacingOccurrences(of: ".", with: "") }
            .filter { !$0.isEmpty })
    }

    var minimumBytes: Int64? {
        guard let value = Double(minimumSizeMB), value > 0 else { return nil }
        return Int64(value * 1_000_000)
    }

    var maximumBytes: Int64? {
        guard let value = Double(maximumSizeMB), value > 0 else { return nil }
        return Int64(value * 1_000_000)
    }
}

struct SearchResult: Identifiable {
    let id: URL
    let item: FileItem
    let matchedInContent: Bool
    let snippet: String?
}

struct GlobalSearchView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("recentSearchesJSON") private var recentSearchesJSON = "[]"

    @State private var searchText = ""
    @State private var results: [SearchResult] = []
    @State private var isSearching = false
    @State private var showFilters = false
    @State private var options = SearchOptions()
    @State private var searchTask: Task<Void, Never>?

    private var recentSearches: [String] {
        guard let data = recentSearchesJSON.data(using: .utf8),
              let decoded = try? JSONDecoder().decode([String].self, from: data) else { return [] }
        return decoded
    }

    var body: some View {
        NavigationStack {
            List {
                if showFilters { filterSection }
                if searchText.isEmpty && !recentSearches.isEmpty {
                    Section("Recent Searches") {
                        ForEach(recentSearches, id: \.self) { query in
                            Button {
                                searchText = query
                                debounceSearch(query: query)
                            } label: {
                                Label(query, systemImage: "clock.arrow.circlepath")
                            }
                        }
                    }
                }
                if isSearching {
                    HStack { Spacer(); ProgressView("Searching…"); Spacer() }
                } else if results.isEmpty && !searchText.trimmingCharacters(in: .whitespaces).isEmpty {
                    ContentUnavailableView.search(text: searchText)
                } else {
                    Section(results.isEmpty ? nil : "\(results.count) Results") {
                        ForEach(results) { result in
                            NavigationLink { destinationView(for: result.item) } label: {
                                HStack(spacing: 12) {
                                    ThumbnailView(url: result.item.url, fallbackIcon: result.item.iconName, fallbackColor: result.item.iconColor)
                                        .frame(width: 36, height: 36)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(result.item.name).font(.body).lineLimit(1)
                                        if let snippet = result.snippet {
                                            Text(snippet).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                        } else {
                                            Text(parentPath(for: result.item.url)).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                        }
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Search")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search files and content…")
            .onChange(of: searchText) { _, newValue in debounceSearch(query: newValue) }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showFilters.toggle() } label: {
                        Image(systemName: showFilters ? "line.3.horizontal.decrease.circle.fill" : "line.3.horizontal.decrease.circle")
                    }
                }
                ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } }
            }
        }
        .onDisappear { searchTask?.cancel() }
    }

    private var filterSection: some View {
        Section("Search Options") {
            Toggle("Search subfolders", isOn: $options.recursive)
            Toggle("Search inside text files", isOn: $options.includeContent)
            Toggle("Case sensitive", isOn: $options.caseSensitive)
            Toggle("Regular expression", isOn: $options.regularExpression)
            Toggle("Include hidden files", isOn: $options.includeHidden)
            TextField("Extensions: pdf, swift, json", text: $options.extensionFilter)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            HStack {
                TextField("Minimum MB", text: $options.minimumSizeMB).keyboardType(.decimalPad)
                TextField("Maximum MB", text: $options.maximumSizeMB).keyboardType(.decimalPad)
            }
            Button("Apply Filters") { debounceSearch(query: searchText) }
                .disabled(searchText.trimmingCharacters(in: .whitespaces).isEmpty)
        }
    }

    private func debounceSearch(query: String) {
        searchTask?.cancel()
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            results = []
            isSearching = false
            return
        }

        isSearching = true
        let currentOptions = options
        searchTask = Task {
            try? await Task.sleep(nanoseconds: 300_000_000)
            guard !Task.isCancelled else { return }
            let found = await performSearch(query: trimmed, options: currentOptions)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                results = found
                isSearching = false
                saveRecent(trimmed)
            }
        }
    }

    private func performSearch(query: String, options: SearchOptions) async -> [SearchResult] {
        await Task.detached(priority: .userInitiated) {
            let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            return Self.searchDirectory(at: docs, query: query, options: options)
        }.value
    }

    nonisolated private static func searchDirectory(at url: URL, query: String, options: SearchOptions) -> [SearchResult] {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.isDirectoryKey, .isHiddenKey, .fileSizeKey]
        let directoryOptions: FileManager.DirectoryEnumerationOptions = options.includeHidden ? [] : [.skipsHiddenFiles]
        let urls: [URL]
        if options.recursive {
            urls = fm.enumerator(at: url, includingPropertiesForKeys: keys, options: directoryOptions)?.compactMap { $0 as? URL } ?? []
        } else {
            urls = (try? fm.contentsOfDirectory(at: url, includingPropertiesForKeys: keys, options: directoryOptions)) ?? []
        }

        let allowedExtensions = options.extensions
        let textExtensions = Set(["txt", "md", "json", "swift", "html", "css", "js", "xml", "plist", "csv"])
        var found: [SearchResult] = []
        found.reserveCapacity(min(urls.count, 100))

        for (index, itemURL) in urls.enumerated() {
            if index.isMultiple(of: 32) && Task.isCancelled { break }
            guard let values = try? itemURL.resourceValues(forKeys: Set(keys)) else { continue }
            let isDirectory = values.isDirectory ?? false
            let size = Int64(values.fileSize ?? 0)
            let ext = itemURL.pathExtension.lowercased()
            if !allowedExtensions.isEmpty && !allowedExtensions.contains(ext) { continue }
            if let minimum = options.minimumBytes, size < minimum { continue }
            if let maximum = options.maximumBytes, size > maximum { continue }

            let nameMatch = matches(itemURL.lastPathComponent, query: query, options: options)
            var contentMatch = false
            var snippet: String?
            if !isDirectory && !nameMatch && options.includeContent && textExtensions.contains(ext) && size <= 1_000_000 {
                if let content = try? String(contentsOf: itemURL, encoding: .utf8),
                   matches(content, query: query, options: options) {
                    contentMatch = true
                    snippet = makeSnippet(content: content, query: query, options: options)
                }
            }

            if nameMatch || contentMatch {
                found.append(SearchResult(id: itemURL, item: FileItem(url: itemURL), matchedInContent: contentMatch, snippet: snippet))
                if found.count >= 500 { break }
            }
        }
        return found
    }

    nonisolated private static func matches(_ value: String, query: String, options: SearchOptions) -> Bool {
        if options.regularExpression {
            let regexOptions: NSRegularExpression.Options = options.caseSensitive ? [] : [.caseInsensitive]
            guard let regex = try? NSRegularExpression(pattern: query, options: regexOptions) else { return false }
            let range = NSRange(value.startIndex..<value.endIndex, in: value)
            return regex.firstMatch(in: value, range: range) != nil
        }
        if options.caseSensitive { return value.contains(query) }
        return value.localizedCaseInsensitiveContains(query)
    }

    nonisolated private static func makeSnippet(content: String, query: String, options: SearchOptions) -> String? {
        guard !options.regularExpression,
              let range = content.range(of: query, options: options.caseSensitive ? [] : [.caseInsensitive]) else { return nil }
        let start = content.index(range.lowerBound, offsetBy: -30, limitedBy: content.startIndex) ?? content.startIndex
        let end = content.index(range.upperBound, offsetBy: 50, limitedBy: content.endIndex) ?? content.endIndex
        return "…" + content[start..<end].trimmingCharacters(in: .whitespacesAndNewlines) + "…"
    }

    private func saveRecent(_ query: String) {
        var values = recentSearches.filter { $0 != query }
        values.insert(query, at: 0)
        values = Array(values.prefix(10))
        if let data = try? JSONEncoder().encode(values), let string = String(data: data, encoding: .utf8) {
            recentSearchesJSON = string
        }
    }

    @ViewBuilder
    private func destinationView(for item: FileItem) -> some View {
        let ext = item.url.pathExtension.lowercased()
        let isImage = ["png", "jpg", "jpeg", "gif", "webp", "heic"].contains(ext)
        let isMedia = ["mp4", "mov", "mkv", "avi", "m4v", "mp3", "wav", "m4a", "flac"].contains(ext)
        if item.isDirectory { BrowserView(url: item.url) }
        else if isImage { MediaGalleryView(items: [item], startIndex: 0).navigationBarHidden(true) }
        else if isMedia { MediaPlayerView(url: item.url) }
        else { FileDetailView(item: item) }
    }

    private func parentPath(for url: URL) -> String {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let parent = url.deletingLastPathComponent().path
        if parent == docs.path { return "Documents" }
        return parent.replacingOccurrences(of: docs.path, with: "Documents")
    }
}
