import SwiftUI
import QuickLook
import UniformTypeIdentifiers

struct FileDetailView: View {
    let item: FileItem
    @State private var isEditing = false
    @State private var showHex = false
    @State private var showMetadataUtility = false
    @State private var showDataUtility = false

    init(item: FileItem) {
        self.item = item
    }

    var body: some View {
        VStack(spacing: 0) {
            if showHex {
                HexViewerView(url: item.url)
            } else if isEditing {
                // 🔥 Edit Mode (Only for text/web files)
                TextEditorView(url: item.url, isEditing: $isEditing)
            } else {
                // 🔥 Preview Mode
                if isWebFile() {
                    RichPreviewView(url: item.url)
                } else if isTextFile() {
                    // Read-only text view
                    TextEditorView(url: item.url, isEditing: $isEditing)
                } else {
                    // Standard QuickLook for images, PDFs, videos, etc.
                    QuickLookView(url: item.url)
                }
            }
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            // 🔥 The elegant toolbar
            ToolbarItemGroup(placement: .topBarTrailing) {
                // Show Edit button if the file is text/web
                if isTextFile() || isWebFile() {
                    if !showHex {
                        Button(isEditing ? "Done" : "Edit") {
                            withAnimation { isEditing.toggle() }
                        }
                        .fontWeight(isEditing ? .bold : .regular)
                    }
                }
                
                // Hex toggle button
                Button {
                    withAnimation { showHex.toggle() }
                } label: {
                    Image(systemName: showHex ? "doc.text" : "number")
                }
                if isImageFile() || isStructuredFile() {
                    Button { showMetadataUtility = true } label: {
                        Image(systemName: isImageFile() ? "camera.aperture" : "text.alignleft")
                    }
                }
                if isCSVFile() || isFontFile() || isSQLiteFile() {
                    Button { showDataUtility = true } label: {
                        Image(systemName: isCSVFile() ? "tablecells" : isFontFile() ? "textformat" : "cylinder.split.1x2")
                    }
                }
            }
        }
        .sheet(isPresented: $showMetadataUtility) {
            MetadataUtilityView(item: item)
        }
        .sheet(isPresented: $showDataUtility) {
            DataUtilityView(item: item)
        }
    }
    
    private func isTextFile() -> Bool {
        let ext = item.url.pathExtension.lowercased()
        return UTType(filenameExtension: ext)?.conforms(to: .text) ?? false
    }
    
    private func isWebFile() -> Bool {
        let ext = item.url.pathExtension.lowercased()
        return ["html", "htm", "md"].contains(ext)
    }

    private func isImageFile() -> Bool {
        ["jpg", "jpeg", "png", "heic", "tiff", "gif"].contains(item.url.pathExtension.lowercased())
    }

    private func isStructuredFile() -> Bool {
        ["json", "xml", "plist"].contains(item.url.pathExtension.lowercased())
    }

    private func isCSVFile() -> Bool {
        ["csv", "tsv"].contains(item.url.pathExtension.lowercased())
    }

    private func isFontFile() -> Bool {
        ["ttf", "otf", "woff", "woff2"].contains(item.url.pathExtension.lowercased())
    }

    private func isSQLiteFile() -> Bool {
        ["sqlite", "sqlite3", "db"].contains(item.url.pathExtension.lowercased())
    }
}

struct QuickLookView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> QLPreviewController {
        let c = QLPreviewController()
        c.dataSource = context.coordinator
        return c
    }
    func updateUIViewController(_ vc: QLPreviewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(url: url) }

    final class Coordinator: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
            url as NSURL
        }
    }
}
