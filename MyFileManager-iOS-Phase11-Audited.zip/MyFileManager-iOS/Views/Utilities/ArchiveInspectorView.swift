import SwiftUI

struct ArchiveInspectorView: View {
    let item: FileItem
    @Environment(\.dismiss) private var dismiss
    @State private var files: [String] = []
    @State private var selection = Set<String>()
    @State private var isLoading = true
    @State private var errorMessage: String?
    @State private var extractedMessage: String?
    @State private var editMode: EditMode = .inactive
    @State private var searchText = ""

    private var visibleFiles: [String] {
        guard !searchText.isEmpty else { return files }
        return files.filter { $0.localizedCaseInsensitiveContains(searchText) }
    }

    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Reading Archive…")
                } else if let errorMessage {
                    ContentUnavailableView("Archive Error", systemImage: "exclamationmark.triangle", description: Text(errorMessage))
                } else if files.isEmpty {
                    ContentUnavailableView("Empty Archive", systemImage: "archivebox")
                } else {
                    List(selection: $selection) {
                        Section("\(files.count) entries") {
                            ForEach(visibleFiles, id: \.self) { file in
                                HStack {
                                    Image(systemName: file.hasSuffix("/") ? "folder" : "doc")
                                        .foregroundStyle(file.hasSuffix("/") ? .blue : .secondary)
                                    Text(file).font(.system(.body, design: .monospaced)).lineLimit(1)
                                }
                                .tag(file)
                                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                    if !file.hasSuffix("/") {
                                        Button { extractFiles([file]) } label: {
                                            Label("Extract", systemImage: "arrow.down.doc")
                                        }
                                        .tint(.blue)
                                    }
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .environment(\.editMode, $editMode)
            .navigationTitle(item.name)
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $searchText, prompt: "Filter archive entries")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    if !files.isEmpty {
                        Button { extractAll() } label: { Image(systemName: "arrow.down.doc") }
                        if !selection.isEmpty {
                            Button { extractFiles(Array(selection)) } label: {
                                Label("Extract Selected", systemImage: "checkmark.circle")
                            }
                        }
                        EditButton()
                    }
                }
            }
            .task { await loadContents() }
            .alert("Extraction Complete", isPresented: Binding(get: { extractedMessage != nil }, set: { if !$0 { extractedMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(extractedMessage ?? "")
            }
        }
    }

    private func loadContents() async {
        do {
            let loaded = try await Task.detached(priority: .utility) {
                try ArchiveService.listContents(item.url)
            }.value
            files = loaded
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func extractAll() {
        let destination = item.url.deletingLastPathComponent()
        do {
            try ArchiveService.extract(item.url, to: destination)
            extractedMessage = "Extracted all archive entries to \(destination.lastPathComponent)."
            selection.removeAll()
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func extractFiles(_ paths: [String]) {
        let destination = item.url.deletingLastPathComponent()
        do {
            try ArchiveService.extractSpecific(item.url, filePaths: paths, to: destination)
            extractedMessage = "Extracted \(paths.count) selected entr\(paths.count == 1 ? "y" : "ies") to \(destination.lastPathComponent)."
            selection.removeAll()
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
