import SwiftUI

struct DownloadsView: View {
    @ObservedObject var manager = DownloadManager.shared
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            Group {
                if manager.activeDownloads.isEmpty {
                    ContentUnavailableView("No Downloads", systemImage: "arrow.down.circle", description: Text("Files downloaded from the browser will appear here."))
                } else {
                    List {
                        ForEach(manager.activeDownloads) { download in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Image(systemName: download.isFailed ? "xmark.circle.fill" : (download.isFinished ? "checkmark.circle.fill" : "arrow.down.circle.fill"))
                                        .foregroundStyle(download.isFailed ? .red : (download.isFinished ? .green : .blue))
                                    
                                    Text(download.fileName)
                                        .font(.subheadline)
                                        .lineLimit(1)
                                    
                                    Spacer()
                                    
                                    if !download.isFinished {
                                        Button {
                                            manager.cancelDownload(id: download.id)
                                        } label: {
                                            Image(systemName: "xmark.circle.fill").foregroundStyle(.gray)
                                        }
                                    }
                                }
                                
                                if !download.isFinished {
                                    ProgressView(value: download.progress)
                                        .tint(.blue)
                                    
                                    // 🔥 NEW: Detailed Status Row
                                    HStack {
                                        Text(formatBytes(download.downloadedBytes) + " of " + formatBytes(download.totalBytes))
                                        
                                        Spacer()
                                        
                                        Text(formatSpeed(download.speedBytesPerSecond))
                                            .foregroundStyle(.blue)
                                    }
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .monospacedDigit()
                                    
                                } else if download.isFailed {
                                    Text(download.failureReason ?? "Failed to download")
                                        .font(.caption).foregroundStyle(.red)
                                } else {
                                    Text("Saved to Documents • \(formatBytes(download.totalBytes))")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("Downloads")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
    
    // Helper to format bytes (e.g., 10.5 MB)
    private func formatBytes(_ bytes: Int64) -> String {
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowedUnits = [.useAll]
        return formatter.string(fromByteCount: bytes)
    }
    
    // Helper to format speed (e.g., 2.4 MB/s)
    private func formatSpeed(_ bytesPerSecond: Double) -> String {
        guard bytesPerSecond > 0 else { return "--- MB/s" }
        let formatter = ByteCountFormatter()
        formatter.countStyle = .file
        formatter.allowedUnits = [.useMB, .useKB]
        return formatter.string(fromByteCount: Int64(bytesPerSecond)) + "/s"
    }
}
