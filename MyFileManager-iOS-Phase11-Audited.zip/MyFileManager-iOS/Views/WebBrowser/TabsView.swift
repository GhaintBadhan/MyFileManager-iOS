import SwiftUI

struct TabsView: View {
    @ObservedObject var manager = BrowserManager.shared
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 16)], spacing: 16) {
                    ForEach(Array(manager.tabs.enumerated()), id: \.element.id) { index, tab in
                        VStack(alignment: .leading) {
                            HStack {
                                Text(tab.title).font(.caption).fontWeight(.semibold).lineLimit(1)
                                Spacer()
                                Button { 
                                    manager.closeTab(at: index)
                                } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                            }.padding(8)
                            
                            Spacer()
                            
                            // 🔥 NEW: Show the webpage snapshot
                            if let snapshot = tab.snapshot {
                                Image(uiImage: snapshot)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 80)
                                    .clipped()
                            } else {
                                Color(UIColor.tertiarySystemBackground)
                                    .frame(height: 80)
                                    .overlay(ProgressView())
                            }
                            
                            Text(tab.webView.url?.host ?? "Web")
                                .font(.caption2).foregroundStyle(.secondary)
                                .padding(.horizontal, 8).padding(.bottom, 8)
                        }
                        .frame(height: 140)
                        .background(index == manager.activeTabIndex ? Color.blue.opacity(0.2) : Color(UIColor.secondarySystemBackground))
                        .cornerRadius(12)
                        .overlay(RoundedRectangle(cornerRadius: 12).stroke(index == manager.activeTabIndex ? Color.blue : Color.clear, lineWidth: 2))
                        .onTapGesture { 
                            manager.activeTabIndex = index
                            dismiss() 
                        }
                    }
                }.padding()
            }
            .navigationTitle("Tabs").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { 
                        BrowserManager.shared.addTab(url: URL(string: "https://www.google.com")!)
                        dismiss()
                    } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
            }
        }
    }
}
