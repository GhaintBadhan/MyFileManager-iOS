import SwiftUI
import WebKit

struct WebBrowserView: View {
    let downloadDirectory: URL
    @Environment(\.dismiss) var dismiss
    
    @ObservedObject var manager = BrowserManager.shared
    
    @State private var showTabs = false
    @State private var showDownloads = false
    @State private var showShareSheet = false
    @State private var inputURL: String = ""
    
    @State private var pendingDownloadURL: URL?
    @State private var showDownloadPrompt = false
    @State private var currentReferer: String = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if manager.activeTab.isLoading {
                    ProgressView(value: manager.activeTab.estimatedProgress).progressViewStyle(.linear).tint(.blue)
                }
                
                WebViewWrapper(tab: manager.activeTab, downloadDirectory: downloadDirectory, pendingDownloadURL: $pendingDownloadURL, showDownloadPrompt: $showDownloadPrompt, currentReferer: $currentReferer)
                    .id(manager.activeTab.id)
                
                BrowserToolbarView(
                    tab: manager.activeTab,
                    tabCount: manager.tabs.count,
                    onShowDownloads: { showDownloads = true },
                    onShowTabs: { showTabs = true },
                    onShowShare: { showShareSheet = true }
                )
            }
            .safeAreaInset(edge: .top) {
                HStack {
                    TextField("Search or enter website", text: $inputURL)
                        .textFieldStyle(.roundedBorder).keyboardType(.URL).autocapitalization(.none).autocorrectionDisabled()
                        .onSubmit {
                            if let url = URL(string: inputURL.hasPrefix("http") ? inputURL : "https://\(inputURL)") {
                                manager.activeTab.webView.load(URLRequest(url: url))
                            }
                        }
                }
                .padding().background(.ultraThinMaterial)
            }
            .navigationTitle(manager.activeTab.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
            .sheet(isPresented: $showDownloads) { DownloadsView() }
            .sheet(isPresented: $showTabs, onDismiss: nil) {
                TabsView()
                    .onAppear { for tab in manager.tabs { tab.takeSnapshot() } }
            }
            .sheet(isPresented: $showShareSheet) {
                // This now uses the ShareSheet from ShareSheet.swift
                if let url = manager.activeTab.webView.url { ShareSheet(items: [url]) }
            }
            .alert("Download File?", isPresented: $showDownloadPrompt) {
                Button("Download") {
                    if let url = pendingDownloadURL {
                        DownloadManager.shared.startDownload(url: url, referer: currentReferer)
                        showDownloads = true
                    }
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text(pendingDownloadURL?.lastPathComponent ?? "Do you want to download this file?")
            }
            .onAppear {
                if inputURL.isEmpty {
                    inputURL = manager.activeTab.webView.url?.absoluteString ?? manager.activeTab.urlString
                    currentReferer = manager.activeTab.webView.url?.absoluteString ?? ""
                }
            }
            .onChange(of: manager.activeTabIndex) { _, _ in 
                inputURL = manager.activeTab.webView.url?.absoluteString ?? manager.activeTab.urlString 
                currentReferer = manager.activeTab.webView.url?.absoluteString ?? ""
            }
            .onChange(of: manager.activeTab.webView.url) { _, newURL in
                if let url = newURL?.absoluteString { inputURL = url; currentReferer = url }
            }
        }
    }
}

struct BrowserToolbarView: View {
    @ObservedObject var tab: BrowserTab
    let tabCount: Int
    
    let onShowDownloads: () -> Void
    let onShowTabs: () -> Void
    let onShowShare: () -> Void
    
    var body: some View {
        HStack {
            Button { tab.webView.goBack() } label: { Image(systemName: "chevron.left").font(.title3) }
                .disabled(!tab.canGoBack)
            
            Spacer()
            
            Button { tab.webView.goForward() } label: { Image(systemName: "chevron.right").font(.title3) }
                .disabled(!tab.canGoForward)
            
            Spacer()
            
            Button { tab.webView.reload() } label: { Image(systemName: "arrow.clockwise").font(.title3) }
            
            Spacer()
            
            Button { onShowShare() } label: { Image(systemName: "square.and.arrow.up").font(.title3) }
            
            Spacer()
            
            Button { onShowDownloads() } label: {
                Image(systemName: "arrow.down.circle").font(.title3)
                    .overlay(
                        Circle().fill(Color.red).frame(width: 8, height: 8)
                            .offset(x: 8, y: -8)
                            .opacity(DownloadManager.shared.activeDownloads.isEmpty ? 0 : 1)
                    )
            }
            
            Spacer()
            
            Button { onShowTabs() } label: {
                Image(systemName: "square.on.square").font(.title3)
                    .overlay(Text("\(tabCount)").font(.caption2).bold().foregroundStyle(.white).padding(4).background(Circle().fill(Color.red)).offset(x: 10, y: -10))
            }
        }
        .padding(.horizontal, 20).padding(.vertical, 12).background(.ultraThinMaterial)
    }
}

struct WebViewWrapper: UIViewRepresentable {
    let tab: BrowserTab
    let downloadDirectory: URL
    @Binding var pendingDownloadURL: URL?
    @Binding var showDownloadPrompt: Bool
    @Binding var currentReferer: String
    
    func makeUIView(context: Context) -> WKWebView {
        tab.webView.navigationDelegate = context.coordinator
        tab.webView.uiDelegate = context.coordinator
        tab.webView.allowsBackForwardNavigationGestures = true
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(context.coordinator, action: #selector(Coordinator.handleRefresh(_:)), for: .valueChanged)
        tab.webView.scrollView.refreshControl = refreshControl
        context.coordinator.webView = tab.webView
        
        context.coordinator.observe(tab)
        
        if tab.webView.url == nil, let url = URL(string: tab.urlString) {
            tab.webView.load(URLRequest(url: url))
        }
        return tab.webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(pendingDownloadURL: $pendingDownloadURL, showDownloadPrompt: $showDownloadPrompt, currentReferer: $currentReferer) }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        @Binding var pendingDownloadURL: URL?
        @Binding var showDownloadPrompt: Bool
        @Binding var currentReferer: String
        
        var webView: WKWebView?
        private var observers: [NSKeyValueObservation] = []
        
        init(pendingDownloadURL: Binding<URL?>, showDownloadPrompt: Binding<Bool>, currentReferer: Binding<String>) {
            self._pendingDownloadURL = pendingDownloadURL
            self._showDownloadPrompt = showDownloadPrompt
            self._currentReferer = currentReferer
        }
        
        @objc func handleRefresh(_ refreshControl: UIRefreshControl) { webView?.reload() }
        
        func observe(_ tab: BrowserTab) {
            observers.append(tab.webView.observe(\.title) { [weak tab] webView, _ in DispatchQueue.main.async { tab?.title = webView.title ?? "New Tab" } })
            observers.append(tab.webView.observe(\.estimatedProgress) { [weak tab] webView, _ in DispatchQueue.main.async { tab?.estimatedProgress = webView.estimatedProgress } })
            observers.append(tab.webView.observe(\.canGoBack) { [weak tab] webView, _ in DispatchQueue.main.async { tab?.canGoBack = webView.canGoBack } })
            observers.append(tab.webView.observe(\.canGoForward) { [weak tab] webView, _ in DispatchQueue.main.async { tab?.canGoForward = webView.canGoForward } })
            observers.append(tab.webView.observe(\.isLoading) { [weak tab] webView, _ in DispatchQueue.main.async { tab?.isLoading = webView.isLoading } })
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else { decisionHandler(.allow); return }
            let ext = url.pathExtension.lowercased()
            let downloadExts = ["zip", "tar", "gz", "pdf", "mp4", "mov", "mp3", "ipa", "apk", "png", "jpg", "jpeg", "dmg", "exe", "dylib", "deb", "7z", "rar"]
            
            if downloadExts.contains(ext) || navigationAction.shouldPerformDownload {
                decisionHandler(.cancel)
                self.pendingDownloadURL = url
                self.showDownloadPrompt = true
                return
            }
            decisionHandler(.allow)
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            if !navigationResponse.canShowMIMEType {
                if let url = navigationResponse.response.url {
                    decisionHandler(.cancel)
                    self.pendingDownloadURL = url
                    self.showDownloadPrompt = true
                    return
                }
            }
            decisionHandler(.allow)
        }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                DispatchQueue.main.async { BrowserManager.shared.addTab(url: url) }
            }
            return nil
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { webView.scrollView.refreshControl?.endRefreshing() }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { webView.scrollView.refreshControl?.endRefreshing() }
    }
}
