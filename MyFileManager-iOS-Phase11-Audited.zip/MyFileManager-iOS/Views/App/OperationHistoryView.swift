import SwiftUI

struct OperationHistoryView: View {
    @ObservedObject var operationQueue: FileOperationQueue
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if operationQueue.records.isEmpty {
                    ContentUnavailableView("No Operations", systemImage: "checkmark.circle", description: Text("Completed transfers will appear here."))
                } else {
                    ForEach(operationQueue.records.reversed()) { record in
                        HStack(spacing: 12) {
                            Image(systemName: icon(for: record.state))
                                .foregroundStyle(color(for: record.state))
                                .frame(width: 24)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("\(record.kind.rawValue) \(record.sourceCount) item\(record.sourceCount == 1 ? "" : "s")")
                                    .font(.body.weight(.medium))
                                Text(record.destination.path)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                if let error = record.errorMessage {
                                    Text(error).font(.caption).foregroundStyle(.red).lineLimit(2)
                                }
                            }
                            Spacer()
                            Text(label(for: record.state))
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(color(for: record.state))
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("Operation History")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Clear") { operationQueue.removeFinished() }
                        .disabled(operationQueue.records.allSatisfy { $0.state == .queued || $0.state == .running })
                }
            }
        }
    }

    private func label(for state: FileOperationRecord.State) -> String {
        switch state {
        case .queued: return "Queued"
        case .running: return "Running"
        case .finished: return "Done"
        case .failed: return "Failed"
        case .cancelled: return "Cancelled"
        }
    }

    private func icon(for state: FileOperationRecord.State) -> String {
        switch state {
        case .queued: return "clock"
        case .running: return "arrow.triangle.2.circlepath"
        case .finished: return "checkmark.circle.fill"
        case .failed: return "exclamationmark.triangle.fill"
        case .cancelled: return "xmark.circle.fill"
        }
    }

    private func color(for state: FileOperationRecord.State) -> Color {
        switch state {
        case .queued, .running: return .blue
        case .finished: return .green
        case .failed: return .red
        case .cancelled: return .secondary
        }
    }
}
