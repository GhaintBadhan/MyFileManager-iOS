import SwiftUI

struct SettingsView: View {
    // Storage & Privacy
    @AppStorage("isHiddenSpaceEnabled") private var isHiddenSpaceEnabled = true
    @AppStorage("trashRetentionDays") private var trashRetentionDays = 30
    
    // Network & Tools
    @AppStorage("isWiFiServerEnabled") private var isWiFiServerEnabled = true
    @AppStorage("isCompressionEnabled") private var isCompressionEnabled = true
    @AppStorage("isSplitMergeEnabled") private var isSplitMergeEnabled = true
    @AppStorage("isEncryptionEnabled") private var isEncryptionEnabled = true
    @AppStorage("isImageResizeEnabled") private var isImageResizeEnabled = true
    @AppStorage("isPDFToolsEnabled") private var isPDFToolsEnabled = true
    @AppStorage("isBatchRenameEnabled") private var isBatchRenameEnabled = true
    
    var body: some View {
        Form {
            // MARK: - Privacy & Security
            Section {
                Toggle(isOn: $isHiddenSpaceEnabled) {
                    Label {
                        Text("Hidden Space")
                    } icon: {
                        SettingsIcon(systemName: "eye.slash.fill", color: .purple)
                    }
                }
                
                Stepper(value: $trashRetentionDays, in: 1...90) {
                    Label {
                        HStack {
                            Text("Keep Deleted Files")
                            Spacer()
                            Text("\(trashRetentionDays) Days")
                                .foregroundStyle(.secondary)
                        }
                    } icon: {
                        SettingsIcon(systemName: "trash.fill", color: .red)
                    }
                }
            } header: {
                Text("Privacy & Storage")
            } footer: {
                Text("Files in 'Recently Deleted' older than this will be permanently removed.")
            }
            
            // MARK: - Network
            Section {
                Toggle(isOn: $isWiFiServerEnabled) {
                    Label {
                        Text("Wi-Fi File Server")
                    } icon: {
                        SettingsIcon(systemName: "wifi", color: .blue)
                    }
                }
            } header: {
                Text("Network")
            } footer: {
                Text("Allows you to transfer files to and from your PC using a web browser.")
            }
            
            // MARK: - File Utilities
            Section {
                Toggle(isOn: $isCompressionEnabled) {
                    Label {
                        Text("Archive & Compression")
                    } icon: {
                        SettingsIcon(systemName: "archivebox.fill", color: .brown)
                    }
                }
                
                Toggle(isOn: $isEncryptionEnabled) {
                    Label {
                        Text("AES-256 Encryption")
                    } icon: {
                        SettingsIcon(systemName: "lock.shield.fill", color: .green)
                    }
                }
                
                Toggle(isOn: $isSplitMergeEnabled) {
                    Label {
                        Text("Split & Merge Files")
                    } icon: {
                        SettingsIcon(systemName: "arrow.triangle.branch", color: .orange)
                    }
                }
                
                Toggle(isOn: $isBatchRenameEnabled) {
                    Label {
                        Text("Batch Rename")
                    } icon: {
                        SettingsIcon(systemName: "pencil.circle.fill", color: .blue)
                    }
                }
            } header: {
                Text("File Utilities")
            } footer: {
                Text("Turn off features you don't use to keep the context menus clean.")
            }
            
            // MARK: - Media Tools
            Section {
                Toggle(isOn: $isPDFToolsEnabled) {
                    Label {
                        Text("PDF Toolkit")
                    } icon: {
                        SettingsIcon(systemName: "doc.text.fill", color: .red)
                    }
                }
                
                Toggle(isOn: $isImageResizeEnabled) {
                    Label {
                        Text("Image Resizer")
                    } icon: {
                        SettingsIcon(systemName: "arrow.down.right.and.arrow.up.left", color: .pink)
                    }
                }
            } header: {
                Text("Media Tools")
            }
            
            // MARK: - Storage
            Section {
                Button {
                    ThumbnailCache.shared.removeAllObjects()
                    let impact = UINotificationFeedbackGenerator()
                    impact.notificationOccurred(.success)
                } label: {
                    Label {
                        Text("Clear Thumbnail Cache")
                            .foregroundStyle(.red)
                    } icon: {
                        SettingsIcon(systemName: "trash.fill", color: .red)
                    }
                }
            } header: {
                Text("Storage")
            } footer: {
                Text("Frees up memory if the app is feeling slow. Thumbnails will be regenerated automatically.")
            }
            
            // MARK: - About
            Section {
                LabeledContent {
                    Text("1.0.0").foregroundStyle(.secondary)
                } label: {
                    Label {
                        Text("Version")
                    } icon: {
                        SettingsIcon(systemName: "info.circle.fill", color: .gray)
                    }
                }
                
                LabeledContent {
                    Text("MyFileManager").foregroundStyle(.secondary)
                } label: {
                    Label {
                        Text("App Name")
                    } icon: {
                        SettingsIcon(systemName: "app.fill", color: .blue)
                    }
                }
            } header: {
                Text("About")
            }
        }
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.inline)
    }
}
