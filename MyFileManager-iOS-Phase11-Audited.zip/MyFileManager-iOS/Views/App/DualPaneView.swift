import SwiftUI

/// MT Manager-style root layout. Each side owns its own BrowserView navigation
/// stack, so opening a folder in one side never changes the other side.
struct DualPaneView: View {
    enum Pane: String, CaseIterable, Hashable {
        case left = "Left"
        case right = "Right"
    }

    let documentsURL: URL
    let trashURL: URL
    let hiddenURL: URL

    @State private var leftURL: URL
    @State private var rightURL: URL
    @State private var leftHistory: [URL]
    @State private var rightHistory: [URL]
    @State private var leftHistoryIndex = 0
    @State private var rightHistoryIndex = 0
    @State private var historyNavigationInProgress = Set<Pane>()
    @State private var leftPaneID = UUID()
    @State private var rightPaneID = UUID()
    @State private var selectedPane: Pane = .left
    @State private var showSettings = false
    @State private var showSearch = false
    @State private var showWiFi = false
    @State private var showWebDAV = false
    @State private var showBrowser = false
    @State private var showDownloads = false
    @State private var showOperationHistory = false
    @State private var showCompare = false
    @State private var compareLeftURL: URL?
    @State private var compareRightURL: URL?
    @State private var leftSelection = Set<URL>()
    @State private var rightSelection = Set<URL>()
    @StateObject private var operationQueue = FileOperationQueue.shared
    @AppStorage("navigationBookmarksJSON") private var navigationBookmarksJSON = "[]"

    init(documentsURL: URL, trashURL: URL, hiddenURL: URL) {
        self.documentsURL = documentsURL
        self.trashURL = trashURL
        self.hiddenURL = hiddenURL
        _leftURL = State(initialValue: documentsURL)
        _rightURL = State(initialValue: documentsURL)
        _leftHistory = State(initialValue: [documentsURL])
        _rightHistory = State(initialValue: [documentsURL])
    }

    var body: some View {
        GeometryReader { proxy in
            let isWide = proxy.size.width >= 700
            Group {
                if isWide {
                    HStack(spacing: 0) {
                        pane(.left)
                        Divider()
                        pane(.right)
                    }
                } else {
                    VStack(spacing: 0) {
                        phonePanePicker
                        pane(selectedPane)
                    }
                }
            }
            .background(Color(uiColor: .systemGroupedBackground))
            .toolbar { rootToolbar(isWide: isWide) }
            .safeAreaInset(edge: .bottom) { transferBar }
            .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("BrowserNavigationChanged"))) { notification in
                guard let event = notification.object as? BrowserNavigationEvent else { return }
                recordNavigation(event)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .sheet(isPresented: $showSettings) {
                NavigationStack { SettingsView() }
            }
            .sheet(isPresented: $showSearch) { GlobalSearchView() }
            .sheet(isPresented: $showWiFi) { WiFiTransferView(rootURL: documentsURL) }
            .sheet(isPresented: $showWebDAV) { WebDAVView() }
            .sheet(isPresented: $showBrowser) { WebBrowserView(downloadDirectory: documentsURL) }
            .sheet(isPresented: $showDownloads) { DownloadsView() }
            .sheet(isPresented: $showOperationHistory) {
                OperationHistoryView(operationQueue: operationQueue)
            }
            .sheet(isPresented: $showCompare) {
                if let compareLeftURL, let compareRightURL {
                    CompareView(leftURL: compareLeftURL, rightURL: compareRightURL)
                }
            }
            .confirmationDialog(
                "File Already Exists",
                isPresented: Binding(
                    get: { operationQueue.conflictRequest != nil },
                    set: { isPresented in
                        if !isPresented { operationQueue.resolveConflict(.skip) }
                    }
                ),
                titleVisibility: .visible
            ) {
                Button("Replace") { operationQueue.resolveConflict(.replace) }
                Button("Skip") { operationQueue.resolveConflict(.skip) }
                Button("Rename Automatically") { operationQueue.resolveConflict(.rename) }
                Button("Replace All") { operationQueue.resolveConflict(.replace, applyToAll: true) }
                Button("Skip All") { operationQueue.resolveConflict(.skip, applyToAll: true) }
                Button("Rename All") { operationQueue.resolveConflict(.rename, applyToAll: true) }
                Button("Cancel", role: .cancel) { operationQueue.resolveConflict(.skip) }
            } message: {
                if let request = operationQueue.conflictRequest {
                    Text("\(request.sourceName) is already in \(request.destination.lastPathComponent).")
                }
            }
        }
    }

    @ViewBuilder
    private func pane(_ pane: Pane) -> some View {
        let url = pane == .left ? leftURL : rightURL
        let paneID = pane == .left ? leftPaneID : rightPaneID
        NavigationStack {
            VStack(spacing: 0) {
                PaneHeader(
                    title: pane.rawValue,
                    url: url,
                    isActive: selectedPane == pane,
                    canGoBack: canGoBack(pane),
                    canGoForward: canGoForward(pane),
                    onActivate: { selectedPane = pane },
                    onBack: { goBack(pane) },
                    onForward: { goForward(pane) },
                    onParent: { navigate(to: url.deletingLastPathComponent(), in: pane) },
                    onBookmark: { addBookmark(url) },
                    onHome: { setURL(documentsURL, for: pane) },
                    onSwap: { swapPanes() }
                )
                BrowserView(url: url, paneID: paneID) { selection in
                    if pane == .left { leftSelection = selection }
                    else { rightSelection = selection }
                    selectedPane = pane
                }
            }
            .navigationBarTitleDisplayMode(.inline)
        }
        .id(url)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .overlay {
            RoundedRectangle(cornerRadius: 10)
                .stroke(selectedPane == pane ? Color.accentColor.opacity(0.65) : .clear, lineWidth: 2)
                .padding(1)
                .allowsHitTesting(false)
        }
        .contentShape(Rectangle())
        .onTapGesture { selectedPane = pane }
    }

    @ViewBuilder
    private var transferBar: some View {
        let selection = selectedPane == .left ? leftSelection : rightSelection
        if !selection.isEmpty || !operationQueue.activeRecords.isEmpty {
            VStack(spacing: 8) {
                if let operation = operationQueue.activeRecords.first {
                    HStack(spacing: 8) {
                        ProgressView(value: operation.progress).tint(.accentColor)
                        Text("\(operation.kind.rawValue) \(operation.completedCount)/\(operation.sourceCount)")
                            .font(.caption.weight(.semibold))
                        if !operation.currentName.isEmpty {
                            Text(operation.currentName)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                                .lineLimit(1)
                        }
                        Button { operationQueue.cancel(operation.id) } label: {
                            Image(systemName: "xmark.circle.fill")
                        }
                        .buttonStyle(.plain)
                    }
                }
                if !selection.isEmpty {
                    HStack(spacing: 10) {
                        Text("\(selection.count) selected")
                            .font(.caption.weight(.semibold))
                        Spacer()
                        Button { transfer(selection, move: false) } label: {
                            Label("Copy", systemImage: "doc.on.doc")
                        }
                        .buttonStyle(.borderedProminent)
                        Button { transfer(selection, move: true) } label: {
                            Label("Move", systemImage: "arrow.right")
                        }
                        .buttonStyle(.bordered)
                        if canCompare {
                            Button { beginCompare() } label: {
                                Label("Compare", systemImage: "arrow.left.arrow.right")
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(.bar)
            .overlay(alignment: .top) { Divider() }
        }
    }

    private var phonePanePicker: some View {
        Picker("Active pane", selection: $selectedPane) {
            ForEach(Pane.allCases, id: \.self) { Text($0.rawValue).tag($0) }
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
        .padding(.vertical, 8)
        .background(.bar)
    }

    @ToolbarContentBuilder
    private func rootToolbar(isWide: Bool) -> some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button { showSearch = true } label: { Image(systemName: "magnifyingglass") }
        }
        ToolbarItem(placement: .principal) {
            Label("My FileManager", systemImage: "square.split.2x1.fill")
                .font(.headline)
        }
        ToolbarItemGroup(placement: .topBarTrailing) {
            Menu {
                Button { setURL(documentsURL, for: selectedPane) } label: { Label("Documents", systemImage: "folder") }
                Button { setURL(trashURL, for: selectedPane) } label: { Label("Recently Deleted", systemImage: "trash") }
                Button { setURL(hiddenURL, for: selectedPane) } label: { Label("Hidden Space", systemImage: "eye.slash") }
                Button { addBookmark(selectedPane == .left ? leftURL : rightURL) } label: { Label("Bookmark Current Folder", systemImage: "bookmark") }
                if !bookmarkURLs.isEmpty {
                    Menu("Bookmarks") {
                        ForEach(bookmarkURLs, id: \.path) { bookmark in
                            Button(bookmark.lastPathComponent.isEmpty ? "/" : bookmark.lastPathComponent) {
                                setURL(bookmark, for: selectedPane)
                            }
                        }
                    }
                }
                Divider()
                Button { swapPanes() } label: { Label("Swap Panes", systemImage: "arrow.left.arrow.right") }
                Button { syncPanes() } label: { Label("Sync Other Pane", systemImage: "arrow.triangle.2.circlepath") }
                Button { showOperationHistory = true } label: { Label("Operation History", systemImage: "clock.arrow.circlepath") }
                if canCompare {
                    Button { beginCompare() } label: { Label("Compare Selected", systemImage: "arrow.left.arrow.right") }
                }
                Divider()
                Button { showBrowser = true } label: { Label("Web Browser", systemImage: "globe") }
                Button { showDownloads = true } label: { Label("Downloads", systemImage: "arrow.down.circle") }
                Button { showWebDAV = true } label: { Label("WebDAV", systemImage: "server.rack") }
                Button { showWiFi = true } label: { Label("Wi-Fi Transfer", systemImage: "wifi") }
            } label: {
                Image(systemName: "ellipsis.circle")
            }
            Button { showSettings = true } label: { Image(systemName: "gearshape") }
        }
    }

    private var bookmarkURLs: [URL] {
        guard let data = navigationBookmarksJSON.data(using: .utf8),
              let paths = try? JSONDecoder().decode([String].self, from: data) else { return [] }
        return paths.map(URL.init(fileURLWithPath:))
    }

    private func addBookmark(_ url: URL) {
        var paths = bookmarkURLs.map(\.path)
        guard !paths.contains(url.path) else { return }
        paths.append(url.path)
        if let data = try? JSONEncoder().encode(paths), let string = String(data: data, encoding: .utf8) {
            navigationBookmarksJSON = string
        }
    }

    private func setURL(_ url: URL, for pane: Pane) {
        navigate(to: url, in: pane)
        selectedPane = pane
    }

    private func canGoBack(_ pane: Pane) -> Bool {
        pane == .left ? leftHistoryIndex > 0 : rightHistoryIndex > 0
    }

    private func canGoForward(_ pane: Pane) -> Bool {
        if pane == .left { return leftHistoryIndex + 1 < leftHistory.count }
        return rightHistoryIndex + 1 < rightHistory.count
    }

    private func navigate(to url: URL, in pane: Pane) {
        guard url.path != "/" || url.isFileURL else { return }
        if pane == .left {
            if leftHistory.last != url {
                leftHistory = Array(leftHistory.prefix(leftHistoryIndex + 1))
                leftHistory.append(url)
                leftHistoryIndex = leftHistory.count - 1
            }
            leftURL = url
        } else {
            if rightHistory.last != url {
                rightHistory = Array(rightHistory.prefix(rightHistoryIndex + 1))
                rightHistory.append(url)
                rightHistoryIndex = rightHistory.count - 1
            }
            rightURL = url
        }
    }

    private func recordNavigation(_ event: BrowserNavigationEvent) {
        let pane: Pane?
        if event.paneID == leftPaneID { pane = .left }
        else if event.paneID == rightPaneID { pane = .right }
        else { pane = nil }
        guard let pane else { return }

        if historyNavigationInProgress.remove(pane) != nil {
            if pane == .left { leftURL = event.url }
            else { rightURL = event.url }
            return
        }
        navigate(to: event.url, in: pane)
    }

    private func goBack(_ pane: Pane) {
        guard canGoBack(pane) else { return }
        if pane == .left {
            leftHistoryIndex -= 1
            historyNavigationInProgress.insert(.left)
            leftURL = leftHistory[leftHistoryIndex]
        } else {
            rightHistoryIndex -= 1
            historyNavigationInProgress.insert(.right)
            rightURL = rightHistory[rightHistoryIndex]
        }
    }

    private func goForward(_ pane: Pane) {
        guard canGoForward(pane) else { return }
        if pane == .left {
            leftHistoryIndex += 1
            historyNavigationInProgress.insert(.left)
            leftURL = leftHistory[leftHistoryIndex]
        } else {
            rightHistoryIndex += 1
            historyNavigationInProgress.insert(.right)
            rightURL = rightHistory[rightHistoryIndex]
        }
    }

    private func transfer(_ urls: Set<URL>, move: Bool) {
        let destination = selectedPane == .left ? rightURL : leftURL
        let source = Array(urls)
        if move {
            operationQueue.enqueueMove(source, to: destination)
        } else {
            operationQueue.enqueueCopy(source, to: destination)
        }
        if selectedPane == .left { leftSelection.removeAll() }
        else { rightSelection.removeAll() }
    }

    private var canCompare: Bool {
        leftSelection.count == 1 && rightSelection.count == 1
    }

    private func beginCompare() {
        guard let left = leftSelection.first, let right = rightSelection.first else { return }
        compareLeftURL = left
        compareRightURL = right
        showCompare = true
    }

    private func syncPanes() {
        if selectedPane == .left { navigate(to: leftURL, in: .right) }
        else { navigate(to: rightURL, in: .left) }
        leftSelection.removeAll()
        rightSelection.removeAll()
    }

    private func swapPanes() {
        let oldLeft = leftURL
        leftURL = rightURL
        rightURL = oldLeft
        let oldLeftHistory = leftHistory
        leftHistory = rightHistory
        rightHistory = oldLeftHistory
        let oldLeftIndex = leftHistoryIndex
        leftHistoryIndex = rightHistoryIndex
        rightHistoryIndex = oldLeftIndex
        let oldLeftSelection = leftSelection
        leftSelection = rightSelection
        rightSelection = oldLeftSelection
        selectedPane = selectedPane == .left ? .right : .left
        HapticManager.shared.impact()
    }
}

private struct PaneHeader: View {
    let title: String
    let url: URL
    let isActive: Bool
    let canGoBack: Bool
    let canGoForward: Bool
    let onActivate: () -> Void
    let onBack: () -> Void
    let onForward: () -> Void
    let onParent: () -> Void
    let onBookmark: () -> Void
    let onHome: () -> Void
    let onSwap: () -> Void

    var body: some View {
        HStack(spacing: 8) {
            Button(action: onActivate) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.caption.weight(.semibold)).foregroundStyle(isActive ? .blue : .secondary)
                    Text(url.lastPathComponent.isEmpty ? "/" : url.lastPathComponent)
                        .font(.subheadline.weight(.medium)).lineLimit(1)
                    Text(url.path).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                }
            }
            .buttonStyle(.plain)
            Spacer(minLength: 4)
            Button(action: onBack) { Image(systemName: "chevron.left") }.disabled(!canGoBack)
            Button(action: onForward) { Image(systemName: "chevron.right") }.disabled(!canGoForward)
            Button(action: onParent) { Image(systemName: "arrow.turn.up.left") }
            Button(action: onBookmark) { Image(systemName: "bookmark") }
            Button(action: onHome) { Image(systemName: "house") }
            Button(action: onSwap) { Image(systemName: "arrow.left.arrow.right") }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(.bar)
        .overlay(alignment: .bottom) {
            Rectangle().fill(isActive ? Color.accentColor : .clear).frame(height: 2)
        }
    }
}
