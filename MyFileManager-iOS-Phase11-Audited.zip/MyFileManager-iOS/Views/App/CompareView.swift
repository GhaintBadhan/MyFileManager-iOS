import SwiftUI

struct CompareView: View {
    let leftURL: URL
    let rightURL: URL
    @Environment(\.dismiss) private var dismiss
    @State private var result: ComparisonResult?
    @State private var errorMessage: String?
    @State private var isLoading = true

    var body: some View {
        NavigationStack {
            Group {
                if isLoading {
                    ProgressView("Comparing…")
                } else if let errorMessage {
                    ContentUnavailableView("Comparison Failed", systemImage: "exclamationmark.triangle", description: Text(errorMessage))
                } else if let result {
                    resultView(result)
                }
            }
            .navigationTitle("Compare")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
            }
        }
        .task {
            do {
                result = try await Task.detached(priority: .userInitiated) {
                    try CompareService.compare(leftURL, rightURL)
                }.value
            } catch {
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }

    @ViewBuilder
    private func resultView(_ result: ComparisonResult) -> some View {
        switch result {
        case .text(let differences):
            textComparison(differences)
        case .folder(let differences):
            folderComparison(differences)
        case .binary(let comparison):
            binaryComparison(comparison)
        }
    }

    private func textComparison(_ differences: [TextDifference]) -> some View {
        ScrollView([.vertical, .horizontal]) {
            LazyVStack(spacing: 0) {
                HStack {
                    Text(leftURL.lastPathComponent).font(.caption.weight(.semibold))
                    Spacer()
                    Text(rightURL.lastPathComponent).font(.caption.weight(.semibold))
                }
                .padding(10)
                ForEach(differences) { difference in
                    HStack(alignment: .top, spacing: 1) {
                        lineCell(difference.left, number: difference.lineNumber, side: .left, kind: difference.kind)
                        lineCell(difference.right, number: difference.lineNumber, side: .right, kind: difference.kind)
                    }
                }
            }
            .frame(minWidth: 680)
        }
    }

    private enum Side: Equatable { case left, right }

    private func lineCell(_ text: String?, number: Int, side: Side, kind: TextDifference.Kind) -> some View {
        let color: Color
        switch kind {
        case .same: color = .clear
        case .changed: color = .yellow.opacity(0.22)
        case .leftOnly: color = side == .left ? .red.opacity(0.18) : .clear
        case .rightOnly: color = side == .right ? .green.opacity(0.18) : .clear
        }
        return HStack(alignment: .top, spacing: 8) {
            Text("\(number)").font(.caption2.monospacedDigit()).foregroundStyle(.secondary).frame(width: 36, alignment: .trailing)
            Text(text ?? "").font(.caption.monospaced()).frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
        }
        .padding(.vertical, 4)
        .padding(.horizontal, 6)
        .background(color)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func folderComparison(_ differences: [FolderDifference]) -> some View {
        List {
            Section("\(differences.count) entries compared") {
                ForEach(differences) { difference in
                    HStack(spacing: 10) {
                        Image(systemName: icon(for: difference.kind)).foregroundStyle(color(for: difference.kind))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(difference.path).lineLimit(1)
                            Text(sizeSummary(difference)).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                }
            }
        }
    }

    private func binaryComparison(_ comparison: BinaryComparison) -> some View {
        Form {
            Section("Result") {
                LabeledContent("Status", value: comparison.isEqual ? "Identical" : "Different")
                LabeledContent("Left size", value: ByteCountFormatter.string(fromByteCount: comparison.leftSize, countStyle: .file))
                LabeledContent("Right size", value: ByteCountFormatter.string(fromByteCount: comparison.rightSize, countStyle: .file))
            }
            Section("SHA-256") {
                Text(comparison.leftHash).font(.caption.monospaced()).textSelection(.enabled)
                Text(comparison.rightHash).font(.caption.monospaced()).textSelection(.enabled)
            }
        }
    }

    private func sizeSummary(_ difference: FolderDifference) -> String {
        let left = difference.leftSize.map { $0 < 0 ? "Folder" : ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) } ?? "Missing"
        let right = difference.rightSize.map { $0 < 0 ? "Folder" : ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) } ?? "Missing"
        return "Left: \(left)  •  Right: \(right)"
    }

    private func icon(for kind: FolderDifference.Kind) -> String {
        switch kind {
        case .same: return "equal.circle"
        case .changed: return "arrow.left.arrow.right.circle"
        case .leftOnly: return "minus.circle"
        case .rightOnly: return "plus.circle"
        }
    }

    private func color(for kind: FolderDifference.Kind) -> Color {
        switch kind {
        case .same: return .secondary
        case .changed: return .orange
        case .leftOnly: return .red
        case .rightOnly: return .green
        }
    }
}
