import SwiftUI

struct ContextMenuView: View {
    let item: FileItem
    @ObservedObject var vm: BrowserViewModel
    let clipboard: Clipboard
    let isEditing: Bool
    let canMerge: Bool
    
    let onRename: () -> Void
    let onSplit: (FileItem) -> Void
    let onMerge: () -> Void
    let onInspectAPK: () -> Void
    let onEncrypt: () -> Void
    let onDecrypt: () -> Void
    let onResize: () -> Void
    let onShare: () -> Void
    let onBatchRename: () -> Void
    let onMergePDFs: () -> Void
    let onInspectArchive: () -> Void
    let onViewPlist: () -> Void 
    let onDrawImage: () -> Void 
    let onViewInfo: () -> Void
    
    @AppStorage("isHiddenSpaceEnabled") private var isHiddenSpaceEnabled = true
    @AppStorage("isCompressionEnabled") private var isCompressionEnabled = true
    @AppStorage("isSplitMergeEnabled") private var isSplitMergeEnabled = true
    @AppStorage("isEncryptionEnabled") private var isEncryptionEnabled = true
    @AppStorage("isImageResizeEnabled") private var isImageResizeEnabled = true
    @AppStorage("isPDFToolsEnabled") private var isPDFToolsEnabled = true
    
    var body: some View {
        let targets = (isEditing && vm.selection.contains(item.url)) ? vm.selectedURLs : [item.url]
        let isMulti = targets.count > 1
        let ext = item.url.pathExtension.lowercased()
        
        let allImages = targets.allSatisfy { ["png", "jpg", "jpeg", "heic", "webp"].contains($0.pathExtension.lowercased()) }
        let allPDFs = targets.allSatisfy { $0.pathExtension.lowercased() == "pdf" }
        let isSinglePDF = !isMulti && ext == "pdf"
        
        if isMulti {
            Button { onShare() } label: { Label("Share \(targets.count) Items", systemImage: "square.and.arrow.up") }
            Button { clipboard.set(targets, cut: false) } label: { Label("Copy \(targets.count) Items", systemImage: "doc.on.doc") }
            Button { clipboard.set(targets, cut: true) } label: { Label("Cut \(targets.count) Items", systemImage: "scissors") }
            Button { onBatchRename() } label: { Label("Rename \(targets.count) Items", systemImage: "pencil.circle.fill") }
            
            if allPDFs && isPDFToolsEnabled {
                Button { onMergePDFs() } label: { Label("Merge \(targets.count) PDFs", systemImage: "rectangle.stack.badge.plus") }
            } else if canMerge && isSplitMergeEnabled {
                Button { onMerge() } label: { Label("Merge \(targets.count) Parts", systemImage: "arrow.triangle.merge") }
            } else if allImages && isImageResizeEnabled {
                Button { onResize() } label: { Label("Resize \(targets.count) Images", systemImage: "arrow.down.right.and.arrow.up.left") }
            } else if isCompressionEnabled {
                Button { vm.compress(targets) } label: { Label("Compress \(targets.count) Items", systemImage: "archivebox.fill") }
            }
            
            Button(role: .destructive) { DispatchQueue.main.async { vm.delete(targets) } } label: {
                Label(vm.isTrash ? "Delete \(targets.count) Items" : "Move \(targets.count) Items to Recently Deleted", systemImage: "trash")
            }
        } else {
            Button { onShare() } label: { Label("Share", systemImage: "square.and.arrow.up") }
            Button { onRename() } label: { Label("Rename", systemImage: "pencil") }
            
            Menu {
                Button { setTag("red") } label: { Text("🔴 Red") }
                Button { setTag("blue") } label: { Text("🔵 Blue") }
                Button { setTag("green") } label: { Text("🟢 Green") }
                Button { setTag("orange") } label: { Text("🟠 Orange") }
                Button { setTag("purple") } label: { Text("🟣 Purple") }
                
                if TagManager.shared.getTagColor(for: item.url) != nil {
                    Divider()
                    Button(role: .destructive) { setTag(nil) } label: { Label("Remove Tag", systemImage: "xmark.circle") }
                }
            } label: {
                Label("Tags", systemImage: "tag")
            }
            
            Button { onViewInfo() } label: { Label("Get Info", systemImage: "info.circle") }
            
            if ext == "plist" && !vm.isTrash {
                Button { onViewPlist() } label: { Label("View Property List", systemImage: "list.bullet.rectangle") }
            }
            
            if ["png", "jpg", "jpeg"].contains(ext) && !vm.isTrash {
                Button { onDrawImage() } label: { Label("Draw on Image", systemImage: "pencil.tip.crop.circle") }
            }
            
            if isCompressionEnabled && item.isArchive && !vm.isTrash {
                Button { onInspectArchive() } label: { Label("Inspect Archive", systemImage: "doc.text.magnifyingglass") }
                Button { vm.extract(item) } label: { Label("Extract Here", systemImage: "archivebox") }
            }
            
            if isSinglePDF && isPDFToolsEnabled && !vm.isTrash {
                Button { vm.splitPDF(item) } label: { Label("Split PDF Pages", systemImage: "square.split.2x1") }
            }
            
            if !item.isDirectory && !vm.isTrash && isSplitMergeEnabled && !item.isArchive { 
                Button { onSplit(item) } label: { Label("Split File", systemImage: "arrow.triangle.branch") } 
            }
            
            if !item.isDirectory && !vm.isTrash && isEncryptionEnabled {
                if item.name.hasSuffix(".enc") {
                    Button { onDecrypt() } label: { Label("Decrypt File", systemImage: "lock.open.fill") }
                } else {
                    Button { onEncrypt() } label: { Label("Encrypt File", systemImage: "lock.fill") }
                }
            }
            
            if isHiddenSpaceEnabled {
                if vm.isHiddenSpace {
                    Button { DispatchQueue.main.async { vm.restoreFromHidden(targets) } } label: { Label("Restore from Hidden", systemImage: "eye") }
                } else if item.isDirectory && !vm.isTrash {
                    Button { DispatchQueue.main.async { vm.moveToHidden(targets) } } label: { Label("Move to Hidden", systemImage: "eye.slash") }
                }
            }
            
            if vm.isTrash {
                Button { vm.restore(targets) } label: { Label("Restore", systemImage: "arrow.uturn.backward") }
            } else {
                Button { clipboard.set(targets, cut: false) } label: { Label("Copy", systemImage: "doc.on.doc") }
                Button { clipboard.set(targets, cut: true) } label: { Label("Cut", systemImage: "scissors") }
                if ext == "apk" { Button { onInspectAPK() } label: { Label("Inspect APK", systemImage: "magnifyingglass") } }
            }
            
            Button(role: .destructive) { DispatchQueue.main.async { vm.delete(targets) } } label: {
                Label(vm.isTrash ? "Delete Forever" : "Move to Recently Deleted", systemImage: "trash")
            }
        }
    }
    
    private func setTag(_ colorName: String?) {
        // 🔥 No vm.reload() needed, the ObservableObject handles it!
        TagManager.shared.setTag(for: item.url, colorName: colorName)
    }
}
