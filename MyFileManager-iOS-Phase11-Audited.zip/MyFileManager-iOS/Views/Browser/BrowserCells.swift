import SwiftUI
import UniformTypeIdentifiers

struct FileListView: View {
    @ObservedObject var vm: BrowserViewModel
    let paneID: UUID?
    let visible: [FileItem]
    let editMode: EditMode?
    @Binding var targetFolderURL: URL?
    let onDropAction: ([NSItemProvider], URL) -> Void
    let menuContent: (FileItem) -> AnyView
    
    var body: some View {
        List(selection: $vm.selection) {
            if !visible.isEmpty {
                Section {
                } header: {
                    HStack {
                        Text("\(visible.count) Items").font(.footnote).fontWeight(.semibold).foregroundStyle(.secondary).textCase(.uppercase)
                        Spacer()
                    }.padding(.vertical, 4)
                }
            }
            ForEach(visible) { item in
                rowView(for: item)
            }
        }
        .listStyle(.plain)
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 90) }
    }
    
    @ViewBuilder
    private func rowView(for item: FileItem) -> some View {
        FileRowView(item: item, vm: vm, paneID: paneID, editMode: editMode, targetFolderURL: targetFolderURL)
            // 🔥 FIXED: Removed the heavy custom preview to stop animation lag
            .contextMenu {
                menuContent(item)
            }
            .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                Button(role: .destructive) { 
                    HapticManager.shared.impact(style: .medium)
                    vm.delete([item.url]) 
                } label: { 
                    Label(vm.isTrash ? "Delete" : "Recently Deleted", systemImage: "trash") 
                }
                if vm.isTrash {
                    Button { 
                        HapticManager.shared.impact()
                        vm.restore([item.url]) 
                    } label: { 
                        Label("Restore", systemImage: "arrow.uturn.backward") 
                    }.tint(.blue)
                }
            }
            .onDrop(of: [UTType.fileURL.identifier, UTType.url.identifier], isTargeted: isTargeted(for: item)) { providers in
                guard item.isDirectory else { return false }
                onDropAction(providers, item.url)
                return true
            }
    }
    
    private func isTargeted(for item: FileItem) -> Binding<Bool> {
        Binding(get: { targetFolderURL == item.url }, set: { isTargeted in targetFolderURL = isTargeted ? item.url : nil })
    }
}

struct FileGridView: View {
    @ObservedObject var vm: BrowserViewModel
    let paneID: UUID?
    let visible: [FileItem]
    let editMode: EditMode?
    @Binding var targetFolderURL: URL?
    let onDropAction: ([NSItemProvider], URL) -> Void
    let menuContent: (FileItem) -> AnyView
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 16)], spacing: 16) {
                ForEach(visible) { item in
                    gridCell(for: item)
                }
            }.padding()
        }.safeAreaInset(edge: .bottom) { Color.clear.frame(height: 90) }
    }
    
    @ViewBuilder
    private func gridCell(for item: FileItem) -> some View {
        GridItemView(item: item, vm: vm, paneID: paneID, editMode: editMode, targetFolderURL: targetFolderURL)
            .contextMenu {
                menuContent(item)
            }
            .onDrop(of: [UTType.fileURL.identifier, UTType.url.identifier], isTargeted: isTargeted(for: item)) { providers in
                guard item.isDirectory else { return false }
                onDropAction(providers, item.url)
                return true
            }
    }
    
    private func isTargeted(for item: FileItem) -> Binding<Bool> {
        Binding(get: { targetFolderURL == item.url }, set: { isTargeted in targetFolderURL = isTargeted ? item.url : nil })
    }
}

struct FileRowView: View {
    let item: FileItem
    @ObservedObject var vm: BrowserViewModel
    let paneID: UUID?
    let editMode: EditMode?
    let targetFolderURL: URL?
    
    var body: some View {
        Group {
            if editMode?.isEditing == true {
                FileRow(item: item).tag(item.url)
            } else {
                NavigationLink {
                    destinationView(for: item, vm: vm, paneID: paneID)
                } label: {
                    FileRow(item: item)
                }
                .onDrag { NSItemProvider(object: item.url as NSURL) } preview: {
                    Label(item.name, systemImage: item.iconName).padding(8).background(Color(UIColor.secondarySystemBackground)).cornerRadius(8)
                }
            }
        }
        .contentShape(Rectangle())
        .background(targetFolderURL == item.url ? Color.blue.opacity(0.2) : Color.clear)
    }
}

struct GridItemView: View {
    let item: FileItem
    @ObservedObject var vm: BrowserViewModel
    let paneID: UUID?
    let editMode: EditMode?
    let targetFolderURL: URL?
    
    @ObservedObject var tagManager = TagManager.shared
    private var isSelected: Bool { editMode?.isEditing == true && vm.selection.contains(item.url) }
    
    var body: some View {
        Group {
            if editMode?.isEditing == true {
                gridContent.contentShape(Rectangle()).onTapGesture {
                    HapticManager.shared.impact(style: .light)
                    if isSelected { vm.selection.remove(item.url) } else { vm.selection.insert(item.url) }
                }
            } else {
                NavigationLink {
                    destinationView(for: item, vm: vm, paneID: paneID)
                } label: {
                    gridContent
                }
                .onDrag { NSItemProvider(object: item.url as NSURL) } preview: {
                    Label(item.name, systemImage: item.iconName).padding(8).background(Color(UIColor.secondarySystemBackground)).cornerRadius(8)
                }
            }
        }
    }
    
    private var gridContent: some View {
        VStack(spacing: 6) {
            ZStack(alignment: .topTrailing) {
                ThumbnailView(url: item.url, fallbackIcon: item.iconName, fallbackColor: item.iconColor)
                    .frame(width: 70, height: 70)
                    .background(targetFolderURL == item.url ? Color.blue.opacity(0.2) : Color.clear)
                    .cornerRadius(12)
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(isSelected ? Color.blue : Color.clear, lineWidth: 3))
                
                if let tagColor = tagManager.getTagColor(for: item.url) {
                    Circle()
                        .fill(tagColor)
                        .frame(width: 14, height: 14)
                        .overlay(Circle().stroke(Color.white, lineWidth: 2))
                        .offset(x: -4, y: 4)
                }
                
                if editMode?.isEditing == true {
                    Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                        .foregroundStyle(isSelected ? .blue : .gray).background(Circle().fill(.white)).offset(x: 4, y: -4)
                }
            }
            Text(item.name).font(.caption).lineLimit(2).multilineTextAlignment(.center).foregroundStyle(isSelected ? .blue : .primary)
        }
        .frame(maxWidth: .infinity)
    }
}

struct FileRow: View {
    let item: FileItem
    @ObservedObject var tagManager = TagManager.shared
    
    var body: some View {
        HStack(spacing: 12) {
            ThumbnailView(url: item.url, fallbackIcon: item.iconName, fallbackColor: item.iconColor).frame(width: 36, height: 36)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.body).lineLimit(1)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            
            if let tagColor = tagManager.getTagColor(for: item.url) {
                Circle().fill(tagColor).frame(width: 12, height: 12)
            }
        }
        .padding(.vertical, 4)
    }
    
    private var subtitle: String {
        let date = item.modified?.formatted(date: .abbreviated, time: .shortened) ?? ""
        if item.isDirectory {
            return "Folder  •  " + date
        }
        return ByteCountFormatter.string(fromByteCount: item.size, countStyle: .file) + "  •  " + date
    }
}

struct EmptyStateView: View {
    let isTrash: Bool
    let onNewFolder: () -> Void
    let onImport: () -> Void
    
    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            
            Image(systemName: isTrash ? "trash" : "folder")
                .font(.system(size: 80))
                .foregroundStyle(.secondary.opacity(0.3))
            
            Text(isTrash ? "Recently Deleted is Empty" : "Folder is Empty")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundStyle(.secondary)
            
            if !isTrash {
                HStack(spacing: 16) {
                    Button {
                        HapticManager.shared.impact()
                        onNewFolder()
                    } label: {
                        Label("New Folder", systemImage: "folder.badge.plus")
                            .font(.subheadline).fontWeight(.medium)
                            .padding(.horizontal, 20).padding(.vertical, 12)
                            .background(Color.blue.opacity(0.1))
                            .foregroundStyle(.blue)
                            .cornerRadius(10)
                    }
                    
                    Button {
                        HapticManager.shared.impact()
                        onImport()
                    } label: {
                        Label("Import Files", systemImage: "square.and.arrow.down")
                            .font(.subheadline).fontWeight(.medium)
                            .padding(.horizontal, 20).padding(.vertical, 12)
                            .background(Color.green.opacity(0.1))
                            .foregroundStyle(.green)
                            .cornerRadius(10)
                    }
                }
                .padding(.top, 10)
            }
            
            Spacer()
        }
        .padding(.bottom, 50)
    }
}

@ViewBuilder
func destinationView(for item: FileItem, vm: BrowserViewModel, paneID: UUID? = nil) -> some View {
    let ext = item.url.pathExtension.lowercased()
    let isImage = ["png", "jpg", "jpeg", "gif", "webp", "heic"].contains(ext)
    let isMedia = ["mp4", "mov", "mkv", "avi", "m4v", "mp3", "wav", "m4a", "flac"].contains(ext)
    
    if item.isDirectory {
        BrowserView(url: item.url, paneID: paneID)
    } else if isImage {
        let imageItems = vm.items.filter { ["png", "jpg", "jpeg", "gif", "webp", "heic"].contains($0.url.pathExtension.lowercased()) }
        let startIndex = imageItems.firstIndex(of: item) ?? 0
        MediaGalleryView(items: imageItems, startIndex: startIndex).navigationBarHidden(true)
    } else if isMedia {
        MediaPlayerView(url: item.url)
    } else {
        FileDetailView(item: item)
    }
}
