import SwiftUI

struct BrowserAlertsModifier: ViewModifier {
    @Binding var showNewFolder: Bool
    @Binding var newFolderName: String
    @Binding var showBatchRename: Bool
    @Binding var batchName: String
    
    // 🔥 FIXED: Added Find & Replace bindings
    @Binding var showFindReplace: Bool
    @Binding var findText: String
    @Binding var replaceText: String
    
    @Binding var renameTarget: FileItem?
    @Binding var renameText: String
    @Binding var showSplitPrompt: Bool
    @Binding var splitChunkSize: String
    @Binding var splitTarget: FileItem?
    @Binding var showMergePrompt: Bool
    @Binding var mergeName: String
    @ObservedObject var vm: BrowserViewModel

    func body(content: Content) -> some View {
        content
            .alert("New Folder", isPresented: $showNewFolder) {
                TextField("Name", text: $newFolderName)
                Button("Create") { vm.createFolder(newFolderName) }
                Button("Cancel", role: .cancel) {}
            }
            .alert("Batch Rename", isPresented: $showBatchRename) {
                TextField("Base Name", text: $batchName)
                Button("Rename") { vm.batchRename(baseName: batchName) }
                Button("Cancel", role: .cancel) {}
            } message: { Text("Items will be renamed to: \(batchName) 1, 2, etc.") }
            
            // 🔥 FIXED: Added Find & Replace alert
            .alert("Find & Replace", isPresented: $showFindReplace) {
                TextField("Find", text: $findText)
                TextField("Replace", text: $replaceText)
                Button("Replace All") { vm.batchReplace(find: findText, replace: replaceText) }
                Button("Cancel", role: .cancel) { findText = ""; replaceText = "" }
            } message: { Text("Replace text in all selected file names.") }
            
            .alert("Rename", isPresented: Binding(get: { renameTarget != nil }, set: { if !$0 { renameTarget = nil } })) {
                TextField("Name", text: $renameText)
                Button("Rename") { if let t = renameTarget { vm.rename(t, to: renameText) } }
                Button("Cancel", role: .cancel) {}
            }
            .alert("Split File", isPresented: $showSplitPrompt) {
                TextField("Chunk Size (MB)", text: $splitChunkSize).keyboardType(.numberPad)
                Button("Split") { if let target = splitTarget, let size = Int(splitChunkSize), size > 0 { vm.splitFile(target, chunkSizeMB: size) } }
                Button("Cancel", role: .cancel) { splitTarget = nil }
            } message: { Text("Enter the size for each part in Megabytes.") }
            .alert("Merge Files", isPresented: $showMergePrompt) {
                TextField("Output File Name", text: $mergeName)
                Button("Merge") { vm.mergeFiles(vm.selectedURLs, baseName: mergeName) }
                Button("Cancel", role: .cancel) {}
            } message: { Text("Enter the name for the combined file.") }
            .alert("Error", isPresented: Binding(get: { vm.errorMessage != nil }, set: { if !$0 { vm.errorMessage = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(vm.errorMessage ?? "") }
    }
}
