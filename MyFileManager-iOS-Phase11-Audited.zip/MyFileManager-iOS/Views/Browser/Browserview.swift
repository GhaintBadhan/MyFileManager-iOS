import SwiftUI
import UniformTypeIdentifiers

struct BrowserNavigationEvent {
    let paneID: UUID
    let url: URL
}

struct BrowserView: View {
    @StateObject private var vm: BrowserViewModel
    @EnvironmentObject private var clipboard: Clipboard
    private let onSelectionChanged: ((Set<URL>) -> Void)?
    private let paneID: UUID?
    
    // 🔥 Native EditMode Management
    @State private var editMode: EditMode = .inactive
    @AppStorage("isGridView") private var isGridView = false
    
    @State private var search = ""
    @State private var showNewFolder = false
    @State private var newFolderName = ""
    @State private var showNewFile = false
    @State private var newFileName = ""
    
    @State private var renameTarget: FileItem?
    @State private var renameText = ""
    @State private var importing = false
    @State private var selectedAPK: FileItem?
    
    @State private var showBatchRename = false
    @State private var batchName = ""
    
    @State private var showFindReplace = false
    @State private var findText = ""
    @State private var replaceText = ""
    
    @State private var showSplitPrompt = false
    @State private var splitChunkSize = "10"
    @State private var splitTarget: FileItem?
    
    @State private var showMergePrompt = false
    @State private var mergeName = "MergedFile"
    
    @State private var showPasswordPrompt = false
    @State private var passwordInput = ""
    @State private var cryptTarget: FileItem?
    @State private var isEncrypting = false
    
    @State private var showResizePrompt = false
    @State private var resizeTargets: [URL] = []
    @State private var resizeDimension = "1080"
    
    @State private var shareItems: [Any] = []
    @State private var showShareSheet = false
    
    @State private var inspectArchiveItem: FileItem?
    @State private var viewPlistItem: FileItem?
    @State private var markupItem: FileItem?
    @State private var infoItem: FileItem?
    
    @State private var targetFolderURL: URL?
    @State private var isTargetingList = false

    init(url: URL, isTrash: Bool = false, paneID: UUID? = nil, onSelectionChanged: ((Set<URL>) -> Void)? = nil) {
        _vm = StateObject(wrappedValue: BrowserViewModel(url: url, isTrash: isTrash))
        self.onSelectionChanged = onSelectionChanged
        self.paneID = paneID
    }

    private var visible: [FileItem] {
        var result = vm.items
        if !search.isEmpty { result = result.filter { $0.name.localizedCaseInsensitiveContains(search) } }
        if let tagFilter = vm.activeTagFilter { result = result.filter { TagManager.shared.getTagName(for: $0.url) == tagFilter } }
        return result
    }
    
    private var displayTitle: String {
        let name = vm.currentURL.lastPathComponent
        if name == ".Trash" { return "Recently Deleted" }
        if name == ".HiddenFolders" { return "Hidden Space" }
        return name
    }
    
    private var isAllSelected: Bool { return !visible.isEmpty && vm.selection.count == visible.count }
    private var canMergeSelection: Bool {
        guard vm.selection.count > 1 else { return false }
        return vm.selectedURLs.allSatisfy { $0.lastPathComponent.contains(".part") }
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            mainContentView
            processingOverlays
        }
        .background(backgroundContextMenu)
        // 🔥 FIXED: Native EditMode binding and cleanup
        .environment(\.editMode, $editMode)
        .onChange(of: editMode) { oldValue, newValue in
            if !newValue.isEditing { vm.selection.removeAll() }
        }
        .onChange(of: vm.selection) { _, newValue in
            onSelectionChanged?(newValue)
        }
        .onDrop(of: [UTType.fileURL.identifier, UTType.url.identifier], isTargeted: $isTargetingList) { providers in
            processProviders(providers, destination: vm.currentURL)
            return true
        }
        .navigationTitle(displayTitle)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search")
        .refreshable { vm.reload() }
        // 🔥 FIXED: Only load data when necessary, preventing stutter on back navigation
        .onAppear {
            if vm.items.isEmpty { vm.reload() } 
            if let paneID {
                NotificationCenter.default.post(
                    name: NSNotification.Name("BrowserNavigationChanged"),
                    object: BrowserNavigationEvent(paneID: paneID, url: vm.currentURL)
                )
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("FileSystemChanged"))) { _ in vm.reload() }
        .toolbar { toolbarContent }
        .modifier(SheetsModifier(
            importing: $importing, selectedAPK: $selectedAPK,
            inspectArchiveItem: $inspectArchiveItem, viewPlistItem: $viewPlistItem,
            markupItem: $markupItem, infoItem: $infoItem, showShareSheet: $showShareSheet,
            shareItems: shareItems, vm: vm
        ))
        .modifier(AlertsModifier(
            showNewFile: $showNewFile, newFileName: $newFileName,
            showPasswordPrompt: $showPasswordPrompt, passwordInput: $passwordInput,
            isEncrypting: isEncrypting, cryptTarget: cryptTarget,
            showResizePrompt: $showResizePrompt, resizeDimension: $resizeDimension,
            resizeTargets: resizeTargets, vm: vm
        ))
        .modifier(BrowserAlertsModifier(
            showNewFolder: $showNewFolder, newFolderName: $newFolderName,
            showBatchRename: $showBatchRename, batchName: $batchName,
            showFindReplace: $showFindReplace, findText: $findText, replaceText: $replaceText,
            renameTarget: $renameTarget, renameText: $renameText,
            showSplitPrompt: $showSplitPrompt, splitChunkSize: $splitChunkSize, splitTarget: $splitTarget,
            showMergePrompt: $showMergePrompt, mergeName: $mergeName,
            vm: vm
        ))
    }

    @ViewBuilder
    private var mainContentView: some View {
        if vm.items.isEmpty && search.isEmpty {
            EmptyStateView(
                isTrash: vm.isTrash,
                onNewFolder: { newFolderName = ""; showNewFolder = true },
                onImport: { importing = true }
            )
        } else if visible.isEmpty && vm.activeTagFilter != nil {
            ContentUnavailableView("No Tagged Files", systemImage: "tag.slash", description: Text("No files in this folder have the selected tag."))
        } else {
            Group {
                if isGridView {
                    FileGridView(vm: vm, paneID: paneID, visible: visible, editMode: editMode, targetFolderURL: $targetFolderURL, onDropAction: processProviders, menuContent: { item in AnyView(renderMenu(for: item)) })
                        // 🔥 Removed solid background to let native glass shine through
                        .background(isTargetingList ? Color.blue.opacity(0.1) : Color.clear)
                } else {
                    FileListView(vm: vm, paneID: paneID, visible: visible, editMode: editMode, targetFolderURL: $targetFolderURL, onDropAction: processProviders, menuContent: { item in AnyView(renderMenu(for: item)) })
                        // 🔥 Removed solid background to let native glass shine through
                        .background(isTargetingList ? Color.blue.opacity(0.1) : Color.clear)
                }
            }
        }
    }

    @ViewBuilder
    private var processingOverlays: some View {
        if vm.isCopying {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Copying...").font(.headline)
                    Spacer()
                    Text("\(Int(vm.copyProgress * 100))%").font(.headline).foregroundStyle(.blue)
                }
                Text(vm.currentCopyName).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                ProgressView(value: vm.copyProgress).tint(.blue)
            }
            .padding(16).background(.regularMaterial).cornerRadius(12).shadow(radius: 10)
            .padding(.horizontal, 20).padding(.bottom, 20)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
        
        if vm.isProcessing {
            Color.black.opacity(0.4).ignoresSafeArea()
            VStack(spacing: 16) {
                ProgressView().scaleEffect(1.5).tint(.white)
                Text("Processing...").font(.headline).foregroundStyle(.white)
            }
            .padding(30).background(Color(UIColor.systemBackground).opacity(0.9)).cornerRadius(16)
        }
    }

    @ViewBuilder
    private var backgroundContextMenu: some View {
        Color.clear
            .contentShape(Rectangle())
            .contextMenu {
                Button { newFolderName = ""; showNewFolder = true } label: { Label("New Folder", systemImage: "folder.badge.plus") }
                Button { newFileName = ""; showNewFile = true } label: { Label("New File", systemImage: "doc.badge.plus") }
                if !clipboard.urls.isEmpty { Button { vm.paste(clipboard) } label: { Label("Paste", systemImage: "doc.on.clipboard") } }
            }
    }

    @ToolbarContentBuilder
    private var toolbarContent: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            if editMode.isEditing {
                Button {
                    HapticManager.shared.impact()
                    withAnimation(.snappy(duration: 0.25)) {
                        if isAllSelected { vm.selection.removeAll() }
                        else { vm.selection = Set(visible.map { $0.url }) }
                    }
                } label: {
                    ZStack {
                        Text("Select All").opacity(isAllSelected ? 0 : 1)
                        Text("Undo").opacity(isAllSelected ? 1 : 0)
                    }
                    .font(.body).frame(width: 80, alignment: .leading)
                }
            }
        }
        
        ToolbarItemGroup(placement: .topBarTrailing) {
            TopTrailingMenuView(
                vm: vm, clipboard: clipboard, isGridView: $isGridView, singleItem: selectedSingleFile,
                onNewFolder: { newFolderName = ""; showNewFolder = true },
                onNewFile: { newFileName = ""; showNewFile = true },
                onImport: { importing = true },
                onSplit: { item in splitTarget = item; splitChunkSize = "10"; showSplitPrompt = true },
                onShare: { shareItems = vm.selectedURLs; showShareSheet = true },
                onBatchRename: { batchName = ""; showBatchRename = true },
                onFindReplace: { findText = ""; replaceText = ""; showFindReplace = true },
                onMergePDFs: { vm.mergePDFs(vm.selectedURLs) },
                onMergeParts: { 
                    let name = vm.selectedURLs.first?.lastPathComponent ?? "Merged"
                    mergeName = name.components(separatedBy: ".part").first ?? "Merged"
                    showMergePrompt = true 
                },
                onResize: { resizeTargets = vm.selectedURLs; showResizePrompt = true }
            )
            EditButton()
        }
        
        ToolbarItemGroup(placement: .bottomBar) {
            if vm.isTrash && !vm.items.isEmpty && !editMode.isEditing {
                Button(role: .destructive) { 
                    HapticManager.shared.success()
                    vm.emptyTrash() 
                } label: { 
                    Label("Empty Recently Deleted", systemImage: "trash.slash").foregroundStyle(.red) 
                }
            }
        }
    }

    private func renderMenu(for item: FileItem) -> some View {
        ContextMenuView(
            item: item, vm: vm, clipboard: clipboard, isEditing: editMode.isEditing,
            canMerge: canMergeSelection,
            onRename: { renameText = item.name; renameTarget = item },
            onSplit: { _ in splitTarget = item; splitChunkSize = "10"; showSplitPrompt = true },
            onMerge: { 
                let name = vm.selectedURLs.first?.lastPathComponent ?? "Merged"
                mergeName = name.components(separatedBy: ".part").first ?? "Merged"
                showMergePrompt = true 
            },
            onInspectAPK: { selectedAPK = item },
            onEncrypt: { cryptTarget = item; isEncrypting = true; showPasswordPrompt = true },
            onDecrypt: { cryptTarget = item; isEncrypting = false; showPasswordPrompt = true },
            onResize: {
                let targets = (editMode.isEditing && vm.selection.contains(item.url)) ? vm.selectedURLs : [item.url]
                resizeTargets = targets
                showResizePrompt = true
            },
            onShare: { 
                let targets = (editMode.isEditing && vm.selection.contains(item.url)) ? vm.selectedURLs : [item.url]
                shareItems = targets
                showShareSheet = true
            },
            onBatchRename: { batchName = ""; showBatchRename = true },
            onMergePDFs: { vm.mergePDFs(vm.selectedURLs) },
            onInspectArchive: { inspectArchiveItem = item },
            onViewPlist: { viewPlistItem = item },
            onDrawImage: { markupItem = item },
            onViewInfo: { infoItem = item }
        )
    }

    private func processProviders(_ providers: [NSItemProvider], destination: URL) {
        for provider in providers {
            if provider.canLoadObject(ofClass: NSURL.self) {
                provider.loadObject(ofClass: NSURL.self) { (object, error) in
                    guard let nsurl = object as? NSURL else { return }
                    let url = nsurl as URL
                    DispatchQueue.main.async {
                        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                        if url.path.hasPrefix(docs.path) { vm.moveItems([url], to: destination) }
                        else { vm.copyItems([url], to: destination) }
                    }
                }
            }
        }
    }
    
    private var selectedSingleFile: FileItem? {
        guard vm.selection.count == 1, let url = vm.selectedURLs.first else { return nil }
        return vm.items.first(where: { $0.url == url })
    }
}

// MARK: - Extracted Modifiers
struct SheetsModifier: ViewModifier {
    @Binding var importing: Bool
    @Binding var selectedAPK: FileItem?
    @Binding var inspectArchiveItem: FileItem?
    @Binding var viewPlistItem: FileItem?
    @Binding var markupItem: FileItem?
    @Binding var infoItem: FileItem?
    @Binding var showShareSheet: Bool
    let shareItems: [Any]
    @ObservedObject var vm: BrowserViewModel

    func body(content: Content) -> some View {
        content
            .sheet(isPresented: $importing) { DocumentPicker { urls in importing = false; vm.importFiles(.success(urls)) } }
            .sheet(item: $selectedAPK) { apkItem in APKInspectorView(item: apkItem) }
            .sheet(item: $inspectArchiveItem) { item in ArchiveInspectorView(item: item) }
            .sheet(item: $viewPlistItem) { item in PlistViewerView(item: item) }
            .sheet(item: $markupItem) { item in ImageMarkupView(item: item) }
            .sheet(item: $infoItem) { item in 
                NavigationStack { InfoView(item: item).toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { infoItem = nil } } } }
            }
            .sheet(isPresented: $showShareSheet) { ShareSheet(items: shareItems) }
    }
}

struct AlertsModifier: ViewModifier {
    @Binding var showNewFile: Bool
    @Binding var newFileName: String
    @Binding var showPasswordPrompt: Bool
    @Binding var passwordInput: String
    let isEncrypting: Bool
    let cryptTarget: FileItem?
    @Binding var showResizePrompt: Bool
    @Binding var resizeDimension: String
    let resizeTargets: [URL]
    @ObservedObject var vm: BrowserViewModel

    func body(content: Content) -> some View {
        content
            .alert("New File", isPresented: $showNewFile) {
                TextField("File Name (e.g. notes.txt)", text: $newFileName)
                Button("Create") {
                    guard !newFileName.isEmpty else { return }
                    let url = vm.currentURL.appendingPathComponent(newFileName)
                    FileManager.default.createFile(atPath: url.path, contents: Data())
                    vm.reload()
                    NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                }
                Button("Cancel", role: .cancel) {}
            } message: { Text("Enter a name with an extension.") }
            
            .alert(isEncrypting ? "Encrypt File" : "Decrypt File", isPresented: $showPasswordPrompt) {
                SecureField("Password", text: $passwordInput)
                Button("Confirm") {
                    if let target = cryptTarget {
                        if isEncrypting { vm.encryptFile(target, password: passwordInput) }
                        else { vm.decryptFile(target, password: passwordInput) }
                        passwordInput = ""
                    }
                }
                Button("Cancel", role: .cancel) { passwordInput = "" }
            } message: { Text(isEncrypting ? "Enter a password to lock this file." : "Enter the password to unlock this file.") }
            
            .alert("Resize Images", isPresented: $showResizePrompt) {
                TextField("Max Dimension (e.g. 1080)", text: $resizeDimension).keyboardType(.numberPad)
                Button("Resize") {
                    if let dim = Double(resizeDimension), dim > 0 { vm.resizeImages(resizeTargets, maxDimension: CGFloat(dim), quality: 0.8, format: "jpg") }
                }
                Button("Cancel", role: .cancel) {}
            } message: { Text("Enter the maximum width/height in pixels.") }
    }
}
