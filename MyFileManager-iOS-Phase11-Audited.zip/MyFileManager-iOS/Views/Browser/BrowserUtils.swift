import SwiftUI
import UniformTypeIdentifiers

struct APKInspectorView: View {
    let item: FileItem
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            VStack { Image(systemName: "archivebox").font(.largeTitle).padding(); Text("APK Inspection requires ZIP support.").multilineTextAlignment(.center).padding() }
            .navigationTitle("APK Inspector")
            .toolbar { Button("Done") { dismiss() } }
        }
    }
}

struct DocumentPicker: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.item], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    func makeCoordinator() -> Coordinator { Coordinator(onPick: onPick) }
    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        init(onPick: @escaping ([URL]) -> Void) { self.onPick = onPick }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { onPick(urls) }
    }
}
