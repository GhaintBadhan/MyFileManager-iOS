import SwiftUI

struct TopTrailingMenuView: View {
    @ObservedObject var vm: BrowserViewModel
    let clipboard: Clipboard
    @Binding var isGridView: Bool
    let singleItem: FileItem?
    let onNewFolder: () -> Void
    let onNewFile: () -> Void
    let onImport: () -> Void
    let onSplit: (FileItem) -> Void
    
    let onShare: () -> Void
    let onBatchRename: () -> Void
    let onFindReplace: () -> Void // 🔥 FIXED: Added this closure
    let onMergePDFs: () -> Void
    let onMergeParts: () -> Void
    let onResize: () -> Void
    
    @AppStorage("isSplitMergeEnabled") private var isSplitMergeEnabled = true
    @AppStorage("isPDFToolsEnabled") private var isPDFToolsEnabled = true
    @AppStorage("isBatchRenameEnabled") private var isBatchRenameEnabled = true
    @AppStorage("isImageResizeEnabled") private var isImageResizeEnabled = true
    
    var body: some View {
        Menu {
            if vm.selection.count > 0 {
                Section("Selected Items (\(vm.selection.count))") {
                    Button { onShare() } label: { Label("Share", systemImage: "square.and.arrow.up") }
                    Button { clipboard.set(vm.selectedURLs, cut: false) } label: { Label("Copy", systemImage: "doc.on.doc") }
                    Button { clipboard.set(vm.selectedURLs, cut: true) } label: { Label("Cut", systemImage: "scissors") }
                    
                    if vm.selection.count > 1 && isBatchRenameEnabled {
                        Button { onBatchRename() } label: { Label("Batch Rename", systemImage: "pencil.circle.fill") }
                        Button { onFindReplace() } label: { Label("Find & Replace", systemImage: "magnifyingglass") }
                    }
                    
                    let allPDFs = vm.selectedURLs.allSatisfy { $0.pathExtension.lowercased() == "pdf" }
                    let canMergeParts = vm.selectedURLs.allSatisfy { $0.lastPathComponent.contains(".part") }
                    let allImages = vm.selectedURLs.allSatisfy { ["png", "jpg", "jpeg", "heic", "webp"].contains($0.pathExtension.lowercased()) }
                    
                    if allPDFs && vm.selection.count > 1 && isPDFToolsEnabled {
                        Button { onMergePDFs() } label: { Label("Merge PDFs", systemImage: "rectangle.stack.badge.plus") }
                    } else if canMergeParts && isSplitMergeEnabled {
                        Button { onMergeParts() } label: { Label("Merge Parts", systemImage: "arrow.triangle.merge") }
                    } else if allImages && isImageResizeEnabled {
                        Button { onResize() } label: { Label("Resize Images", systemImage: "arrow.down.right.and.arrow.up.left") }
                    } else if !allImages {
                        Button { vm.compress(vm.selectedURLs) } label: { Label("Compress to Tar", systemImage: "archivebox.fill") }
                    }
                    
                    Button(role: .destructive) { vm.delete(vm.selectedURLs) } label: {
                        Label(vm.isTrash ? "Delete Forever" : "Move to Recently Deleted", systemImage: "trash")
                    }
                }
            } else {
                Section {
                    Menu {
                        Button { vm.activeTagFilter = nil } label: { Label("All Files", systemImage: vm.activeTagFilter == nil ? "checkmark.circle.fill" : "circle") }
                        Button { vm.activeTagFilter = "red" } label: { Text("🔴 Red") }
                        Button { vm.activeTagFilter = "blue" } label: { Text("🔵 Blue") }
                        Button { vm.activeTagFilter = "green" } label: { Text("🟢 Green") }
                        Button { vm.activeTagFilter = "orange" } label: { Text("🟠 Orange") }
                        Button { vm.activeTagFilter = "purple" } label: { Text("🟣 Purple") }
                    } label: { Label("Filter by Tag", systemImage: "tag") }
                    
                    Menu {
                        Picker("Sort", selection: $vm.sort) {
                            Label("Name", systemImage: "textformat.abc").tag(SortOption.name)
                            Label("Size", systemImage: "arrow.up.arrow.down.square").tag(SortOption.size)
                            Label("Date", systemImage: "calendar").tag(SortOption.date)
                        }
                    } label: { Label("Sort By", systemImage: "arrow.up.arrow.down") }
                }
                
                Section {
                    Button { withAnimation { isGridView.toggle() } } label: { Label(isGridView ? "List View" : "Grid View", systemImage: isGridView ? "list.bullet" : "square.grid.2x2") }
                    Toggle(isOn: $vm.showHidden) { Label("Show Hidden Files", systemImage: "eye") }
                }
                
                if !vm.isTrash && !vm.isHiddenSpace {
                    Section("Actions") {
                        Button { onNewFolder() } label: { Label("New Folder", systemImage: "folder.badge.plus") }
                        Button { onNewFile() } label: { Label("New File", systemImage: "doc.badge.plus") }
                        Button { onImport() } label: { Label("Import Files", systemImage: "square.and.arrow.down") }
                        if !clipboard.urls.isEmpty { Button { vm.paste(clipboard) } label: { Label("Paste", systemImage: "doc.on.clipboard") } }
                    }
                } else if vm.isTrash {
                    Section { Button(role: .destructive) { vm.emptyTrash() } label: { Label("Empty Recently Deleted", systemImage: "trash.slash") } }
                }
            }
        } label: { 
            Image(systemName: vm.activeTagFilter != nil ? "line.3.horizontal.decrease.circle.fill" : "ellipsis.circle")
        }
    }
}

struct GlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 22, weight: .regular))
            .frame(width: 48, height: 48)
            .foregroundStyle(configuration.isPressed ? .secondary : .primary)
            .background(Circle().fill(Color.primary.opacity(configuration.isPressed ? 0.1 : 0.0)))
            .scaleEffect(configuration.isPressed ? 0.85 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}
