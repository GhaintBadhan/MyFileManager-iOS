# iOS-native enhancement roadmap

The project is now configured as a normal iOS application rather than a Nyxian project. The most useful next additions that fit Apple's APIs are a File Provider extension for exposing app-managed or remote files in the Files app, a unified background transfer queue using background `URLSession`, and richer document previews using Quick Look.

Other good additions are a Keychain-backed WebDAV credential vault, SharePlay-free share extensions for importing files from the share sheet, Spotlight indexing for local documents, App Shortcuts for opening bookmarks and launching transfers, and a proper ZIP editor built on a maintained archive library.

Android-only root access, APK installation, and system-directory modification should not be copied directly. APK inspection can still be added as a safe ZIP/package-inspection feature, while actual iOS app installation and protected system access are outside the normal iOS application sandbox.
