# MyFileManager iOS

This is the standard iOS/Xcode version of MyFileManager. Nyxian-specific project and entitlement configuration has been removed. The source is generated into an Xcode project with XcodeGen so it can be built reproducibly on a macOS GitHub Actions runner.

## Local build on macOS

Install Xcode and XcodeGen, then run:

```sh
brew install xcodegen
xcodegen generate
open MyFileManager.xcodeproj
```

For a simulator build without signing:

```sh
xcodebuild -project MyFileManager.xcodeproj \
  -scheme MyFileManager \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  build
```

For a device archive or App Store/TestFlight build, set your Apple Development Team and signing settings in Xcode or through GitHub Actions secrets. A paid Apple Developer account is required for signed device distribution.

## GitHub Actions

The included `.github/workflows/ios-build.yml` installs XcodeGen, generates `MyFileManager.xcodeproj`, builds an unsigned iOS Simulator app, and uploads it as a workflow artifact. Trigger it from the Actions tab or push to `main`/`master`.

## iOS-native scope

The app uses standard SwiftUI, UIKit, WebKit, Network, PDFKit, CryptoKit, LocalAuthentication, ImageIO, and Uniform Type Identifiers APIs. It keeps Files app sharing through `UIFileSharingEnabled` and `LSSupportsOpeningDocumentsInPlace`. Nyxian-only entitlements are not included.
