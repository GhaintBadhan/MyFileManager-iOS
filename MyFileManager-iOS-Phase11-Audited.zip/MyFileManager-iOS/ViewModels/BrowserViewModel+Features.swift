import Foundation

extension BrowserViewModel {
    // MARK: - Archive Tools
    func compress(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        isProcessing = true
        let name = urls.count == 1 ? urls[0].deletingPathExtension().lastPathComponent : "Archive"
        let dest = service.uniqueURL("\(name).tar", in: currentURL)
        
        Task.detached {
            var securedURLs: [URL] = []
            for url in urls { if url.startAccessingSecurityScopedResource() { securedURLs.append(url) } }
            defer { for url in securedURLs { url.stopAccessingSecurityScopedResource() } }
            
            do {
                try ArchiveService.compress(urls, to: dest)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }
    
    func extract(_ item: FileItem) {
        let dest = service.uniqueURL(item.url.deletingPathExtension().lastPathComponent, in: currentURL)
        isProcessing = true
        
        Task.detached {
            do {
                try FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true)
                try ArchiveService.extract(item.url, to: dest)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }

    // MARK: - Encryption Tools
    func encryptFile(_ item: FileItem, password: String) {
        isProcessing = true
        Task.detached {
            do {
                _ = try EncryptionService.encrypt(item.url, password: password)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }

    func decryptFile(_ item: FileItem, password: String) {
        isProcessing = true
        Task.detached {
            do {
                _ = try EncryptionService.decrypt(item.url, password: password)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }

    // MARK: - Split & Merge
    func splitFile(_ item: FileItem, chunkSizeMB: Int) {
        isProcessing = true
        Task.detached {
            do {
                _ = try self.service.splitFile(item.url, chunkSizeMB: chunkSizeMB)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }

    func mergeFiles(_ urls: [URL], baseName: String) {
        isProcessing = true
        let dest = service.uniqueURL(baseName, in: currentURL)
        Task.detached {
            do {
                try self.service.mergeFiles(urls, outputURL: dest)
                await MainActor.run { 
                    self.selection.removeAll()
                    self.finishProcessing() 
                }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }
}
