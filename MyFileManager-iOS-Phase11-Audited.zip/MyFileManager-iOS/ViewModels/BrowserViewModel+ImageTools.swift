import Foundation

extension BrowserViewModel {
    func resizeImages(_ urls: [URL], maxDimension: CGFloat, quality: CGFloat, format: String) {
        guard !urls.isEmpty else { return }
        isProcessing = true
        
        Task.detached {
            for url in urls {
                let started = url.startAccessingSecurityScopedResource()
                defer { if started { url.stopAccessingSecurityScopedResource() } }
                _ = try? ImageService.resizeImage(at: url, maxDimension: maxDimension, quality: quality, format: format)
            }
            await MainActor.run { 
                self.selection.removeAll()
                self.finishProcessing() 
            }
        }
    }
}
