import Foundation

extension BrowserViewModel {
    func mergePDFs(_ urls: [URL]) {
        guard urls.count > 1 else { return }
        isProcessing = true
        let dest = service.uniqueURL("Merged_Document.pdf", in: currentURL)
        
        Task.detached {
            do {
                try PDFService.mergePDFs(urls: urls, outputURL: dest)
                await MainActor.run { 
                    self.selection.removeAll()
                    self.finishProcessing() 
                }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }
    
    func splitPDF(_ item: FileItem) {
        isProcessing = true
        Task.detached {
            do {
                _ = try PDFService.splitPDF(url: item.url, outputDirectory: self.currentURL)
                await MainActor.run { self.finishProcessing() }
            } catch { await MainActor.run { self.handleError(error) } }
        }
    }
}
