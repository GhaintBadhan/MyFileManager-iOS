import Foundation

final class BrowserViewModel: ObservableObject {
    let currentURL: URL
    let isTrash: Bool
    
    @Published var items: [FileItem] = []
    @Published var selection = Set<URL>()
    @Published var errorMessage: String?
    @Published var showHidden = false { didSet { reload() } }
    @Published var sort: SortOption = .name { didSet { reload() } }
    @Published var isProcessing = false
    @Published var activeTagFilter: String? = nil
    
    @Published var copyProgress: Double = 0.0
    @Published var isCopying: Bool = false
    @Published var currentCopyName: String = ""

    internal let service = FileSystemService()
    private var reloadTask: Task<Void, Never>?
    private var reloadID = UUID()

    init(url: URL, isTrash: Bool = false) {
        self.currentURL = url
        self.isTrash = isTrash
    }

    deinit {
        reloadTask?.cancel()
    }
    
    var selectedURLs: [URL] { Array(selection) }
    var isHiddenSpace: Bool { currentURL.lastPathComponent == ".HiddenFolders" }

    func reload() {
        reloadTask?.cancel()
        let url = currentURL
        let hidden = showHidden
        let currentSort = sort
        let requestID = UUID()
        reloadID = requestID
        let service = self.service

        reloadTask = Task.detached(priority: .userInitiated) {
            do {
                try Task.checkCancellation()
                let fetchedItems = try service.list(url, showHidden: hidden)
                let sortedItems = Self.sorted(fetchedItems, by: currentSort)
                try Task.checkCancellation()
                await MainActor.run {
                    guard self.reloadID == requestID else { return }
                    self.items = sortedItems
                }
            } catch {
                guard !Task.isCancelled else { return }
                await MainActor.run { self.errorMessage = error.localizedDescription }
            }
        }
    }

    private static func sorted(_ list: [FileItem], by option: SortOption) -> [FileItem] {
        list.sorted { a, b in
            if a.isDirectory != b.isDirectory { return a.isDirectory }
            switch option {
            case .name: return a.name.localizedStandardCompare(b.name) == .orderedAscending
            case .size: return a.size > b.size
            case .date: return (a.modified ?? .distantPast) > (b.modified ?? .distantPast)
            }
        }
    }

    internal func run(_ work: () throws -> Void) {
        do { 
            try work() 
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch { 
            errorMessage = error.localizedDescription 
        }
        reload()
    }

    func createFolder(_ name: String) {
        guard !name.isEmpty else { return }
        run { try service.createFolder(name, in: currentURL) }
    }
    
    func rename(_ item: FileItem, to name: String) {
        guard !name.isEmpty, name != item.name else { return }
        run { try service.rename(item.url, to: name) }
    }
    
    func batchReplace(find: String, replace: String) {
        guard !find.isEmpty, !selection.isEmpty else { return }
        run { try service.batchReplace(selectedURLs, find: find, replace: replace) }
        selection.removeAll()
    }
    
    func batchRename(baseName: String) {
        guard !baseName.isEmpty, !selection.isEmpty else { return }
        run { try service.batchRename(selectedURLs, baseName: baseName) }
        selection.removeAll()
    }
    
    func moveItems(_ urls: [URL], to directory: URL) {
        run { try service.move(urls, to: directory) }
    }
    
    func moveToHidden(_ urls: [URL]) {
        run { try service.moveToHidden(urls) }
        selection.removeAll()
    }
    
    func restoreFromHidden(_ urls: [URL]) {
        run { try service.restoreFromHidden(urls) }
        selection.removeAll()
    }
    
    func copyItems(_ urls: [URL], to directory: URL) {
        guard !urls.isEmpty else { return }
        isCopying = true
        copyProgress = 0.0
        
        Task.detached {
            for (index, url) in urls.enumerated() {
                await MainActor.run {
                    self.currentCopyName = url.lastPathComponent
                    self.copyProgress = Double(index) / Double(max(urls.count, 1))
                }
                
                do {
                    try Self.copySafely(from: url, to: directory, using: self.service)
                } catch {
                    await MainActor.run { self.errorMessage = error.localizedDescription }
                    break
                }
            }
            
            await MainActor.run { 
                self.copyProgress = 1.0
                self.isCopying = false
                self.currentCopyName = ""
                self.reload() 
                NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
            }
        }
    }
    
    func delete(_ urls: [URL]) {
        run {
            if isTrash { try service.delete(urls) } 
            else { try service.moveToTrash(urls) }
        }
        selection.removeAll()
    }
    
    func restore(_ urls: [URL]) {
        run { try service.restoreFromTrash(urls) }
        selection.removeAll()
    }
    
    func emptyTrash() {
        run { try service.emptyTrash() }
        selection.removeAll()
    }
    
    func paste(_ clipboard: Clipboard) {
        run {
            if clipboard.isCut { 
                try service.move(clipboard.urls, to: currentURL)
                clipboard.clear() 
            } else { 
                try service.copy(clipboard.urls, to: currentURL) 
            }
        }
    }
    
    func importFiles(_ result: Result<[URL], Error>) {
        switch result {
        case .failure(let error):
            errorMessage = error.localizedDescription
        case .success(let urls):
            Task.detached {
                var errorMsg: String? = nil
                for url in urls {
                    do { 
                        try Self.copySafely(from: url, to: self.currentURL, using: self.service) 
                    } catch { 
                        errorMsg = error.localizedDescription
                        break 
                    }
                }
                let finalError = errorMsg
                await MainActor.run {
                    if let err = finalError { self.errorMessage = err }
                    self.reload()
                    NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                }
            }
        }
    }

    nonisolated private static func copySafely(from url: URL, to destination: URL, using service: FileSystemService) throws {
        let started = url.startAccessingSecurityScopedResource()
        defer { if started { url.stopAccessingSecurityScopedResource() } }
        
        var coordError: NSError?
        var safeURL: URL?
        NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordError) { safeURL = $0 }
        
        if let error = coordError { throw error }
        guard let finalURL = safeURL else { return }
        try service.copy([finalURL], to: destination)
    }
    
    internal func finishProcessing() {
        self.isProcessing = false
        self.reload()
        NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
    }
    
    internal func handleError(_ error: Error) {
        self.isProcessing = false
        self.errorMessage = error.localizedDescription
    }
}
