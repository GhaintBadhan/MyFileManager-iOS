# MyFileManager: iOS-native MT Manager feature plan

This plan targets the strongest parts of MT Manager while respecting the iOS application sandbox. Features are grouped by user value and implementation risk so the project can remain responsive and power-conscious.

## Tier 1: core dual-pane workflow

The first implementation tier should make the dual-pane experience complete. Each pane should have independent navigation history, back/forward buttons, a parent-folder button, breadcrumbs, a per-pane home folder, bookmarks, recent locations, and a sync-to-other-pane action. The active pane should have a clear but lightweight visual border.

Selected files should support explicit Copy to Other Pane, Move to Other Pane, Compare, Archive, Share, Rename, Delete, and Restore actions. Destination conflicts should offer Replace, Skip, Rename, and Apply to All. Drag and drop remains available, but it should not be the only transfer method.

## Tier 2: power-user search and selection

Search should support recursive folder search, extension filters, file-size ranges, date ranges, case sensitivity, regular expressions, content search for text files, excluded folders, saved searches, and search within supported archives. Results should remain available in a persistent results panel while the user opens or edits files.

Selection should support select all, inverse selection, range selection where the UI allows it, filtered selection, and a preview of batch rename results before applying them.

## Tier 3: task engine and performance

All expensive work should go through one operation queue. The queue should handle copy, move, delete, hashing, compression, extraction, encryption, image conversion, PDF processing, downloads, and network transfers. Each task needs progress, speed, remaining time, pause where technically possible, cancel, retry, and an error report.

Directory scans should be cancellable and generation-scoped so stale results never repaint the UI. Large files should stream through FileHandle or URLSession rather than loading the entire file into memory. Thumbnail work should use bounded concurrency and an in-memory plus disk cache. Heavy work should not run on the main actor.

The UI should avoid timers that run while a screen is inactive, avoid continuous animations, debounce search input, and update progress at a limited rate. This keeps CPU, battery, and thermal use under control.

## Tier 4: archive workspace

The archive browser should support ZIP inspection and editing, TAR and TAR.GZ extraction, adding or replacing entries, renaming entries, deleting entries, extracting selected entries, archive integrity checks, and copying files directly between a normal pane and an archive pane. Password-protected formats should be added only through a maintained library with documented iOS support.

Archive entries must always be normalized and checked against the destination root before extraction. Archive operations should be streamed or chunked where possible.

## Tier 5: comparison and editing

Add text comparison for TXT, Markdown, JSON, XML, PLIST, Swift, JavaScript, Python, HTML, and CSS. The comparison screen should show changed, inserted, and deleted lines and allow copying changes from one side to the other.

The text editor should support line numbers, syntax highlighting, automatic indentation, encoding detection, encoding conversion, word-wrap control, font-size control, go-to-line, regular-expression search and replace, read-only mode, crash recovery, and an explicit large-file warning.

Add folder comparison using names, sizes, modification dates, and optional hashes. Hash comparison should be opt-in for large trees because it is more power-intensive.

## Tier 6: iOS-native document and network integration

Add a File Provider extension so app-managed or remote files can appear in the Files app. The first provider backend should be the existing WebDAV service, followed by optional SMB/SFTP/FTP backends if their licensing and maintained iOS libraries are acceptable.

Store WebDAV and network credentials in the Keychain. Use background URLSession for resumable network transfers. Add Share Sheet import/export, Spotlight indexing for local documents, App Shortcuts for bookmarks and common transfers, Quick Look previews, and document-provider bookmark recovery.

The Wi-Fi server should use a short-lived pairing token, safe path handling, bounded request sizes, and a clear active-server indicator. It should not run unless the user explicitly starts it.

## Tier 7: metadata and media utilities

Add EXIF viewing and removal, image crop/rotate/flip, batch image conversion, video and audio metadata inspection, font preview, Markdown preview, JSON/XML formatting, CSV viewing, and SQLite read-only inspection. Each preview should have a file-size limit and offer a safe fallback instead of trying to decode arbitrarily large input.

## APK-related boundary

APK inspection is possible because an APK is a ZIP-based package. The iOS app can safely add manifest inspection, package metadata, certificate display, ZIP entry browsing, DEX/SMALI text viewing, and resource extraction.

Normal iOS apps cannot provide Android root access, install APKs, modify protected Android system directories, or reproduce full DEX/ARSC rewriting as a native iOS capability. Those functions should not be advertised as supported iOS features.

## Recommended implementation order

Implement Tier 1 first, then Tier 3, Tier 2, Tier 5, Tier 4, Tier 6, and Tier 7. This order improves the core workflow before adding expensive utilities and ensures every feature uses the same task queue, error handling, caching, and responsive UI rules.

The current project already contains the dual-pane shell, file operations, downloads, WebDAV, Wi-Fi transfer, PDF/image tools, encryption, hashing, previews, and search foundations. The next code pass should focus on Tier 1 navigation and transfer actions plus the shared task engine rather than adding isolated one-off screens.
