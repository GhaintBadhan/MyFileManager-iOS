import Foundation
import UIKit
import ImageIO

struct ImageService {
    static func resizeImage(at url: URL, maxDimension: CGFloat, quality: CGFloat, format: String) throws -> URL {
        // 1. Create image source
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else {
            throw NSError(domain: "ImageService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read image."])
        }
        
        // 2. Setup resize options
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageIfAbsent: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxDimension
        ]
        
        // 3. Create thumbnail
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            throw NSError(domain: "ImageService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not resize image."])
        }
        
        // 4. Determine new file name and path
        let baseName = url.deletingPathExtension().lastPathComponent
        let ext = format.lowercased()
        let newName = "\(baseName)_resized.\(ext)"
        let newURL = url.deletingLastPathComponent().appendingPathComponent(newName)
        
        // 5. Write to disk
        guard let destination = CGImageDestinationCreateWithURL(newURL as CFURL, ext == "png" ? "public.png" as CFString : "public.jpeg" as CFString, 1, nil) else {
            throw NSError(domain: "ImageService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not create output file."])
        }
        
        let properties: [CFString: Any] = [
            kCGImageDestinationLossyCompressionQuality: quality
        ]
        
        CGImageDestinationAddImage(destination, cgImage, properties as CFDictionary)
        
        guard CGImageDestinationFinalize(destination) else {
            throw NSError(domain: "ImageService", code: 4, userInfo: [NSLocalizedDescriptionKey: "Failed to save resized image."])
        }
        
        return newURL
    }
}
