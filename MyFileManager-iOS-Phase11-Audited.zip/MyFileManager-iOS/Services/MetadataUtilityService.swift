import Foundation
import ImageIO
import UniformTypeIdentifiers

struct MetadataRow: Identifiable {
    let id = UUID()
    let key: String
    let value: String
}

enum MetadataUtilityError: LocalizedError {
    case unsupported
    case tooLarge
    case invalidImage
    case saveFailed

    var errorDescription: String? {
        switch self {
        case .unsupported: return "This file type is not supported by the utility."
        case .tooLarge: return "The file is too large for this safe utility."
        case .invalidImage: return "The image metadata could not be read."
        case .saveFailed: return "The processed file could not be saved."
        }
    }
}

enum MetadataUtilityService {
    private static let maxBytes: Int64 = 25_000_000

    static func imageMetadata(at url: URL) throws -> [MetadataRow] {
        try validateSize(url)
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any] else {
            throw MetadataUtilityError.invalidImage
        }
        return flatten(properties).prefix(250).map { MetadataRow(key: $0.key, value: $0.value) }
    }

    static func removeImageMetadata(at url: URL) throws {
        try validateSize(url)
        let temporary = temporaryURL(for: url)
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
              let type = CGImageSourceGetType(source),
              let destination = CGImageDestinationCreateWithURL(
                temporary as CFURL,
                type,
                1,
                nil
              ) else { throw MetadataUtilityError.invalidImage }

        var properties = (CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]) ?? [:]
        properties.removeValue(forKey: kCGImagePropertyExifDictionary)
        properties.removeValue(forKey: kCGImagePropertyGPSDictionary)
        properties.removeValue(forKey: kCGImagePropertyMakerAppleDictionary)
        properties.removeValue(forKey: kCGImagePropertyTIFFDictionary)
        CGImageDestinationAddImageFromSource(destination, source, 0, properties as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { throw MetadataUtilityError.saveFailed }
        try replaceOriginal(url, with: temporary)
    }

    static func formattedText(at url: URL) throws -> String {
        try validateSize(url)
        let text = try String(contentsOf: url, encoding: .utf8)
        switch url.pathExtension.lowercased() {
        case "json":
            let data = Data(text.utf8)
            let object = try JSONSerialization.jsonObject(with: data)
            let formatted = try JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys])
            return String(decoding: formatted, as: UTF8.self)
        case "xml", "plist":
            return formatXML(text)
        default:
            throw MetadataUtilityError.unsupported
        }
    }

    static func saveFormatted(_ text: String, to url: URL) throws {
        let temp = temporaryURL(for: url)
        try text.write(to: temp, atomically: true, encoding: .utf8)
        try replaceOriginal(url, with: temp)
    }

    private static func validateSize(_ url: URL) throws {
        let size = Int64(try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0)
        guard size <= maxBytes else { throw MetadataUtilityError.tooLarge }
    }

    private static func flatten(_ dictionary: [CFString: Any], prefix: String = "") -> [(key: String, value: String)] {
        var rows: [(String, String)] = []
        for (key, value) in dictionary {
            let name = prefix.isEmpty ? key as String : "\(prefix).\(key)"
            if let nested = value as? [CFString: Any] {
                rows.append(contentsOf: flatten(nested, prefix: name))
            } else {
                rows.append((name, String(describing: value)))
            }
        }
        return rows.sorted { $0.0 < $1.0 }
    }

    private static func formatXML(_ text: String) -> String {
        let tokens = text.replacingOccurrences(of: ">", with: ">\n").split(separator: "\n", omittingEmptySubsequences: true)
        var depth = 0
        var output: [String] = []
        for tokenSub in tokens {
            let token = tokenSub.trimmingCharacters(in: .whitespacesAndNewlines)
            if token.hasPrefix("</") { depth = max(0, depth - 1) }
            output.append(String(repeating: "  ", count: depth) + token)
            if token.hasPrefix("<") && !token.hasPrefix("</") && !token.hasPrefix("<?") && !token.hasPrefix("<!") && !token.contains("</") && !token.hasSuffix("/>") { depth += 1 }
        }
        return output.joined(separator: "\n")
    }

    private static func temporaryURL(for url: URL) -> URL {
        url.deletingLastPathComponent().appendingPathComponent(".metadata-\(UUID().uuidString)-\(url.lastPathComponent)")
    }

    private static func replaceOriginal(_ url: URL, with temp: URL? = nil) throws {
        let temporary = temp ?? temporaryURL(for: url)
        if temp == nil { throw MetadataUtilityError.saveFailed }
        _ = try FileManager.default.replaceItemAt(url, withItemAt: temporary, backupItemName: nil, options: .usingNewMetadataOnly)
    }
}
