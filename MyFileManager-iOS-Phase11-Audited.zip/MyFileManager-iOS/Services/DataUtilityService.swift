import Foundation
import CoreText
import SQLite3

struct CSVData {
    let headers: [String]
    let rows: [[String]]
}

struct FontInfo {
    let postScriptName: String
    let familyName: String
    let styleName: String
}

struct SQLiteTable: Identifiable {
    let id: String
    let name: String
    let columns: [String]
    let rows: [[String]]
}

enum DataUtilityError: LocalizedError {
    case tooLarge
    case invalidData
    case databaseOpenFailed
    case databaseQueryFailed

    var errorDescription: String? {
        switch self {
        case .tooLarge: return "This file exceeds the safe utility limit."
        case .invalidData: return "The file could not be parsed safely."
        case .databaseOpenFailed: return "The SQLite database could not be opened read-only."
        case .databaseQueryFailed: return "The SQLite query failed."
        }
    }
}

enum DataUtilityService {
    private static let maximumBytes: Int64 = 10_000_000

    static func parseCSV(at url: URL) throws -> CSVData {
        try validate(url)
        let text = try String(contentsOf: url, encoding: .utf8)
        let delimiter: Character = url.pathExtension.lowercased() == "tsv" ? "\t" : ","
        let records = parseCSVRecords(text, delimiter: delimiter).prefix(1_001)
        guard !records.isEmpty else { return CSVData(headers: [], rows: []) }
        let headers = Array(records[0].prefix(100))
        let rows = records.dropFirst().map { Array($0.prefix(100)) }
        return CSVData(headers: headers, rows: rows)
    }

    static func fontInfo(at url: URL) throws -> FontInfo {
        let descriptor = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor]
        guard let descriptor = descriptor?.first,
              let name = CTFontDescriptorCopyAttribute(descriptor, kCTFontNameAttribute) as? String else {
            throw DataUtilityError.invalidData
        }
        let font = CTFontCreateWithName(name as CFString, 18, nil)
        let style = (CTFontDescriptorCopyAttribute(descriptor, kCTFontStyleNameAttribute) as? String) ?? "Regular"
        return FontInfo(
            postScriptName: name,
            familyName: CTFontCopyFamilyName(font) as String,
            styleName: style
        )
    }

    static func sqliteTables(at url: URL) throws -> [SQLiteTable] {
        try validate(url)
        var database: OpaquePointer?
        guard sqlite3_open_v2(url.path, &database, SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX, nil) == SQLITE_OK else {
            if database != nil { sqlite3_close(database) }
            throw DataUtilityError.databaseOpenFailed
        }
        defer { sqlite3_close(database) }
        let names = try query(database, sql: "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 100;")
        return try names.compactMap { row in
            guard let name = row.first else { return nil }
            return try table(database, name: name)
        }
    }

    private static func table(_ database: OpaquePointer?, name: String) throws -> SQLiteTable {
        let escaped = name.replacingOccurrences(of: "\"", with: "\"\"")
        let rows = try query(database, sql: "SELECT * FROM \"\(escaped)\" LIMIT 100;")
        let columns = try columnNames(database, sql: "SELECT * FROM \"\(escaped)\" LIMIT 0;")
        return SQLiteTable(id: name, name: name, columns: columns, rows: rows)
    }

    private static func columnNames(_ database: OpaquePointer?, sql: String) throws -> [String] {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK else { throw DataUtilityError.databaseQueryFailed }
        defer { sqlite3_finalize(statement) }
        return (0..<sqlite3_column_count(statement)).map { String(cString: sqlite3_column_name(statement, $0)) }
    }

    private static func query(_ database: OpaquePointer?, sql: String) throws -> [[String]] {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK else { throw DataUtilityError.databaseQueryFailed }
        defer { sqlite3_finalize(statement) }
        var result: [[String]] = []
        while sqlite3_step(statement) == SQLITE_ROW {
            var row: [String] = []
            for index in 0..<sqlite3_column_count(statement) {
                if sqlite3_column_type(statement, index) == SQLITE_NULL {
                    row.append("NULL")
                } else if let value = sqlite3_column_text(statement, index) {
                    row.append(String(cString: value))
                } else {
                    row.append("")
                }
            }
            result.append(row)
        }
        return result
    }

    private static func validate(_ url: URL) throws {
        let size = Int64(try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0)
        guard size <= maximumBytes else { throw DataUtilityError.tooLarge }
    }

    private static func parseCSVRecords(_ text: String, delimiter: Character) -> [[String]] {
        var records: [[String]] = []
        var row: [String] = []
        var field = ""
        var quoted = false
        var characters = Array(text)
        characters.append("\n")
        var index = 0
        while index < characters.count {
            let character = characters[index]
            if character == "\"" {
                if quoted && index + 1 < characters.count && characters[index + 1] == "\"" {
                    field.append("\""); index += 1
                } else { quoted.toggle() }
            } else if character == delimiter && !quoted {
                row.append(field); field = ""
            } else if (character == "\n" || character == "\r") && !quoted {
                if character == "\r", index + 1 < characters.count, characters[index + 1] == "\n" { index += 1 }
                row.append(field); field = ""
                if !row.allSatisfy({ $0.isEmpty }) { records.append(row) }
                row = []
                if records.count >= 1_001 { break }
            } else { field.append(character) }
            index += 1
        }
        return records
    }
}
