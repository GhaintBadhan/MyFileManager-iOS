import Foundation
import Security

struct WebDAVCredentials {
    let username: String
    let password: String
}

enum KeychainService {
    private static let service = "com.personal.myfilemanager.webdav"

    static func saveWebDAV(server: String, username: String, password: String) throws {
        let account = normalizedServer(server)
        let payload = try JSONEncoder().encode(["username": username, "password": password])
        deleteWebDAV(server: server)

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: payload,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
    }

    static func loadWebDAV(server: String) -> WebDAVCredentials? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: normalizedServer(server),
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let values = try? JSONDecoder().decode([String: String].self, from: data),
              let username = values["username"],
              let password = values["password"] else { return nil }
        return WebDAVCredentials(username: username, password: password)
    }

    static func deleteWebDAV(server: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: normalizedServer(server)
        ]
        SecItemDelete(query as CFDictionary)
    }

    private static func normalizedServer(_ server: String) -> String {
        server.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
}

struct KeychainError: LocalizedError {
    let status: OSStatus
    var errorDescription: String? { "Keychain operation failed (\(status))." }
}
