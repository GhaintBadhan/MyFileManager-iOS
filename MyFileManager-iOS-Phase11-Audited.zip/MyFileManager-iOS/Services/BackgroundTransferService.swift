import Foundation
import Combine

struct NetworkTransferRecord: Identifiable {
    enum Kind: String, Equatable { case download = "Download"; case upload = "Upload" }
    enum State: String, Equatable { case queued = "Queued"; case running = "Running"; case finished = "Done"; case failed = "Failed"; case cancelled = "Cancelled" }

    let id: UUID
    let taskIdentifier: Int
    let kind: Kind
    let name: String
    let localURL: URL
    var progress: Double = 0
    var state: State = .queued
    var errorMessage: String?
    var resumeData: Data?
}

@MainActor
final class BackgroundTransferService: NSObject, ObservableObject {
    static let shared = BackgroundTransferService()

    @Published private(set) var records: [NetworkTransferRecord] = []

    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.background(withIdentifier: "com.personal.myfilemanager.transfers")
        configuration.isDiscretionary = false
        configuration.sessionSendsLaunchEvents = true
        configuration.waitsForConnectivity = true
        configuration.allowsCellularAccess = true
        return URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }()
    private var destinations: [Int: URL] = [:]
    private var recordIDs: [Int: UUID] = [:]
    private var responses: [Int: HTTPURLResponse] = [:]

    private override init() {
        super.init()
    }

    @discardableResult
    func enqueueDownload(request: URLRequest, to destination: URL) -> UUID {
        let id = UUID()
        let task = session.downloadTask(with: request)
        destinations[task.taskIdentifier] = destination
        recordIDs[task.taskIdentifier] = id
        records.append(NetworkTransferRecord(id: id, taskIdentifier: task.taskIdentifier, kind: .download, name: destination.lastPathComponent, localURL: destination))
        task.resume()
        update(id) { $0.state = .running }
        return id
    }

    @discardableResult
    func enqueueUpload(request: URLRequest, from source: URL) -> UUID {
        let id = UUID()
        let task = session.uploadTask(with: request, fromFile: source)
        recordIDs[task.taskIdentifier] = id
        records.append(NetworkTransferRecord(id: id, taskIdentifier: task.taskIdentifier, kind: .upload, name: source.lastPathComponent, localURL: source))
        task.resume()
        update(id) { $0.state = .running }
        return id
    }

    func cancel(_ id: UUID) {
        guard let record = records.first(where: { $0.id == id }) else { return }
        session.getAllTasks { [weak self] tasks in
            guard let task = tasks.first(where: { $0.taskIdentifier == record.taskIdentifier }) else { return }
            if let downloadTask = task as? URLSessionDownloadTask {
                downloadTask.cancel(byProducingResumeData: { resumeData in
                    Task { @MainActor [weak self] in
                        self?.update(id) {
                            $0.resumeData = resumeData
                            $0.state = .cancelled
                        }
                    }
                })
            } else {
                task.cancel()
                Task { @MainActor [weak self] in self?.update(id) { $0.state = .cancelled } }
            }
        }
    }

    func resume(_ id: UUID) {
        guard let index = records.firstIndex(where: { $0.id == id }), let data = records[index].resumeData else { return }
        let task = session.downloadTask(withResumeData: data)
        recordIDs[task.taskIdentifier] = id
        destinations[task.taskIdentifier] = records[index].localURL
        records[index].state = .running
        records[index].resumeData = nil
        task.resume()
    }

    func removeFinished() {
        records.removeAll { $0.state == .finished || $0.state == .failed || $0.state == .cancelled }
    }

    private func update(_ id: UUID, _ change: (inout NetworkTransferRecord) -> Void) {
        guard let index = records.firstIndex(where: { $0.id == id }) else { return }
        change(&records[index])
    }

}

extension BackgroundTransferService: URLSessionDownloadDelegate, URLSessionTaskDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let taskID = downloadTask.taskIdentifier
        Task { @MainActor [weak self] in
            guard let self, let id = self.recordIDs[taskID], let destination = self.destinations[taskID] else { return }
            do {
                try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
                try FileManager.default.moveItem(at: location, to: destination)
                self.update(id) { $0.progress = 1; $0.state = .finished }
                NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
            } catch {
                self.update(id) { $0.state = .failed; $0.errorMessage = error.localizedDescription }
            }
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        Task { @MainActor [weak self] in
            guard let self, let id = self.recordIDs[downloadTask.taskIdentifier] else { return }
            self.update(id) { $0.progress = progress }
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        guard totalBytesExpectedToSend > 0 else { return }
        let progress = Double(totalBytesSent) / Double(totalBytesExpectedToSend)
        Task { @MainActor [weak self] in
            guard let self, let id = self.recordIDs[task.taskIdentifier] else { return }
            self.update(id) { $0.progress = progress }
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        if let response = response as? HTTPURLResponse {
            Task { @MainActor [weak self] in self?.responses[task.taskIdentifier] = response }
        }
        completionHandler(.allow)
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let taskID = task.taskIdentifier
        Task { @MainActor [weak self] in
            guard let self, let id = self.recordIDs[taskID] else { return }
            if let error {
                if (error as NSError).code == NSURLErrorCancelled { return }
                self.update(id) { $0.state = .failed; $0.errorMessage = error.localizedDescription }
            } else if task is URLSessionUploadTask {
                let status = self.responses[taskID]?.statusCode ?? 200
                if (200...299).contains(status) {
                    self.update(id) { $0.progress = 1; $0.state = .finished }
                } else {
                    self.update(id) { $0.state = .failed; $0.errorMessage = "Server returned HTTP \(status)." }
                }
            }
        }
    }
}
