import Foundation
import CryptoKit

struct EncryptionService {
    static func encrypt(_ url: URL, password: String) throws -> URL {
        let data = try Data(contentsOf: url)
        let key = SymmetricKey(data: SHA256.hash(data: Data(password.utf8)))
        let sealedBox = try AES.GCM.seal(data, using: key)
        
        guard let encryptedData = sealedBox.combined else {
            throw NSError(domain: "Encryption", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to encrypt data."])
        }
        
        let newURL = url.deletingLastPathComponent().appendingPathComponent("\(url.lastPathComponent).enc")
        try encryptedData.write(to: newURL)
        return newURL
    }
    
    static func decrypt(_ url: URL, password: String) throws -> URL {
        let encryptedData = try Data(contentsOf: url)
        let key = SymmetricKey(data: SHA256.hash(data: Data(password.utf8)))
        
        do {
            let sealedBox = try AES.GCM.SealedBox(combined: encryptedData)
            let decryptedData = try AES.GCM.open(sealedBox, using: key)
            
            let fileName = url.lastPathComponent.replacingOccurrences(of: ".enc", with: "")
            let newURL = url.deletingLastPathComponent().appendingPathComponent(fileName)
            try decryptedData.write(to: newURL)
            return newURL
        } catch {
            throw NSError(domain: "Decryption", code: -2, userInfo: [NSLocalizedDescriptionKey: "Incorrect password or corrupted file."])
        }
    }
}
