import Foundation

struct FileSystemService {
    private let fm = FileManager.default

    var trashURL: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let trash = docs.appendingPathComponent(".Trash")
        if !fm.fileExists(atPath: trash.path) {
            try? fm.createDirectory(at: trash, withIntermediateDirectories: true)
        }
        return trash
    }
    
    var hiddenURL: URL {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let hidden = docs.appendingPathComponent(".HiddenFolders")
        if !fm.fileExists(atPath: hidden.path) {
            try? fm.createDirectory(at: hidden, withIntermediateDirectories: true)
        }
        return hidden
    }

    func list(_ dir: URL, showHidden: Bool) throws -> [FileItem] {
        try fm.contentsOfDirectory(
            at: dir,
            includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey],
            options: showHidden ? [] : [.skipsHiddenFiles]
        ).map(FileItem.init(url:))
    }

    func uniqueURL(_ name: String, in dir: URL) -> URL {
        var candidate = dir.appendingPathComponent(name)
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var n = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = dir.appendingPathComponent(ext.isEmpty ? "\(base) \(n)" : "\(base) \(n).\(ext)")
            n += 1
        }
        return candidate
    }

    func createFolder(_ name: String, in dir: URL) throws {
        try fm.createDirectory(at: uniqueURL(name, in: dir), withIntermediateDirectories: false)
    }
    func rename(_ url: URL, to name: String) throws {
        let dest = url.deletingLastPathComponent().appendingPathComponent(name)
        guard !fm.fileExists(atPath: dest.path) else { throw CocoaError(.fileWriteFileExists) }
        try fm.moveItem(at: url, to: dest)
    }
    func copy(_ urls: [URL], to dir: URL) throws {
        for u in urls { try fm.copyItem(at: u, to: uniqueURL(u.lastPathComponent, in: dir)) }
    }
    func move(_ urls: [URL], to dir: URL) throws {
        for u in urls { try fm.moveItem(at: u, to: uniqueURL(u.lastPathComponent, in: dir)) }
    }
    func delete(_ urls: [URL]) throws {
        for u in urls { try fm.removeItem(at: u) }
    }
    
    func moveToTrash(_ urls: [URL]) throws {
        for u in urls { try fm.moveItem(at: u, to: uniqueURL(u.lastPathComponent, in: trashURL)) }
    }
    func restoreFromTrash(_ urls: [URL]) throws {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        for u in urls { try fm.moveItem(at: u, to: uniqueURL(u.lastPathComponent, in: docs)) }
    }
    func emptyTrash() throws {
        let items = try fm.contentsOfDirectory(at: trashURL, includingPropertiesForKeys: nil)
        for item in items { try fm.removeItem(at: item) }
    }
    
    func purgeOldTrashItems(days: Int) {
        guard let items = try? fm.contentsOfDirectory(at: trashURL, includingPropertiesForKeys: [.contentModificationDateKey]) else { return }
        let cutoffDate = Date().addingTimeInterval(-Double(days * 24 * 60 * 60))
        for item in items {
            if let attrs = try? item.resourceValues(forKeys: [.contentModificationDateKey]),
               let modDate = attrs.contentModificationDate,
               modDate < cutoffDate {
                try? fm.removeItem(at: item)
            }
        }
    }
    
    func moveToHidden(_ urls: [URL]) throws {
        for u in urls { let started = u.startAccessingSecurityScopedResource(); defer { if started { u.stopAccessingSecurityScopedResource() } }; try fm.moveItem(at: u, to: uniqueURL(u.lastPathComponent, in: hiddenURL)) }
    }
    func restoreFromHidden(_ urls: [URL]) throws {
        let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        for u in urls { let started = u.startAccessingSecurityScopedResource(); defer { if started { u.stopAccessingSecurityScopedResource() } }; try fm.moveItem(at: u, to: uniqueURL(u.lastPathComponent, in: docs)) }
    }
    
    // 🔥 FIXED: This was missing. It handles the "Find & Replace" batch renaming.
    func batchReplace(_ urls: [URL], find: String, replace: String) throws {
        for url in urls {
            let oldName = url.lastPathComponent
            if oldName.contains(find) {
                let newName = oldName.replacingOccurrences(of: find, with: replace)
                let dest = url.deletingLastPathComponent().appendingPathComponent(newName)
                let finalDest = fm.fileExists(atPath: dest.path) ? uniqueURL(newName, in: url.deletingLastPathComponent()) : dest
                try fm.moveItem(at: url, to: finalDest)
            }
        }
    }
    
    func batchRename(_ urls: [URL], baseName: String) throws {
        let sorted = urls.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        for (index, url) in sorted.enumerated() {
            let ext = url.pathExtension
            let newName = ext.isEmpty ? "\(baseName) \(index + 1)" : "\(baseName) \(index + 1).\(ext)"
            let dest = url.deletingLastPathComponent().appendingPathComponent(newName)
            let finalDest = fm.fileExists(atPath: dest.path) ? uniqueURL(newName, in: url.deletingLastPathComponent()) : dest
            try fm.moveItem(at: url, to: finalDest)
        }
    }

    nonisolated func splitFile(_ url: URL, chunkSizeMB: Int) throws -> [URL] {
        let chunkSize = chunkSizeMB * 1024 * 1024
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var partNumber = 1
        var chunkURLs: [URL] = []
        let directory = url.deletingLastPathComponent()
        let baseName = url.lastPathComponent
        while true {
            let data = try handle.read(upToCount: chunkSize) ?? Data()
            if data.isEmpty { break }
            let partName = "\(baseName).part\(partNumber)"
            let partURL = directory.appendingPathComponent(partName)
            if fm.fileExists(atPath: partURL.path) { try? fm.removeItem(at: partURL) }
            try data.write(to: partURL)
            chunkURLs.append(partURL)
            partNumber += 1
        }
        return chunkURLs
    }

    nonisolated func mergeFiles(_ urls: [URL], outputURL: URL) throws {
        let sorted = urls.sorted { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }
        fm.createFile(atPath: outputURL.path, contents: nil)
        let outputHandle = try FileHandle(forWritingTo: outputURL)
        defer { try? outputHandle.close() }
        for url in sorted {
            let inputHandle = try FileHandle(forReadingFrom: url)
            defer { try? inputHandle.close() }
            while let data = try inputHandle.read(upToCount: 1024 * 1024), !data.isEmpty {
                try outputHandle.write(contentsOf: data)
            }
        }
    }

    func updatePermissions(_ url: URL, mode: Int) throws {
        try fm.setAttributes([.posixPermissions: mode], ofItemAtPath: url.path)
    }
    
    func updateModificationDate(_ url: URL, date: Date) throws {
        try fm.setAttributes([.modificationDate: date], ofItemAtPath: url.path)
    }

    nonisolated func calculateFolderSize(_ url: URL) -> Int64 {
        var size: Int64 = 0
        if let enumerator = FileManager.default.enumerator(at: url, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles]) {
            for case let fileURL as URL in enumerator {
                if let fileSize = try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize {
                    size += Int64(fileSize)
                }
            }
        }
        return size
    }
}
