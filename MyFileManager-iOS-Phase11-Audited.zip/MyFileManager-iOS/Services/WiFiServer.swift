import Foundation
import Network

class WiFiServer {
    private var listener: NWListener?
    var rootDirectory: URL?
    var onStatusChange: ((Bool, String) -> Void)?
    
    func start() {
        let params = NWParameters.tcp
        params.allowLocalEndpointReuse = true
        
        do {
            listener = try NWListener(using: params, on: 8080)
            listener?.stateUpdateHandler = { [weak self] state in
                switch state {
                case .ready:
                    let ip = self?.getIPAddress() ?? "Unknown IP"
                    DispatchQueue.main.async { self?.onStatusChange?(true, ip) }
                case .failed, .cancelled:
                    DispatchQueue.main.async { self?.onStatusChange?(false, "") }
                default:
                    break
                }
            }
            
            listener?.newConnectionHandler = { [weak self] connection in
                connection.start(queue: .global())
                self?.handleConnection(connection)
            }
            
            listener?.start(queue: .global())
        } catch {
            print("Failed to start server: \(error)")
        }
    }
    
    func stop() {
        listener?.cancel()
        listener = nil
        onStatusChange?(false, "")
    }
    
    private func handleConnection(_ connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, isComplete, error in
            guard let data = data, !data.isEmpty else {
                connection.cancel()
                return
            }
            
            if let requestString = String(data: data, encoding: .utf8) {
                self?.routeRequest(requestString, data: data, connection: connection)
            }
        }
    }
    
    private func routeRequest(_ request: String, data: Data, connection: NWConnection) {
        let firstLine = request.components(separatedBy: "\r\n").first ?? ""
        
        if firstLine.hasPrefix("GET / HTTP") {
            sendHTML(connection)
        } else if firstLine.hasPrefix("GET /download") {
            handleDownload(request, connection: connection)
        } else if firstLine.hasPrefix("POST /upload") {
            handleUpload(request, data: data, connection: connection)
        } else {
            sendResponse(connection, status: "404 Not Found", contentType: "text/plain", body: "Not Found".data(using: .utf8)!)
        }
    }
    
    private func sendHTML(_ connection: NWConnection) {
        guard let root = rootDirectory else { return }
        let files = (try? FileManager.default.contentsOfDirectory(atPath: root.path)) ?? []
        
        var fileRows = ""
        for file in files where !file.hasPrefix(".") {
            if let encoded = file.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                fileRows += "<li><a href='/download?file=\(encoded)'>\(file)</a></li>"
            }
        }
        
        let html = """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Wi-Fi File Server</title>
            <style>
                body { font-family: -apple-system, sans-serif; padding: 20px; background: #f2f2f7; }
                h1 { text-align: center; color: #1c1c1e; }
                .card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin-bottom: 20px; }
                ul { list-style: none; padding: 0; }
                li { padding: 10px 0; border-bottom: 1px solid #e5e5ea; }
                a { text-decoration: none; color: #007aff; font-weight: 500; }
                input[type="file"] { margin-bottom: 10px; }
                button { background: #007aff; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; width: 100%; font-size: 16px; }
            </style>
        </head>
        <body>
            <h1>📁 My FileManager</h1>
            <div class="card">
                <h3>Upload File</h3>
                <input type="file" id="fileInput" multiple>
                <button onclick="uploadFiles()">Upload to iPhone</button>
                <p id="status" style="color: green; text-align: center;"></p>
            </div>
            <div class="card">
                <h3>Files on iPhone (\(files.count))</h3>
                <ul>\(fileRows)</ul>
            </div>
            <script>
                async function uploadFiles() {
                    const files = document.getElementById('fileInput').files;
                    const status = document.getElementById('status');
                    if (files.length === 0) return;
                    
                    for (let i = 0; i < files.length; i++) {
                        status.innerText = `Uploading ${files[i].name}...`;
                        await fetch('/upload?name=' + encodeURIComponent(files[i].name), {
                            method: 'POST',
                            body: files[i]
                        });
                    }
                    status.innerText = "Upload complete!";
                    setTimeout(() => location.reload(), 1000);
                }
            </script>
        </body>
        </html>
        """
        
        sendResponse(connection, status: "200 OK", contentType: "text/html", body: html.data(using: .utf8)!)
    }
    
    private func handleDownload(_ request: String, connection: NWConnection) {
        guard let root = rootDirectory,
              let urlComponents = request.components(separatedBy: "\r\n").first?.components(separatedBy: " "),
              urlComponents.count > 1,
              let fileName = urlComponents[1].components(separatedBy: "file=").last?.removingPercentEncoding else {
            sendResponse(connection, status: "400 Bad Request", contentType: "text/plain", body: "Bad Request".data(using: .utf8)!)
            return
        }
        
        guard let fileURL = safeFileURL(named: fileName, in: root) else {
            sendResponse(connection, status: "400 Bad Request", contentType: "text/plain", body: "Invalid path".data(using: .utf8)!)
            return
        }
        guard let fileData = try? Data(contentsOf: fileURL) else {
            sendResponse(connection, status: "404 Not Found", contentType: "text/plain", body: "File not found".data(using: .utf8)!)
            return
        }
        
        let header = "HTTP/1.1 200 OK\r\nContent-Disposition: attachment; filename=\"\(fileName)\"\r\nContent-Length: \(fileData.count)\r\nConnection: close\r\n\r\n"
        var response = header.data(using: .utf8)!
        response.append(fileData)
        
        connection.send(content: response, completion: .contentProcessed({ _ in connection.cancel() }))
    }
    
    private func handleUpload(_ request: String, data: Data, connection: NWConnection) {
        guard let root = rootDirectory,
              let headersEnd = data.range(of: Data("\r\n\r\n".utf8)) else {
            connection.cancel()
            return
        }
        
        // Extract filename from URL parameters
        guard let firstLine = request.components(separatedBy: "\r\n").first,
              let fileNameEncoded = firstLine.components(separatedBy: "name=").last?.components(separatedBy: " ").first,
              let fileName = fileNameEncoded.removingPercentEncoding else {
            sendResponse(connection, status: "400 Bad Request", contentType: "text/plain", body: "No filename".data(using: .utf8)!)
            return
        }
        
        let fileData = data.subdata(in: headersEnd.upperBound..<data.count)
        guard let destURL = safeFileURL(named: fileName, in: root) else {
            sendResponse(connection, status: "400 Bad Request", contentType: "text/plain", body: "Invalid path".data(using: .utf8)!)
            return
        }
        
        do {
            try fileData.write(to: destURL)
            sendResponse(connection, status: "200 OK", contentType: "text/plain", body: "Uploaded".data(using: .utf8)!)
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch {
            sendResponse(connection, status: "500 Error", contentType: "text/plain", body: "Write Error".data(using: .utf8)!)
        }
    }

    private func safeFileURL(named name: String, in root: URL) -> URL? {
        let rootURL = root.standardizedFileURL
        let candidate = rootURL.appendingPathComponent(name).standardizedFileURL
        let rootPath = rootURL.path.hasSuffix("/") ? rootURL.path : rootURL.path + "/"
        return candidate.path == rootURL.path || candidate.path.hasPrefix(rootPath) ? candidate : nil
    }
    
    private func sendResponse(_ connection: NWConnection, status: String, contentType: String, body: Data) {
        let headerString = "HTTP/1.1 \(status)\r\nContent-Type: \(contentType)\r\nContent-Length: \(body.count)\r\nConnection: close\r\n\r\n"
        var response = headerString.data(using: .utf8)!
        response.append(body)
        connection.send(content: response, completion: .contentProcessed({ _ in connection.cancel() }))
    }
    
    private func getIPAddress() -> String {
        var address: String = "unknown"
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        if getifaddrs(&ifaddr) == 0 {
            var ptr = ifaddr
            while ptr != nil {
                defer { ptr = ptr?.pointee.ifa_next }
                let interface = ptr?.pointee
                let addrFamily = interface?.ifa_addr.pointee.sa_family
                if addrFamily == UInt8(AF_INET) {
                    let name = String(cString: (interface?.ifa_name)!)
                    if name == "en0" {
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        getnameinfo(interface?.ifa_addr, socklen_t((interface?.ifa_addr.pointee.sa_len)!), &hostname, socklen_t(hostname.count), nil, socklen_t(0), NI_NUMERICHOST)
                        address = String(cString: hostname)
                    }
                }
            }
            freeifaddrs(ifaddr)
        }
        return address
    }
}
