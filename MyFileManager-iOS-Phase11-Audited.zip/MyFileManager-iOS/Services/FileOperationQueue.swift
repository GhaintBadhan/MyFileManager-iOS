import Foundation
import Combine

struct FileOperationRecord: Identifiable {
    enum Kind: String, Equatable {
        case copy = "Copy"
        case move = "Move"
    }

    enum State, Equatable {
        case queued
        case running
        case finished
        case failed
        case cancelled
    }

    let id: UUID
    let kind: Kind
    let sourceCount: Int
    let destination: URL
    var completedCount: Int = 0
    var skippedCount: Int = 0
    var currentName: String = ""
    var state: State = .queued
    var errorMessage: String?

    var progress: Double {
        guard sourceCount > 0 else { return 1 }
        return Double(completedCount + skippedCount) / Double(sourceCount)
    }
}

enum FileConflictChoice, Equatable {
    case replace
    case skip
    case rename
}

struct FileConflictRequest: Identifiable {
    let id: UUID
    let operationID: UUID
    let sourceName: String
    let destination: URL
}

/// Serializes filesystem operations and pauses only for explicit collisions.
/// It stores task metadata, never file contents, so the operation UI stays cheap.
@MainActor
final class FileOperationQueue: ObservableObject {
    static let shared = FileOperationQueue()

    @Published private(set) var records: [FileOperationRecord] = []
    @Published var conflictRequest: FileConflictRequest?

    private var workers: [UUID: Task<Void, Never>] = [:]
    private var conflictContinuations: [UUID: CheckedContinuation<FileConflictChoice, Never>] = [:]
    private var applyToAll: [UUID: FileConflictChoice] = [:]

    var activeRecords: [FileOperationRecord] {
        records.filter { $0.state == .queued || $0.state == .running }
    }

    private init() {}

    func enqueueCopy(_ urls: [URL], to destination: URL) {
        enqueue(kind: .copy, urls: urls, destination: destination)
    }

    func enqueueMove(_ urls: [URL], to destination: URL) {
        enqueue(kind: .move, urls: urls, destination: destination)
    }

    func cancel(_ id: UUID) {
        workers[id]?.cancel()
        workers[id] = nil
        conflictContinuations[id]?.resume(returning: .skip)
        conflictContinuations[id] = nil
        conflictRequest = nil
        update(id) { record in
            guard record.state == .queued || record.state == .running else { return }
            record.state = .cancelled
        }
    }

    func resolveConflict(_ choice: FileConflictChoice, applyToAll: Bool = false) {
        guard let request = conflictRequest else { return }
        if applyToAll { self.applyToAll[request.operationID] = choice }
        conflictRequest = nil
        conflictContinuations[request.operationID]?.resume(returning: choice)
        conflictContinuations[request.operationID] = nil
    }

    func removeFinished() {
        records.removeAll { $0.state == .finished || $0.state == .failed || $0.state == .cancelled }
    }

    private func enqueue(kind: FileOperationRecord.Kind, urls: [URL], destination: URL) {
        guard !urls.isEmpty else { return }
        let id = UUID()
        records.append(FileOperationRecord(id: id, kind: kind, sourceCount: urls.count, destination: destination))
        workers[id] = Task { [weak self] in
            guard let self else { return }
            await self.run(id: id, kind: kind, urls: urls, destination: destination)
        }
    }

    private func run(id: UUID, kind: FileOperationRecord.Kind, urls: [URL], destination: URL) async {
        update(id) { $0.state = .running }

        do {
            for (index, url) in urls.enumerated() {
                try Task.checkCancellation()
                update(id) {
                    $0.currentName = url.lastPathComponent
                    $0.completedCount = index - $0.skippedCount
                }

                let candidate = destination.appendingPathComponent(url.lastPathComponent)
                var choice: FileConflictChoice?
                if url.standardizedFileURL == candidate.standardizedFileURL {
                    choice = .rename
                } else if FileManager.default.fileExists(atPath: candidate.path) {
                    choice = applyToAll[id] ?? await requestConflict(
                        operationID: id,
                        sourceName: url.lastPathComponent,
                        destination: destination
                    )
                }

                if choice == .skip {
                    update(id) { $0.skippedCount += 1 }
                    continue
                }

                let result: Result<Void, Error> = await Task.detached(priority: .userInitiated) {
                    do {
                        let started = url.startAccessingSecurityScopedResource()
                        defer { if started { url.stopAccessingSecurityScopedResource() } }
                        let worker = FileSystemService()
                        if choice == .replace {
                            try? FileManager.default.removeItem(at: candidate)
                        }
                        if kind == .copy {
                            try worker.copy([url], to: destination)
                        } else {
                            try worker.move([url], to: destination)
                        }
                        return .success(())
                    } catch {
                        return .failure(error)
                    }
                }.value

                if case .failure(let error) = result { throw error }
                update(id) { $0.completedCount = index + 1 - $0.skippedCount }
            }
            update(id) {
                $0.currentName = ""
                $0.state = .finished
            }
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
        } catch is CancellationError {
            update(id) { $0.state = .cancelled }
        } catch {
            update(id) {
                $0.state = .failed
                $0.errorMessage = error.localizedDescription
            }
        }

        workers[id] = nil
        conflictContinuations[id] = nil
        applyToAll[id] = nil
    }

    private func requestConflict(operationID: UUID, sourceName: String, destination: URL) async -> FileConflictChoice {
        await withCheckedContinuation { continuation in
            conflictContinuations[operationID] = continuation
            conflictRequest = FileConflictRequest(
                id: UUID(),
                operationID: operationID,
                sourceName: sourceName,
                destination: destination
            )
        }
    }

    private func update(_ id: UUID, _ change: (inout FileOperationRecord) -> Void) {
        guard let index = records.firstIndex(where: { $0.id == id }) else { return }
        change(&records[index])
    }
}
