import Foundation

struct WebDAVItem: Identifiable {
    let id = UUID()
    let name: String
    let url: URL
    let isDirectory: Bool
    let size: Int64
    let modified: Date?
}

enum WebDAVError: LocalizedError {
    case invalidCredentials
    case serverError
    case parseError
    var errorDescription: String? {
        switch self {
        case .invalidCredentials: return "Invalid username or password."
        case .serverError: return "The server returned an error."
        case .parseError: return "Failed to read the server's response."
        }
    }
}

class WebDAVService: NSObject, XMLParserDelegate {
    private var baseURL: URL
    private var username: String
    private var password: String
    
    // Parser state
    private var items: [WebDAVItem] = []
    private var currentElement = ""
    private var currentHref = ""
    private var currentSize: Int64 = 0
    private var currentModified: Date?
    private var isDirectory = false
    
    init(url: URL, username: String, password: String) {
        self.baseURL = url
        self.username = username
        self.password = password
    }
    
    private func createRequest(url: URL, method: String) -> URLRequest {
        var request = URLRequest(url: url)
        request.httpMethod = method
        let loginString = String(format: "%@:%@", username, password)
        let loginData = loginString.data(using: String.Encoding.utf8)!
        let base64LoginString = loginData.base64EncodedString()
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        return request
    }

    func downloadRequest(for url: URL) -> URLRequest {
        createRequest(url: url, method: "GET")
    }

    func uploadRequest(for url: URL) -> URLRequest {
        var request = createRequest(url: url, method: "PUT")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        return request
    }
    
    func listDirectory(at url: URL) async throws -> [WebDAVItem] {
        var request = createRequest(url: url, method: "PROPFIND")
        request.setValue("1", forHTTPHeaderField: "Depth")
        request.setValue("application/xml", forHTTPHeaderField: "Content-Type")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw WebDAVError.serverError
        }
        
        items = []
        let parser = XMLParser(data: data)
        parser.delegate = self
        if parser.parse() {
            return items.count > 1 ? Array(items.dropFirst()) : items
        } else {
            throw WebDAVError.parseError
        }
    }
    
    func downloadFile(at url: URL, to localURL: URL) async throws {
        let request = createRequest(url: url, method: "GET")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw WebDAVError.serverError
        }
        try data.write(to: localURL)
    }
    
    // 🔥 NEW: Upload File
    func uploadFile(localURL: URL, to remoteURL: URL) async throws {
        let data = try Data(contentsOf: localURL)
        var request = createRequest(url: remoteURL, method: "PUT")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
        
        let (_, response) = try await URLSession.shared.upload(for: request, from: data)
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw WebDAVError.serverError
        }
    }
    
    // 🔥 NEW: Create Folder
    func createFolder(name: String, at parentURL: URL) async throws {
        let folderURL = parentURL.appendingPathComponent(name)
        let request = createRequest(url: folderURL, method: "MKCOL")
        
        let (_, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            throw WebDAVError.serverError
        }
    }
    
    // XML Parser Delegates
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentElement = elementName
        if elementName == "d:response" || elementName == "response" {
            currentHref = ""; currentSize = 0; currentModified = nil; isDirectory = false
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let text = string.trimmingCharacters(in: .whitespacesAndNewlines)
        if currentElement == "d:href" || currentElement == "href" { currentHref += text }
        else if currentElement == "d:getcontentlength" || currentElement == "getcontentlength" { currentSize = Int64(text) ?? 0 }
        else if currentElement == "d:getlastmodified" || currentElement == "getlastmodified" {
            let formatter = DateFormatter()
            formatter.dateFormat = "EEE, dd MMM yyyy HH:mm:ss zzz"
            currentModified = formatter.date(from: text)
        } else if currentElement == "d:collection" || currentElement == "collection" { isDirectory = true }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "d:response" || elementName == "response" {
            if !currentHref.isEmpty, let itemURL = URL(string: currentHref, relativeTo: baseURL) {
                let name = itemURL.lastPathComponent.removingPercentEncoding ?? itemURL.lastPathComponent
                if !name.isEmpty {
                    items.append(WebDAVItem(name: name, url: itemURL, isDirectory: isDirectory, size: currentSize, modified: currentModified))
                }
            }
        }
    }
}
