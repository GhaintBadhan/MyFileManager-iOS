import Foundation
import CryptoKit

enum HashAlgorithm: String, CaseIterable {
    case md5 = "MD5", sha1 = "SHA-1", sha256 = "SHA-256", sha512 = "SHA-512"
}

enum HashService {
    static func hash(_ url: URL, _ algorithm: HashAlgorithm) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        switch algorithm {
        case .md5:    var h = Insecure.MD5();    try feed(handle) { h.update(data: $0) }; return hex(h.finalize())
        case .sha1:   var h = Insecure.SHA1();   try feed(handle) { h.update(data: $0) }; return hex(h.finalize())
        case .sha256: var h = SHA256();          try feed(handle) { h.update(data: $0) }; return hex(h.finalize())
        case .sha512: var h = SHA512();          try feed(handle) { h.update(data: $0) }; return hex(h.finalize())
        }
    }
    private static func feed(_ handle: FileHandle, _ body: (Data) -> Void) throws {
        while let chunk = try handle.read(upToCount: 1 << 20), !chunk.isEmpty { body(chunk) }
    }
    private static func hex<D: Digest>(_ digest: D) -> String {
        digest.map { String(format: "%02x", $0) }.joined()
    }
}
