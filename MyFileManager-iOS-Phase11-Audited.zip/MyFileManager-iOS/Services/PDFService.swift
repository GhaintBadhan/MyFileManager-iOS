import Foundation
import PDFKit

enum PDFError: LocalizedError {
    case invalidPDF
    case writeFailed
    var errorDescription: String? {
        switch self {
        case .invalidPDF: return "Could not read the PDF file."
        case .writeFailed: return "Failed to save the PDF."
        }
    }
}

struct PDFService {
    static func mergePDFs(urls: [URL], outputURL: URL) throws {
        let mergedDocument = PDFDocument()
        
        for url in urls {
            guard let document = PDFDocument(url: url) else { throw PDFError.invalidPDF }
            for i in 0..<document.pageCount {
                if let page = document.page(at: i) {
                    mergedDocument.insert(page, at: mergedDocument.pageCount)
                }
            }
        }
        
        guard mergedDocument.write(to: outputURL) else { throw PDFError.writeFailed }
    }
    
    static func splitPDF(url: URL, outputDirectory: URL) throws -> [URL] {
        guard let document = PDFDocument(url: url) else { throw PDFError.invalidPDF }
        
        let baseName = url.deletingPathExtension().lastPathComponent
        var createdURLs: [URL] = []
        
        for i in 0..<document.pageCount {
            if let page = document.page(at: i) {
                let singlePageDoc = PDFDocument()
                singlePageDoc.insert(page, at: 0)
                
                let newName = "\(baseName)_page\(i + 1).pdf"
                let newURL = outputDirectory.appendingPathComponent(newName)
                
                if singlePageDoc.write(to: newURL) {
                    createdURLs.append(newURL)
                }
            }
        }
        
        return createdURLs
    }
}
