import Foundation
import WebKit
import Combine

struct ActiveDownload: Identifiable {
    let id: UUID
    var fileName: String
    var progress: Double
    var isFinished: Bool
    var isFailed: Bool = false
    var failureReason: String? = nil
    var url: URL
    
    // 🔥 NEW: Tracking metrics
    var downloadedBytes: Int64 = 0
    var totalBytes: Int64 = 0
    var speedBytesPerSecond: Double = 0
}

@MainActor
class DownloadManager: NSObject, ObservableObject {
    static let shared = DownloadManager()
    
    @Published var activeDownloads: [ActiveDownload] = []
    
    private var session: URLSession!
    private var taskToIdMap: [Int: UUID] = [:]
    private var activeTasks: [UUID: URLSessionDownloadTask] = [:]
    
    // Internal trackers for speed calculation
    private var lastUpdateTimeMap: [Int: Date] = [:]
    private var lastBytesMap: [Int: Int64] = [:]
    
    override init() {
        super.init()
        let config = URLSessionConfiguration.default
        config.waitsForConnectivity = true
        
        self.session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }
    
    func startDownload(url: URL, referer: String? = nil) {
        if url.absoluteString.hasPrefix("blob:") {
            let download = ActiveDownload(id: UUID(), fileName: "Unknown_File", progress: 0, isFinished: true, isFailed: true, failureReason: "Cannot download blob URLs.", url: url)
            self.activeDownloads.append(download)
            return
        }
        
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self else { return }
            
            let downloadId = UUID()
            
            Task { @MainActor in
                var request = URLRequest(url: url)
                request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
                
                if let referer = referer {
                    request.setValue(referer, forHTTPHeaderField: "Referer")
                }
                
                let cookieHeaders = HTTPCookie.requestHeaderFields(with: cookies)
                for (key, value) in cookieHeaders {
                    request.setValue(value, forHTTPHeaderField: key)
                }
                
                let fileName = url.lastPathComponent.isEmpty ? "Download_\(UUID().uuidString.prefix(4))" : url.lastPathComponent
                let download = ActiveDownload(id: downloadId, fileName: fileName, progress: 0, isFinished: false, url: url)
                self.activeDownloads.append(download)
                
                let task = self.session.downloadTask(with: request)
                self.activeTasks[downloadId] = task
                self.taskToIdMap[task.taskIdentifier] = downloadId
                task.resume()
            }
        }
    }
    
    func cancelDownload(id: UUID) {
        activeTasks[id]?.cancel()
        activeTasks.removeValue(forKey: id)
        activeDownloads.removeAll { $0.id == id }
    }
}

extension DownloadManager: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let taskId = downloadTask.taskIdentifier
        
        Task { @MainActor in
            guard let downloadId = self.taskToIdMap[taskId],
                  let index = self.activeDownloads.firstIndex(where: { $0.id == downloadId }) else { return }
            
            // 🔥 SPEED CALCULATION (Throttled to update every 0.5s)
            let now = Date()
            let lastTime = self.lastUpdateTimeMap[taskId] ?? Date.distantPast
            let lastBytes = self.lastBytesMap[taskId] ?? 0
            let timeDiff = now.timeIntervalSince(lastTime)
            
            if timeDiff > 0.5 {
                let bytesDiff = totalBytesWritten - lastBytes
                let speed = Double(bytesDiff) / timeDiff
                
                self.activeDownloads[index].speedBytesPerSecond = speed
                self.lastUpdateTimeMap[taskId] = now
                self.lastBytesMap[taskId] = totalBytesWritten
            }
            
            self.activeDownloads[index].downloadedBytes = totalBytesWritten
            self.activeDownloads[index].totalBytes = totalBytesExpectedToWrite
            self.activeDownloads[index].progress = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        }
    }
    
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let taskId = downloadTask.taskIdentifier
        
        if let httpResponse = downloadTask.response as? HTTPURLResponse, httpResponse.statusCode >= 400 {
            Task { @MainActor in
                if let downloadId = self.taskToIdMap[taskId],
                   let index = self.activeDownloads.firstIndex(where: { $0.id == downloadId }) {
                    self.activeDownloads[index].isFailed = true
                    self.activeDownloads[index].failureReason = "Server returned error \(httpResponse.statusCode)"
                    self.activeDownloads[index].isFinished = true
                    self.activeTasks.removeValue(forKey: downloadId)
                }
            }
            return
        }
        
        let suggestedName = downloadTask.response?.suggestedFilename
        let originalName = downloadTask.originalRequest?.url?.lastPathComponent
        var finalName = suggestedName ?? originalName ?? "Download_\(UUID().uuidString.prefix(4))"
        
        finalName = finalName.replacingOccurrences(of: "&quot;", with: "\"")
        finalName = finalName.replacingOccurrences(of: "&amp;", with: "&")
        
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let destination = documentsURL.appendingPathComponent(finalName)
        
        do {
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: location, to: destination)
            
            Task { @MainActor in
                if let downloadId = self.taskToIdMap[taskId],
                   let index = self.activeDownloads.firstIndex(where: { $0.id == downloadId }) {
                    self.activeDownloads[index].fileName = finalName
                    self.activeDownloads[index].progress = 1.0
                    self.activeDownloads[index].isFinished = true
                    self.activeTasks.removeValue(forKey: downloadId)
                    NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                }
            }
        } catch {
            Task { @MainActor in
                if let downloadId = self.taskToIdMap[taskId],
                   let index = self.activeDownloads.firstIndex(where: { $0.id == downloadId }) {
                    self.activeDownloads[index].isFailed = true
                    self.activeDownloads[index].failureReason = error.localizedDescription
                    self.activeDownloads[index].isFinished = true
                    self.activeTasks.removeValue(forKey: downloadId)
                }
            }
        }
    }
    
    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            let taskId = task.taskIdentifier
            Task { @MainActor in
                if let downloadId = self.taskToIdMap[taskId],
                   let index = self.activeDownloads.firstIndex(where: { $0.id == downloadId }) {
                    self.activeDownloads[index].isFailed = true
                    self.activeDownloads[index].failureReason = error.localizedDescription
                    self.activeDownloads[index].isFinished = true
                    self.activeTasks.removeValue(forKey: downloadId)
                }
            }
        }
    }
}
