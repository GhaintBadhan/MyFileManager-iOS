import Foundation

struct TextDifference: Identifiable {
    enum Kind {
        case same
        case changed
        case leftOnly
        case rightOnly
    }

    let id: Int
    let lineNumber: Int
    let left: String?
    let right: String?
    let kind: Kind
}

struct FolderDifference: Identifiable {
    enum Kind {
        case same
        case changed
        case leftOnly
        case rightOnly
    }

    let id: String
    let path: String
    let leftSize: Int64?
    let rightSize: Int64?
    let kind: Kind
}

struct BinaryComparison {
    let leftSize: Int64
    let rightSize: Int64
    let leftHash: String
    let rightHash: String

    var isEqual: Bool { leftHash == rightHash }
}

enum ComparisonResult {
    case text([TextDifference])
    case folder([FolderDifference])
    case binary(BinaryComparison)
}

enum CompareError: LocalizedError {
    case unsupported
    case tooLarge
    case invalidFolder

    var errorDescription: String? {
        switch self {
        case .unsupported: return "This file type cannot be compared as text."
        case .tooLarge: return "The file is too large for an in-memory text comparison."
        case .invalidFolder: return "One of the selected folders could not be read."
        }
    }
}

enum CompareService {
    private static let textExtensions = Set(["txt", "md", "json", "swift", "html", "css", "js", "xml", "plist", "csv", "log"])
    private static let maximumTextBytes: Int64 = 2_000_000
    private static let maximumFolderEntries = 2_000

    static func compare(_ left: URL, _ right: URL) throws -> ComparisonResult {
        let leftValues = try left.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
        let rightValues = try right.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
        let leftDirectory = leftValues.isDirectory ?? false
        let rightDirectory = rightValues.isDirectory ?? false
        guard leftDirectory == rightDirectory else { throw CompareError.unsupported }

        if leftDirectory { return .folder(try compareFolders(left, right)) }
        if textExtensions.contains(left.pathExtension.lowercased()),
           textExtensions.contains(right.pathExtension.lowercased()) {
            return .text(try compareText(left, right))
        }

        let leftSize = Int64(leftValues.fileSize ?? 0)
        let rightSize = Int64(rightValues.fileSize ?? 0)
        return .binary(BinaryComparison(
            leftSize: leftSize,
            rightSize: rightSize,
            leftHash: try HashService.hash(left, .sha256),
            rightHash: try HashService.hash(right, .sha256)
        ))
    }

    private static func compareText(_ left: URL, _ right: URL) throws -> [TextDifference] {
        let leftData = try Data(contentsOf: left, options: .mappedIfSafe)
        let rightData = try Data(contentsOf: right, options: .mappedIfSafe)
        guard Int64(leftData.count) <= maximumTextBytes, Int64(rightData.count) <= maximumTextBytes else {
            throw CompareError.tooLarge
        }
        let leftLines = String(decoding: leftData, as: UTF8.self).components(separatedBy: .newlines)
        let rightLines = String(decoding: rightData, as: UTF8.self).components(separatedBy: .newlines)
        let count = min(max(leftLines.count, rightLines.count), 5_000)
        return (0..<count).map { index in
            let l = index < leftLines.count ? leftLines[index] : nil
            let r = index < rightLines.count ? rightLines[index] : nil
            let kind: TextDifference.Kind
            if l == r { kind = .same }
            else if l == nil { kind = .rightOnly }
            else if r == nil { kind = .leftOnly }
            else { kind = .changed }
            return TextDifference(id: index, lineNumber: index + 1, left: l, right: r, kind: kind)
        }
    }

    private static func compareFolders(_ left: URL, _ right: URL) throws -> [FolderDifference] {
        let leftEntries = try folderEntries(left)
        let rightEntries = try folderEntries(right)
        let paths = Set(leftEntries.keys).union(rightEntries.keys).sorted().prefix(maximumFolderEntries)
        return paths.map { path in
            let l = leftEntries[path]
            let r = rightEntries[path]
            let kind: FolderDifference.Kind
            if l == nil { kind = .rightOnly }
            else if r == nil { kind = .leftOnly }
            else if l == r { kind = .same }
            else { kind = .changed }
            return FolderDifference(id: path, path: path, leftSize: l, rightSize: r, kind: kind)
        }
    }

    private static func folderEntries(_ root: URL) throws -> [String: Int64] {
        guard let enumerator = FileManager.default.enumerator(
            at: root,
            includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey],
            options: [.skipsHiddenFiles]
        ) else { throw CompareError.invalidFolder }
        var entries: [String: Int64] = [:]
        for case let url as URL in enumerator {
            if entries.count >= maximumFolderEntries { break }
            let relative = url.path.replacingOccurrences(of: root.path + "/", with: "")
            let values = try url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey])
            entries[relative] = values.isDirectory == true ? -1 : Int64(values.fileSize ?? 0)
        }
        return entries
    }
}
