import Foundation

struct TarEntry: Identifiable {
    let id: String
    let name: String
    let size: Int
    let dataOffset: Int
    let isDirectory: Bool
}

enum ArchiveError: LocalizedError {
    case notSupported
    case failedToCreate
    case fileNotFound
    case archiveTooLarge
    case malformedArchive
    case unsafePath

    var errorDescription: String? {
        switch self {
        case .notSupported: return "Only uncompressed .tar archives are supported by the built-in archive engine."
        case .failedToCreate: return "Failed to create the archive."
        case .fileNotFound: return "The requested file was not found in the archive."
        case .archiveTooLarge: return "This archive exceeds the safe built-in inspection limit."
        case .malformedArchive: return "The archive is malformed or incomplete."
        case .unsafePath: return "The archive contains an unsafe path and was not extracted."
        }
    }
}

enum ArchiveService {
    private static let maximumArchiveBytes = 100 * 1_024 * 1_024

    static func extract(_ archive: URL, to dir: URL) throws {
        guard archive.pathExtension.lowercased() == "tar" else { throw ArchiveError.notSupported }
        try TarService.extract(archive, to: dir)
    }

    static func extractSpecific(_ archive: URL, filePath: String, to dir: URL) throws {
        try extractSpecific(archive, filePaths: [filePath], to: dir)
    }

    static func extractSpecific(_ archive: URL, filePaths: [String], to dir: URL) throws {
        guard archive.pathExtension.lowercased() == "tar" else { throw ArchiveError.notSupported }
        try TarService.extractSpecific(archive, filePaths: Set(filePaths), to: dir)
    }

    static func compress(_ urls: [URL], to dest: URL) throws {
        try TarService.create(from: urls, to: dest)
    }

    static func listContents(_ archiveURL: URL) throws -> [String] {
        try TarService.entries(in: archiveURL).map(\.name)
    }

    fileprivate static func loadArchive(_ url: URL) throws -> Data {
        let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
        guard size <= maximumArchiveBytes else { throw ArchiveError.archiveTooLarge }
        return try Data(contentsOf: url, options: .mappedIfSafe)
    }
}

enum TarService {
    private static let blockSize = 512
    private static let maximumEntries = 5_000

    static func entries(in tarURL: URL) throws -> [TarEntry] {
        try parse(ArchiveService.loadArchive(tarURL))
    }

    static func extract(_ tarURL: URL, to destDir: URL) throws {
        let data = try ArchiveService.loadArchive(tarURL)
        try extract(entries: parse(data), from: data, selected: nil, to: destDir)
    }

    static func extractSpecific(_ tarURL: URL, filePaths: Set<String>, to destDir: URL) throws {
        let data = try ArchiveService.loadArchive(tarURL)
        let parsed = try parse(data)
        guard parsed.contains(where: { filePaths.contains($0.name) }) else { throw ArchiveError.fileNotFound }
        try extract(entries: parsed, from: data, selected: filePaths, to: destDir)
    }

    private static func parse(_ data: Data) throws -> [TarEntry] {
        var offset = 0
        var entries: [TarEntry] = []
        while offset + blockSize <= data.count {
            let header = data.subdata(in: offset..<(offset + blockSize))
            if header.allSatisfy({ $0 == 0 }) { break }
            let name = stringField(header, start: 0, length: 100)
            guard !name.isEmpty else { throw ArchiveError.malformedArchive }
            let size = octalField(header, start: 124, length: 12)
            let type = header[156]
            let dataOffset = offset + blockSize
            guard size >= 0, dataOffset <= data.count, size <= data.count - dataOffset else {
                throw ArchiveError.malformedArchive
            }
            let isDirectory = type == 53 || name.hasSuffix("/")
            if type == 0 || type == 53 || type == 48 {
                entries.append(TarEntry(id: name, name: name, size: size, dataOffset: dataOffset, isDirectory: isDirectory))
            }
            if entries.count > maximumEntries { throw ArchiveError.archiveTooLarge }
            offset = dataOffset + size
            let remainder = offset % blockSize
            if remainder != 0 { offset += blockSize - remainder }
        }
        return entries
    }

    private static func extract(entries: [TarEntry], from data: Data, selected: Set<String>?, to destDir: URL) throws {
        try FileManager.default.createDirectory(at: destDir, withIntermediateDirectories: true)
        for entry in entries {
            if let selected, !selected.contains(entry.name) { continue }
            let destination = try safeDestination(for: entry.name, in: destDir)
            if entry.isDirectory {
                try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
                continue
            }
            try FileManager.default.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
            let bytes = data.subdata(in: entry.dataOffset..<(entry.dataOffset + entry.size))
            try bytes.write(to: destination, options: .atomic)
        }
    }

    private static func safeDestination(for entryName: String, in directory: URL) throws -> URL {
        let normalized = entryName.replacingOccurrences(of: "\\", with: "/")
        guard !normalized.hasPrefix("/"), !normalized.split(separator: "/").contains("..") else { throw ArchiveError.unsafePath }
        let root = directory.standardizedFileURL
        let candidate = root.appendingPathComponent(normalized).standardizedFileURL
        let rootPath = root.path.hasSuffix("/") ? root.path : root.path + "/"
        guard candidate.path == root.path || candidate.path.hasPrefix(rootPath) else { throw ArchiveError.unsafePath }
        return candidate
    }

    private static func stringField(_ data: Data, start: Int, length: Int) -> String {
        let field = data.subdata(in: start..<(start + length))
        let trimmed = field.prefix { $0 != 0 }
        return String(decoding: trimmed, as: UTF8.self).trimmingCharacters(in: .whitespaces)
    }

    private static func octalField(_ data: Data, start: Int, length: Int) -> Int {
        let field = stringField(data, start: start, length: length).trimmingCharacters(in: .whitespacesAndNewlines)
        return Int(field, radix: 8) ?? 0
    }

    static func create(from urls: [URL], to destURL: URL) throws {
        var tarData = Data()
        func addEntry(url: URL, relativePath: String) throws {
            let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
            let isDir = (attrs[.type] as? FileAttributeType) == .typeDirectory
            let fileSize = isDir ? 0 : (attrs[.size] as? Int64 ?? 0)
            var header = Data(repeating: 0, count: 512)
            let name = isDir ? relativePath + "/" : relativePath
            let nameData = name.data(using: .utf8)?.prefix(99) ?? Data()
            header.replaceSubrange(0..<nameData.count, with: nameData)
            header.replaceSubrange(100..<107, with: Data("0000644".utf8))
            header.replaceSubrange(108..<115, with: Data("0000000".utf8))
            header.replaceSubrange(116..<123, with: Data("0000000".utf8))
            let sizeData = Data(String(format: "%011o", fileSize).utf8)
            header.replaceSubrange(124..<124 + sizeData.count, with: sizeData)
            let mtimeData = Data(String(format: "%011o", Int(Date().timeIntervalSince1970)).utf8)
            header.replaceSubrange(136..<136 + mtimeData.count, with: mtimeData)
            header[156] = isDir ? 53 : 48
            header.replaceSubrange(257..<263, with: Data("ustar\0".utf8))
            header.replaceSubrange(263..<265, with: Data("00".utf8))
            for i in 148..<156 { header[i] = 32 }
            let checksum = header.reduce(0) { $0 + Int($1) }
            header.replaceSubrange(148..<156, with: Data((String(format: "%06o", checksum) + "\0 ").utf8))
            tarData.append(header)
            if isDir {
                for item in try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil) {
                    let child = relativePath.isEmpty ? item.lastPathComponent : "\(relativePath)/\(item.lastPathComponent)"
                    try addEntry(url: item, relativePath: child)
                }
            } else if fileSize > 0 {
                let fileData = try Data(contentsOf: url)
                tarData.append(fileData)
                let remainder = fileData.count % 512
                if remainder != 0 { tarData.append(Data(repeating: 0, count: 512 - remainder)) }
            }
        }
        for url in urls { try addEntry(url: url, relativePath: url.lastPathComponent) }
        tarData.append(Data(repeating: 0, count: 1024))
        try tarData.write(to: destURL, options: .atomic)
    }
}
