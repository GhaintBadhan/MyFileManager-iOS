import Foundation
import WebKit
import UIKit

class BrowserTab: Identifiable, ObservableObject {
    let id = UUID()
    let webView: WKWebView
    
    @Published var urlString: String
    @Published var title: String = "New Tab"
    @Published var estimatedProgress: Double = 0.0
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var isLoading: Bool = false
    @Published var snapshot: UIImage? = nil // 🔥 NEW: For Tab Previews
    
    init(urlString: String) {
        self.urlString = urlString
        self.webView = WKWebView()
    }
    
    // 🔥 NEW: Generates a screenshot of the webpage for the Tabs menu
    func takeSnapshot() {
        let config = WKSnapshotConfiguration()
        config.rect = CGRect(x: 0, y: 0, width: 300, height: 300)
        
        webView.takeSnapshot(with: config) { [weak self] image, error in
            if let image = image {
                DispatchQueue.main.async {
                    self?.snapshot = image
                }
            }
        }
    }
}

@MainActor
class BrowserManager: ObservableObject {
    static let shared = BrowserManager()
    
    @Published var tabs: [BrowserTab] = [BrowserTab(urlString: "https://www.google.com")]
    @Published var activeTabIndex: Int = 0
    
    var activeTab: BrowserTab { tabs[activeTabIndex] }
    
    private init() {}
    
    func addTab(url: URL) {
        let newTab = BrowserTab(urlString: url.absoluteString)
        newTab.webView.load(URLRequest(url: url))
        tabs.append(newTab)
        activeTabIndex = tabs.count - 1
    }
    
    func closeTab(at index: Int) {
        tabs.remove(at: index)
        if tabs.isEmpty {
            tabs.append(BrowserTab(urlString: "https://www.google.com"))
        }
        if activeTabIndex >= tabs.count {
            activeTabIndex = tabs.count - 1
        }
    }
}
