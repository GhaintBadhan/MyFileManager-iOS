import Foundation
import SwiftUI
import UIKit

// 🔥 NEW: Global Haptic Manager
class HapticManager {
    static let shared = HapticManager()
    func impact(style: UIImpactFeedbackGenerator.FeedbackStyle = .light) {
        let generator = UIImpactFeedbackGenerator(style: style)
        generator.impactOccurred()
    }
    func success() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
}

class TagManager: ObservableObject {
    static let shared = TagManager()
    @Published private var tags: [String: String] = UserDefaults.standard.dictionary(forKey: "FileColorTags") as? [String: String] ?? [:]
    
    func setTag(for url: URL, colorName: String?) {
        var current = tags
        if let colorName = colorName {
            current[url.path] = colorName
        } else {
            current.removeValue(forKey: url.path)
        }
        tags = current
        UserDefaults.standard.set(tags, forKey: "FileColorTags")
    }
    
    func getTagColor(for url: URL) -> Color? {
        guard let colorName = tags[url.path] else { return nil }
        switch colorName {
        case "red": return .red
        case "blue": return .blue
        case "green": return .green
        case "orange": return .orange
        case "purple": return .purple
        default: return nil
        }
    }
    
    func getTagName(for url: URL) -> String? {
        return tags[url.path]
    }
}

struct FileItem: Identifiable, Hashable {
    let url: URL
    let name: String
    let isDirectory: Bool
    let size: Int64
    let modified: Date?
    var id: URL { url }

    init(url: URL) {
        let v = try? url.resourceValues(forKeys: [.isDirectoryKey, .fileSizeKey, .contentModificationDateKey])
        self.url = url
        name = url.lastPathComponent
        isDirectory = v?.isDirectory ?? false
        size = Int64(v?.fileSize ?? 0)
        modified = v?.contentModificationDate
    }
    
    var isArchive: Bool {
        let ext = url.pathExtension.lowercased()
        return ["zip", "apk", "ipa", "tar", "gz", "7z", "rar"].contains(ext)
    }
    
    var iconName: String {
        if isDirectory { return "folder.fill" }
        let ext = url.pathExtension.lowercased()
        switch ext {
        case "png", "jpg", "jpeg", "gif", "webp", "heic": return "photo.fill"
        case "mp4", "mov", "mkv", "avi": return "video.fill"
        case "mp3", "wav", "m4a", "flac": return "music.note"
        case "zip", "tar", "gz", "7z", "rar": return "archivebox.fill"
        case "apk", "ipa": return "shippingbox.fill"
        case "swift", "js", "py", "html", "css", "json", "xml", "plist": return "curlybraces"
        case "pdf": return "doc.richtext.fill"
        case "txt", "md": return "doc.text.fill"
        default: return "doc.fill"
        }
    }
    
    var iconColor: Color {
        if isDirectory { return .blue }
        let ext = url.pathExtension.lowercased()
        switch ext {
        case "png", "jpg", "jpeg", "gif", "webp", "heic": return .purple
        case "mp4", "mov", "mkv", "avi": return .red
        case "mp3", "wav", "m4a", "flac": return .pink
        case "zip", "tar", "gz", "7z", "rar": return .brown
        case "apk", "ipa": return .green
        case "swift", "js", "py", "html", "css", "json", "xml", "plist": return .orange
        case "pdf": return .red
        default: return .gray
        }
    }
}

enum SortOption: String, CaseIterable, Identifiable {
    case name, size, date
    var id: String { rawValue }
}

final class Clipboard: ObservableObject {
    @Published var urls: [URL] = []
    @Published var isCut = false
    func set(_ urls: [URL], cut: Bool) { self.urls = urls; isCut = cut }
    func clear() { urls = []; isCut = false }
}

final class BookmarkStore: ObservableObject {
    struct Entry: Codable, Identifiable {
        let id: UUID
        var name: String
        var data: Data
    }
    @Published private(set) var entries: [Entry] = []
    private let key = "folderBookmarks"

    init() {
        if let raw = UserDefaults.standard.data(forKey: key),
           let decoded = try? JSONDecoder().decode([Entry].self, from: raw) {
            entries = decoded
        }
    }

    func add(_ url: URL) throws {
        let started = url.startAccessingSecurityScopedResource()
        defer { if started { url.stopAccessingSecurityScopedResource() } }
        let data = try url.bookmarkData()
        entries.append(Entry(id: UUID(), name: url.lastPathComponent, data: data))
        save()
    }

    func resolve(_ entry: Entry) -> URL? {
        var stale = false
        guard let url = try? URL(resolvingBookmarkData: entry.data, bookmarkDataIsStale: &stale) else { return nil }
        if stale, let i = entries.firstIndex(where: { $0.id == entry.id }) {
            let started = url.startAccessingSecurityScopedResource()
            defer { if started { url.stopAccessingSecurityScopedResource() } }
            if let fresh = try? url.bookmarkData() { entries[i].data = fresh; save() }
        }
        return url
    }

    func remove(at offsets: IndexSet) { entries.remove(atOffsets: offsets); save() }

    private func save() {
        if let raw = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(raw, forKey: key) }
    }
}
