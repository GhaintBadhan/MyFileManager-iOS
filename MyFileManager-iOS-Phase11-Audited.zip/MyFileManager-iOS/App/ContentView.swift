import SwiftUI

final class ScopedAccess: ObservableObject {
    private let url: URL
    private let started: Bool
    init(url: URL, scoped: Bool) {
        self.url = url
        started = scoped && url.startAccessingSecurityScopedResource()
    }
    deinit { if started { url.stopAccessingSecurityScopedResource() } }
}

struct RootBrowser: View {
    @StateObject private var access: ScopedAccess
    let url: URL
    let isTrash: Bool
    
    init(url: URL, scoped: Bool, isTrash: Bool = false) {
        self.url = url
        self.isTrash = isTrash
        _access = StateObject(wrappedValue: ScopedAccess(url: url, scoped: scoped))
    }
    var body: some View { BrowserView(url: url, isTrash: isTrash) }
}

// 🔥 Premium Icon Style
struct SettingsIcon: View {
    let systemName: String
    let color: Color

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: 14, weight: .semibold))
            .foregroundColor(.white)
            .frame(width: 28, height: 28)
            .background(color)
            .cornerRadius(6)
    }
}

struct ContentView: View {
    @StateObject private var bookmarks = BookmarkStore()
    @StateObject private var clipboard = Clipboard()
    
    @AppStorage("isHiddenSpaceEnabled") private var isHiddenSpaceEnabled = true
    
    private let documentsURL: URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    private let trashURL: URL = {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(".Trash")
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }()
    private let hiddenURL: URL = {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(".HiddenFolders")
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }()
    
    var body: some View {
        DualPaneView(documentsURL: documentsURL, trashURL: trashURL, hiddenURL: hiddenURL)
        .environmentObject(clipboard)
    }
}

struct FolderList: View {
    @ObservedObject var bookmarks: BookmarkStore
    let documentsURL: URL
    let trashURL: URL
    let hiddenURL: URL
    let isHiddenSpaceEnabled: Bool
    
    @EnvironmentObject var clipboard: Clipboard
    
    @State private var importing = false
    @State private var errorText: String?
    @State private var showWiFiSheet = false
    @State private var showGlobalSearch = false
    @State private var showBrowser = false
    @State private var showDownloads = false
    @State private var showWebDAV = false
    
    @State private var showNewFolderAlert = false
    @State private var newFolderName = ""
    @State private var showNewFileAlert = false
    @State private var newFileName = ""
    
    @ObservedObject var downloadManager = DownloadManager.shared
    @AppStorage("isWiFiServerEnabled") private var isWiFiServerEnabled = true
    @AppStorage("trashRetentionDays") private var trashRetentionDays = 30
    
    var body: some View {
        NavigationStack {
            List {
                Section("On My iPhone") {
                    NavigationLink { RootBrowser(url: documentsURL, scoped: false) } label: {
                        Label { Text("Documents") } icon: { SettingsIcon(systemName: "folder.fill", color: .blue) }
                    }
                    
                    if isHiddenSpaceEnabled {
                        NavigationLink { SecureFolderView(url: hiddenURL) } label: {
                            Label { Text("Hidden Space") } icon: { SettingsIcon(systemName: "eye.slash.fill", color: .purple) }
                        }
                    }
                    
                    NavigationLink { RootBrowser(url: trashURL, scoped: false, isTrash: true) } label: {
                        Label { Text("Recently Deleted") } icon: { SettingsIcon(systemName: "trash.fill", color: .red) }
                    }
                }
                
                Section("Added Folders") {
                    if bookmarks.entries.isEmpty {
                        Text("No external folders added yet.").font(.subheadline).foregroundStyle(.secondary).padding(.vertical, 4)
                    } else {
                        ForEach(bookmarks.entries) { entry in
                            NavigationLink {
                                if let url = bookmarks.resolve(entry) { RootBrowser(url: url, scoped: true) }
                                else { Text("Folder is no longer available") }
                            } label: {
                                Label { Text(entry.name) } icon: { SettingsIcon(systemName: "externaldrive.fill", color: .green) }
                            }
                        }.onDelete { bookmarks.remove(at: $0) }
                    }
                }
                
                Section("Web Tools") {
                    Button { showBrowser = true } label: {
                        Label { Text("Web Browser") } icon: { SettingsIcon(systemName: "globe", color: .blue) }
                    }
                    
                    Button { showDownloads = true } label: {
                        HStack {
                            Label { Text("Downloads") } icon: { SettingsIcon(systemName: "arrow.down.circle.fill", color: .green) }
                            Spacer()
                            if !downloadManager.activeDownloads.filter({ !$0.isFinished }).isEmpty {
                                Circle().fill(.red).frame(width: 8, height: 8)
                            }
                        }
                    }
                }
                
                Section("Network & Cloud") {
                    Button { showWebDAV = true } label: {
                        Label { Text("WebDAV Client") } icon: { SettingsIcon(systemName: "server.rack", color: .purple) }
                    }
                    
                    if isWiFiServerEnabled {
                        Button { showWiFiSheet = true } label: {
                            Label { Text("Wi-Fi File Server") } icon: { SettingsIcon(systemName: "wifi", color: .orange) }
                        }
                    }
                }
            }
            .navigationTitle("Files")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showGlobalSearch = true } label: { Image(systemName: "magnifyingglass") }
                }
                
                // 🔥 FIXED: NavigationLink instead of a Button/Sheet
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        SettingsView()
                    } label: {
                        Image(systemName: "gearshape")
                            .foregroundStyle(.gray)
                    }
                }
                
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button { newFolderName = ""; showNewFolderAlert = true } label: { Label("New Folder", systemImage: "folder.badge.plus") }
                        Button { newFileName = ""; showNewFileAlert = true } label: { Label("New File", systemImage: "doc.badge.plus") }
                        Button { importing = true } label: { Label("Import Files", systemImage: "square.and.arrow.down") }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            // Sheets
            .sheet(isPresented: $showWiFiSheet) { WiFiTransferView(rootURL: documentsURL) }
            .sheet(isPresented: $showGlobalSearch) { GlobalSearchView() }
            .sheet(isPresented: $showBrowser) { WebBrowserView(downloadDirectory: documentsURL) }
            .sheet(isPresented: $showDownloads) { DownloadsView() }
            .sheet(isPresented: $showWebDAV) { WebDAVView() }
            
            .fileImporter(isPresented: $importing, allowedContentTypes: [.folder]) { result in
                switch result {
                case .success(let url):
                    do { try bookmarks.add(url) } catch { errorText = error.localizedDescription }
                case .failure(let error): errorText = error.localizedDescription
                }
            }
            .alert("New Folder", isPresented: $showNewFolderAlert) {
                TextField("Folder Name", text: $newFolderName)
                Button("Create") {
                    guard !newFolderName.isEmpty else { return }
                    let url = documentsURL.appendingPathComponent(newFolderName)
                    try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: false)
                    NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                }
                Button("Cancel", role: .cancel) {}
            }
            .alert("New File", isPresented: $showNewFileAlert) {
                TextField("File Name (e.g. notes.txt)", text: $newFileName)
                Button("Create") {
                    guard !newFileName.isEmpty else { return }
                    let url = documentsURL.appendingPathComponent(newFileName)
                    FileManager.default.createFile(atPath: url.path, contents: Data())
                    NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
                }
                Button("Cancel", role: .cancel) {}
            }
            .alert("Error", isPresented: Binding(get: { errorText != nil }, set: { if !$0 { errorText = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(errorText ?? "") }
            
            .onAppear {
                let service = FileSystemService()
                service.purgeOldTrashItems(days: trashRetentionDays)
            }
        }
    }
}
