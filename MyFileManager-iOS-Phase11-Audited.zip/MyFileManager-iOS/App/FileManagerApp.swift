import SwiftUI

@main
struct FileManagerApp: App {
    var body: some Scene {
        WindowGroup { 
            ContentView()
                // 🔥 Intercept files shared from other apps
                .onOpenURL { url in
                    importSharedFile(url)
                }
        }
    }
    
    private func importSharedFile(_ url: URL) {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dest = docs.appendingPathComponent(url.lastPathComponent)
        
        do {
            let started = url.startAccessingSecurityScopedResource()
            defer { if started { url.stopAccessingSecurityScopedResource() } }
            
            if FileManager.default.fileExists(atPath: dest.path) {
                try FileManager.default.removeItem(at: dest)
            }
            try FileManager.default.copyItem(at: url, to: dest)
            
            // Tell the browser to refresh
            NotificationCenter.default.post(name: NSNotification.Name("FileSystemChanged"), object: nil)
            
        } catch {
            print("Error importing shared file: \(error)")
        }
    }
}
